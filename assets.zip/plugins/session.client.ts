import { Pinia } from '@pinia/nuxt/dist/runtime/composables';

import { useAuthStore } from '~/store/auth';
import { defineNuxtPlugin } from '#imports';

export default defineNuxtPlugin(async nuxt => {
  const authStore = useAuthStore(nuxt.$pinia as Pinia);

  const { getSession } = useAuth();

  const session = await getSession({ required: true });
  authStore.setSession(session);
});
