import quasarLang from 'quasar/lang/pt-BR';
import '@quasar/extras/roboto-font/roboto-font.css';
import '@quasar/extras/material-icons/material-icons.css';
import '@quasar/extras/fontawesome-v6/fontawesome-v6.css';

import { Quasar, Notify, Loading } from 'quasar';
import * as quasarComponents from 'quasar';
import * as quasarDirectives from 'quasar';

// @ts-ignore
export default defineNuxtPlugin(nuxtApp => {
  const quasarUserOptions: any = {
    lang: quasarLang,
    plugins: { Notify, Loading },
    components: quasarComponents,
    directives: quasarDirectives
    // ssr: false
    // runMode: 'web-client' // "web-client" | "ssr-client" | "ssr-server";
    // boot: [
    //   'some-boot-file', // runs on both server & client
    //   { path: 'some-other', server: false }, // this boot file gets embedded only on client-side
    //   { path: 'third', client: false } // this boot file gets embedded only on server-side
    // ]
  };

  nuxtApp.vueApp.use(Quasar, quasarUserOptions);

  // @ts-ignore
  const { vueApp } = useNuxtApp();

  return {
    provide: {
      q: vueApp.config.globalProperties.$q
    }
  };
});
