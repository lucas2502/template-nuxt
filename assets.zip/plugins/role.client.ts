import { Pinia } from '@pinia/nuxt/dist/runtime/composables';
import { ErrorCodeEnum } from '~/logic/core/enums/ErrorCodeEnum';
import { useRolesStore } from '~/store/roles';
import { StatusType, useNotifyStore } from '~/store/notify';
import { defineNuxtPlugin } from '#imports';
import getAllUserRolesUseCase from '~/logic/modules/functionality/use-cases/GetAllUserRoles';

export default defineNuxtPlugin(async nuxt => {
  const rolesStore = useRolesStore(nuxt.$pinia as Pinia);
  const notifyStore = useNotifyStore(nuxt.$pinia as Pinia);

  const res = await getAllUserRolesUseCase.execute();

  if (res.isLeft()) {
    const code = res.value.errorValue().code;

    if (code === ErrorCodeEnum.NotFound) {
      return;
    }

    if (code === ErrorCodeEnum.AccessDenied) {
      notifyStore.toggleNotify({
        type: StatusType.WARNING,
        message: 'Usuários não autorizado!'
      });
      return;
    }
    notifyStore.toggleNotify({
      type: StatusType.ERROR,
      message: 'Ocorreu um erro!'
    });

    return;
  }
  const roles = res.value.getValue();
  rolesStore.setRoles(roles);
});
