<template>
  <AdminPage>
    <q-form
      ref="formSearchUser"
      class="q-gutter-md"
      @submit="filterEmailTemplate"
    >
      <div class="row">
        <div class="col-6 q-pa-sm">
          <UiAtomInputText
            id="input-text-search-profile"
            v-model="searchByName"
            label="Nome"
            max-length="50"
            placeholder="Informe o nome"
            :rules="[
                (val: any) => (val && val.length > 0) || 'Campo obrigatório!'
              ]"
          ></UiAtomInputText>
        </div>
      </div>
      <div class="row">
        <div class="col-3 col-md-3 col-sm-6 q-pa-sm">
          <UiAtomInputDate
            id="input-text-search-profile"
            v-model="searchByStartDate"
            label="Mês/Ano de cadastro inicio"
            placeholder="Informe data incio"
            :rules="[
                (val: any) => (val && val.length > 0) || 'Campo obrigatório!'
              ]"
          ></UiAtomInputDate>
        </div>
        <div class="col-3 col-md-3 col-sm-6 q-pa-sm">
          <UiAtomInputDate
            id="input-text-search-profile"
            v-model="searchByEndDate"
            label="Mês/Ano de cadastro fim"
            placeholder="Informe data fim"
            :rules="[
                (val: any) => (val && val.length > 0) || 'Campo obrigatório!'
              ]"
          ></UiAtomInputDate>
        </div>
        <div class="col-2 col-md-2 com-sm-6 q-pa-sm q-mt-xs">
          <UiAtomButton
            id="button-search-profile"
            label="Buscar"
            class="q-mt-md"
            :loading="loading.searchBtn"
            :disable="loading.emailTemplate"
            type="submit"
          ></UiAtomButton>
        </div>
      </div>
    </q-form>
    <div class="row q-mt-md">
      <div class="col-12">
        <UiAtomTable
          id="table-profiles"
          :columns="emailTemplateTable.columns"
          :rows="emailTemplateTable.rows"
          :hide-bottom="$q.screen.lt.sm"
          :hide-header="$q.screen.lt.sm"
          :bordered="$q.screen.lt.sm"
          :grid="$q.screen.lt.sm"
          :loading="loading.emailTemplate || loading.searchBtn"
          row-key="id"
        >
          <template #body-cell-action="props">
            <q-td :props="props">
              <UiAtomIcon
                v-if="canDetails"
                id="icon-search"
                icon="search"
                size="sm"
                cursor-pointer
                @click="
                  openDialogWithProfileSelected({
                    item: props.row.id,
                    action: 'about'
                  })
                "
              ></UiAtomIcon>
              <UiAtomIcon
                v-if="canUpdate"
                id="icon-edit"
                icon="edit"
                size="sm"
                cursor-pointer
                @click="
                  openDialogWithProfileSelected({
                    item: props.row.id,
                    action: 'edit'
                  })
                "
              ></UiAtomIcon>
              <UiAtomIcon
                v-if="canDelete"
                id="icon-remove"
                name="close"
                size="sm"
                cursor-pointer
                @click="
                  showConfirmActionDeleteProfile({
                    show: true,
                    item: props.row.id
                  })
                "
              ></UiAtomIcon>
            </q-td>
          </template>
        </UiAtomTable>
      </div>
    </div>
    <template #actions>
      <UiAtomButton
        v-if="canSave"
        id="button-prodile-add"
        label="ADICIONAR"
        class="q-ml-xs"
        @click="toggleDialog({ show: true })"
      ></UiAtomButton>
    </template>
  </AdminPage>
  <UiMoleculeDialog v-model="dialog">
    <template #title>Template de E-mail</template>
    <template #content>
      <template v-if="loading.getEmailTemplate">
        <UiAtomCircularProgress></UiAtomCircularProgress
      ></template>
      <template v-else>
        <q-form ref="formSubmit" class="q-gutter-md">
          <div class="row">
            <div class="col-12 q-pa-sm">
              <UiAtomInputText
                id="input-text-profile-name"
                v-model="emailTemplate.templateName"
                label="Nome *"
                :disable="isAbout"
                max-length="50"
                :rules="[
                (val: any) => (val && val.length > 0) || 'Campo obrigatório!'
              ]"
              ></UiAtomInputText>
            </div>
          </div>
          <div class="row">
            <div class="col-12 q-pa-sm">
              <UiAtomInputText
                id="input-text-profile-name"
                v-model="emailTemplate.description"
                label="Descrição *"
                type="textarea"
                max-length="250"
                :disable="isAbout"
                :rules="[
                (val: any) => (val && val.length > 0) || 'Campo obrigatório!'
              ]"
              ></UiAtomInputText>
            </div>
          </div>
          <div class="row">
            <div class="col-9 q-pa-sm">
              <UiAtomInputText
                id="input-email-chip"
                v-model="emailChip"
                label="Copia para"
                :disable="isAbout"
                max-length="100"
              ></UiAtomInputText>
            </div>
            <div class="col-2 q-pa-sm q-mt-xs">
              <UiAtomButton
                id="button-search-profile"
                label="ADICIONAR"
                class="q-mt-md q-ml-sm"
                :disable="disableButtonAddEmail"
                :loading="loading.delete"
                @click="handlePushEmailChip"
              ></UiAtomButton>
            </div>
            <q-chip
              v-for="name in emailTemplate.emailList"
              :key="name"
              class="q-mt-sm"
              removable
              :disable="isAbout"
              color="primary"
              text-color="white"
              @remove="handleRemoveEmailChip(name)"
            >
              {{ name }}
            </q-chip>
          </div>
          <div class="row">
            <div class="col-9 q-pa-sm">
              <UiAtomEditor
                id="skeditor"
                v-model="emailTemplate.templateContent"
                label="Template *"
                :disable="isAbout"
                :rules="[
                (val: any) =>
                  (val &&
                    val.length > 0) ||
                  'Campo obrigatório!'
              ]"
              />
            </div>
            <div class="col-3 q-mt-sm">
              <q-label id="label-variables">Variaveis</q-label>
              <q-scroll-area
                class="q-mt-xs q-scroll-area-variables"
                :thumb-style="{ width: '5px' }"
              >
                <div v-for="variables in templateVariables()" :key="variables">
                  <UiAtomButton
                    id="button-close-dialog"
                    :label="variables.key"
                    class="q-mb-sm full-width"
                    outline
                    bold
                    :disable="isAbout"
                    @click="handleSetVariablesOnTamplate(variables.value)"
                  />
                </div>
              </q-scroll-area>
            </div>
          </div>
        </q-form>
      </template>
    </template>
    <template #actions>
      <UiAtomButton
        id="button-close-dialog"
        label="FECHAR"
        outline
        bold
        @click="toggleDialog({ show: false })"
      ></UiAtomButton>
      <UiAtomButton
        v-if="!isAbout && canSave"
        id="button-prodile-add-new"
        label="SALVAR"
        :loading="loading.submit"
        :disable="loading.getEmailTemplate"
        @click="submit"
      ></UiAtomButton>
    </template>
  </UiMoleculeDialog>
  <UiOrganismBaseModal v-model="showDeleteModal" persistent>
    <template #header>Deseja deletar o Template de E-mail?</template>

    <template #footer>
      <UiAtomButton
        id="button-modal-cancel-action"
        label="CANCELAR"
        outline
        bold
        @click="showConfirmActionDeleteProfile({ show: false })"
      ></UiAtomButton>
      <UiAtomButton
        id="button-modal-confirm-action"
        label="CONFIRMAR"
        class="q-ml-xs"
        :loading="loading.delete"
        @click="deleteSelectedEmailTemplate"
      ></UiAtomButton>
    </template>
  </UiOrganismBaseModal>
</template>

<script setup lang="ts">
import { Helper } from '@pmesp/logic/dist/core/helpers/Helper';
import { ErrorCodeEnum } from '@pmesp/logic/dist/core/enums/ErrorCodeEnum';
import { RoleEnum } from '@pmesp/logic/dist/modules/functionality/enums/RoleEnum';
import { GetEmailTemplateByIdDTO } from '@pmesp/logic/dist/modules/email-template/use-cases/GetEmailTemplateById/GetEmailTemplateByIdDTO';
import { GetAllEmailTemplatesDTO } from '@pmesp/logic/dist/modules/email-template/use-cases/GetAllEmailTemplates/GetAllEmailTemplatesDTO';
import { Column } from '../../../../../../lib/ui/components/v1/atom/table/UiAtomTable.vue';
import { StatusType, StatusTypeKey, useNotifyStore } from '~/store/notify';
import { useRolesStore } from '~/store/roles';

definePageMeta({ title: 'Administração / Template de E-mail' });

const searchByName = ref<string | undefined>(undefined);
const searchByStartDate = ref<string | undefined>(undefined);
const searchByEndDate = ref<string | undefined>(undefined);
const formSubmit = ref<boolean | undefined>(undefined);
const showDeleteModal = ref<boolean>(false);
const emailChip = ref<string | undefined>(undefined);
const loading = ref({
  emailTemplate: false as boolean,
  delete: false as boolean,
  searchBtn: false as boolean,
  submit: false as boolean,
  getEmailTemplate: false as boolean
});
const notifyStore = useNotifyStore();

const { $UseCase, $q } = useNuxtApp();

const { signOut } = useAuth();

const emailTemplateTable = ref({
  selected: undefined as string | undefined,
  columns: [
    {
      name: 'name',
      field: 'name',
      label: 'Perfil',
      align: 'left'
    },
    {
      name: 'description',
      field: 'description',
      align: 'left',
      label: 'Descrição',
      style: 'word-break: break-all; white-space: pre-line !important;'
    },
    {
      name: 'author',
      field: 'author',
      label: 'Autor',
      // style: 'min-width: 200px',
      align: 'left'
    },
    {
      name: 'monthYear',
      field: 'monthYear',
      label: 'Mês/Ano de Cadastro',
      align: 'left'
    },
    {
      name: 'action',
      field: 'action',
      label: 'Ações',
      align: 'center'
    }
  ] as Column[],
  rows: [] as GetAllEmailTemplatesDTO.EmailTemplate[]
});

const emailTemplate = ref({
  id: undefined as string | undefined,
  templateName: undefined as string | undefined,
  description: undefined as string | undefined,
  emailList: [] as string[],
  templateContent: '' as string,
  author: undefined as string | undefined,
  monthYear: undefined as string | undefined,
  active: undefined as boolean | undefined
});

// type & interfaces
enum ActionType {
  ABOUT = 'about',
  ADD = 'add',
  EDIT = 'edit'
}
export type ActionKey = `${ActionType}`;

const dialog = ref<boolean>(false);

const dialogAction = ref<ActionKey>(ActionType.ADD);

// Methods
async function openDialogWithProfileSelected(value: {
  item: string;
  action?: ActionKey;
}) {
  if (Helper.isDefined(value.item)) {
    toggleDialog({ show: true, action: value.action });
    await getEmailTemplateById({ id: value.item });
  }
}

function clearData() {
  emailTemplate.value.id = undefined;
  emailTemplate.value.templateName = undefined;
  emailTemplate.value.description = undefined;
  emailTemplate.value.emailList = [];
  emailChip.value = undefined;
  emailTemplate.value.templateContent = '';
  emailTemplate.value.author = undefined;
  emailTemplate.value.monthYear = undefined;
  emailTemplate.value.active = undefined;
}

function toggleDialog(value: { show: boolean; action?: ActionKey }) {
  const show = value.show;
  const action = value?.action ?? ActionType.ADD;
  dialog.value = show;

  if (show === true) {
    dialogAction.value = action;
  }
}

onMounted(async () => {
  await getAllEmailTemplates();
});

watch(dialog, value => {
  if (Helper.isNotDefined(value)) {
    clearData();
  }
});

const disableButtonAddEmail = computed(() => {
  return !!(
    Helper.isEmpty(emailChip.value) ||
    Helper.isNotDefined(emailChip.value) ||
    isAbout.value ||
    emailTemplate?.value?.emailList?.length >= 10
  );
});
const isAbout = computed(() => {
  return dialogAction.value === ActionType.ABOUT;
});

const rolesStore = useRolesStore();

const canDelete = computed(() => {
  return rolesStore.existRoles(RoleEnum.Templates.Delete);
});

const canSave = computed(() => {
  return rolesStore.existRoles(RoleEnum.Templates.Post);
});

const canUpdate = computed(() => {
  return rolesStore.existRoles(RoleEnum.Templates.Put);
});

const canDetails = computed(() => {
  return rolesStore.existRoles(RoleEnum.Templates.GetById);
});

function showNotify(value: { type: StatusTypeKey; message: string }) {
  notifyStore.toggleNotify();
  notifyStore.toggleNotify({
    type: value.type,
    message: value.message
  });
}

const templateVariables = () => {
  return $UseCase.EmailTemplate.GetTemplateVariables.execute().variables;
};

function handleSetVariablesOnTamplate(event: string) {
  if (Helper.isDefined(event)) {
    const templateContent = emailTemplate.value.templateContent;
    emailTemplate.value.templateContent = `${templateContent} ${event}`;
  }
}

async function getAllEmailTemplates() {
  emailTemplateTable.value.rows = [];

  loading.value.emailTemplate = true;
  const res = await $UseCase.EmailTemplate.GetAllEmailTemplates.execute();
  loading.value.emailTemplate = false;

  if (res.isLeft()) {
    const code = res.value.errorValue().code;

    if (code === ErrorCodeEnum.AccessDenied) {
      await signOut({
        redirect: true,
        callbackUrl: `http://intranet.policiamilitar.sp.gov.br/`
      });
    }

    if (code === ErrorCodeEnum.NotFound) {
      return;
    }
    showNotify({
      type: StatusType.ERROR,
      message: 'Ocorreu um erro ao listar informações!'
    });

    return;
  }
  const emailTemplates = res.value.getValue();

  emailTemplateTable.value.rows = emailTemplates;
}

async function filterEmailTemplate() {
  if (
    Helper.isDefined(searchByName.value) ||
    Helper.isDefined(searchByStartDate.value) ||
    Helper.isDefined(searchByEndDate.value)
  ) {
    const input = {
      templateName: searchByName.value ?? undefined,
      startDate: searchByStartDate.value ?? undefined,
      endDate: searchByEndDate.value ?? undefined
    };

    loading.value.searchBtn = true;
    const res = await $UseCase.EmailTemplate.GetFilteredEmailTemplates.execute(
      input
    );

    loading.value.searchBtn = false;

    if (res.isLeft()) {
      const code = res.value.errorValue().code;

      if (code === ErrorCodeEnum.AccessDenied) {
        await signOut({
          redirect: true,
          callbackUrl: `http://intranet.policiamilitar.sp.gov.br/`
        });
      }

      if (code === ErrorCodeEnum.BadRequest) {
        showNotify({
          type: StatusType.WARNING,
          message: 'Template de e-mail não encontrado'
        });
        return;
      }

      if (code === ErrorCodeEnum.NotFound) {
        return;
      }
      showNotify({
        type: StatusType.ERROR,
        message: 'Ocorreu um erro ao listar informações!'
      });

      return;
    }

    emailTemplateTable.value.rows = Helper.isDefined(res.value.getValue())
      ? res.value.getValue()
      : [];
  }
}

async function getEmailTemplateById(
  value: GetEmailTemplateByIdDTO.Request
): Promise<GetEmailTemplateByIdDTO.ResponseBody | void> {
  if (Helper.isDefined(value.id)) {
    const input = {
      id: value.id
    };
    loading.value.getEmailTemplate = true;
    const res = await $UseCase.EmailTemplate.GetEmailTemplateById.execute(
      input
    );
    loading.value.getEmailTemplate = false;

    if (res.isLeft()) {
      const code = res.value.errorValue().code;

      if (code === ErrorCodeEnum.BadRequest) {
        showNotify({
          type: StatusType.WARNING,
          message: 'Template de E-mail não encontrado!'
        });
        return;
      }

      if (code === ErrorCodeEnum.NotFound) {
        return;
      }

      showNotify({
        type: StatusType.ERROR,
        message: 'Ocorreu um erro ao listar template de e-mail!'
      });

      return;
    }
    const emailTemplateDetails = res.value.getValue();

    emailTemplate.value.id = emailTemplateDetails.id;
    emailTemplate.value.templateName = emailTemplateDetails.name;
    emailTemplate.value.description = emailTemplateDetails.description;
    emailTemplate.value.emailList = emailTemplateDetails.emailList;
    emailTemplate.value.templateContent = emailTemplateDetails.templateContent;
    emailTemplate.value.author = emailTemplateDetails.author;
    emailTemplate.value.monthYear = emailTemplateDetails.monthYear;
    emailTemplate.value.active = emailTemplateDetails.active;
  }
}

async function deleteEmailTemplate(id: string) {
  if (Helper.isDefined(id)) {
    const input = {
      id
    };

    loading.value.delete = true;
    const res = await $UseCase.EmailTemplate.DeleteEmailTemplate.execute(input);
    loading.value.delete = false;

    if (res.isLeft()) {
      const code = res.value.errorValue().code;

      if (code === ErrorCodeEnum.AccessDenied) {
        await signOut({
          redirect: true,
          callbackUrl: `http://intranet.policiamilitar.sp.gov.br/`
        });
      }
      showNotify({ type: StatusType.ERROR, message: 'Ocorreu um erro!' });
      return;
    }
    showNotify({
      type: StatusType.SUCCESS,
      message: 'Perfil deletado com sucesso'
    });
    await getAllEmailTemplates();
  }
}

async function createEmailTemplate() {
  if (
    Helper.isDefined(emailTemplate.value.templateName) &&
    Helper.isDefined(emailTemplate.value.description) &&
    Helper.isDefined(emailTemplate.value.emailList) &&
    Helper.isDefined(emailTemplate.value.templateContent)
  ) {
    const input = {
      templateName: emailTemplate.value.templateName,
      description: emailTemplate.value.description,
      emailList: emailTemplate.value.emailList,
      templateContent: emailTemplate.value.templateContent
    };

    loading.value.submit = true;
    const res = await $UseCase.EmailTemplate.CreateEmailTemplate.execute(input);
    loading.value.submit = false;

    if (res.isLeft()) {
      const code = res.value.errorValue().code;

      if (code === ErrorCodeEnum.AccessDenied) {
        await signOut({
          redirect: true,
          callbackUrl: `http://intranet.policiamilitar.sp.gov.br/`
        });
      }

      if (code === ErrorCodeEnum.BadRequest) {
        showNotify({
          type: StatusType.WARNING,
          message:
            'Este nome já está sendo utilizado por outro template de e-mail'
        });
        return;
      }

      showNotify({ type: StatusType.ERROR, message: 'Ocorreu um erro!' });
      return;
    }
    showNotify({
      type: StatusType.SUCCESS,
      message: 'Salvo com sucesso!'
    });
    toggleDialog({ show: false });
    await getAllEmailTemplates();
  }
}

async function updateEmailTemplate() {
  if (Helper.isDefined(emailTemplate.value.id)) {
    const input = {
      id: emailTemplate.value.id,
      templateName: emailTemplate.value.templateName,
      description: emailTemplate.value.description,
      emailList: emailTemplate.value.emailList,
      templateContent: emailTemplate.value.templateContent
    };

    loading.value.submit = true;
    const res = await $UseCase.EmailTemplate.UpdateEmailTemplate.execute(input);
    loading.value.submit = false;

    if (res.isLeft()) {
      const code = res.value.errorValue().code;

      if (code === ErrorCodeEnum.AccessDenied) {
        await signOut({
          redirect: true,
          callbackUrl: `http://intranet.policiamilitar.sp.gov.br/`
        });
      }
      if (code === ErrorCodeEnum.BadRequest) {
        showNotify({
          type: StatusType.WARNING,
          message:
            'Este nome já está sendo utilizado por outro template de e-mail'
        });
        return;
      }
      showNotify({ type: StatusType.ERROR, message: 'Ocorreu um erro!' });

      return;
    }
    showNotify({
      type: StatusType.SUCCESS,
      message: 'Atualizado com sucesso!'
    });
    toggleDialog({ show: false });
    await getAllEmailTemplates();
  }
}
async function validate(): Promise<boolean> {
  // @ts-ignore
  return await formSubmit.value.validate().then((success: any) => {
    if (success) {
      return true;
    }
    return false;
  });
}
async function submit() {
  const isValidate = await validate();
  if (isValidate) {
    if (Helper.isDefined(emailTemplate.value.id)) {
      return await updateEmailTemplate();
    }
    await createEmailTemplate();
  }
}

async function deleteSelectedEmailTemplate() {
  const selected = emailTemplateTable.value.selected;
  if (Helper.isDefined(selected)) {
    await deleteEmailTemplate(selected);
    showConfirmActionDeleteProfile({ show: false });
    await getAllEmailTemplates();
  }
}

function showConfirmActionDeleteProfile(value: {
  show: boolean;
  item?: string;
}) {
  showDeleteModal.value = value?.show;
  if (Helper.isDefined(value.item)) {
    const templateId = value.item;
    emailTemplateTable.value.selected = templateId;
  }
}

function handlePushEmailChip() {
  if (!Array.isArray(emailTemplate.value.emailList)) {
    emailTemplate.value.emailList = [];
  }
  if (
    Helper.isDefined(emailChip.value) &&
    Helper.isNotEmpty(emailChip.value) &&
    emailTemplate.value.emailList.filter(e => e === emailChip.value).length <= 0
  ) {
    emailTemplate.value.emailList.push(emailChip.value);
    emailChip.value = undefined;
  }
}

function handleRemoveEmailChip(name: string) {
  if (Helper.isDefined(emailTemplate.value.emailList)) {
    const index = emailTemplate.value.emailList.indexOf(name);
    if (index !== -1) {
      emailTemplate.value.emailList.splice(index, 1);
    }
  }
}
</script>
<style lang="scss" scoped>
.q-scroll-area-variables {
  height: 170px;
}

@media only screen and (max-width: 900px) {
  .q-scroll-area-variables {
    height: 200px;
  }
}
</style>
