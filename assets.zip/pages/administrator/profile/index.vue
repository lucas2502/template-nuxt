<template>
  <AdminPage>
    <div class="row">
      <div class="col-6 q-pa-sm">
        <UiAtomInputText
          id="input-text-search-profile"
          v-model="searchProfile"
          label="Perfil"
          max-length="30"
          placeholder="Informe o nome do perfil"
          :disable="!canGetUserByName"
        ></UiAtomInputText>
      </div>
      <div class="col-2 q-pa-sm">
        <UiAtomInputSelect
          id="input-select-application-search"
          v-model="applicationSearchProfile"
          label="Aplicação"
          :options="applications"
          return-single-value
          :disable="!canGetUserByName"
        ></UiAtomInputSelect>
      </div>
      <div class="col-2 q-pa-sm q-mt-xs">
        <UiAtomButton
          id="button-search-profile"
          label="Buscar"
          class="q-mt-md"
          :disable="loading.profiles || !canGetUserByName"
          :loading="loading.getProfile"
          @click="searchProfiles"
        ></UiAtomButton>
      </div>
    </div>

    <div class="row q-mt-md">
      <div class="col-12">
        <UiAtomTable
          id="table-profiles"
          v-model="profileTable.selected"
          :columns="profileTable.columns"
          :rows="profileTable.rows"
          :hide-bottom="$q.screen.lt.sm"
          :hide-header="$q.screen.lt.sm"
          :bordered="$q.screen.lt.sm"
          :grid="$q.screen.lt.sm"
          :loading="loading.profiles"
          selection="multiple"
          row-key="id"
          wrap-cells
          selected-rows-label
        >
          <template #body-cell-action="props">
            <q-td :props="props">
              <UiAtomIcon
                id="icon-search"
                icon="search"
                size="sm"
                cursor-pointer
                @click="
                  openDialogWithProfileSelected({
                    item: props.row.name,
                    action: 'about'
                  })
                "
              ></UiAtomIcon>
              <UiAtomIcon
                v-if="canUpdate"
                id="icon-edit"
                icon="edit"
                size="sm"
                cursor-pointer
                @click="
                  openDialogWithProfileSelected({
                    item: props.row.name,
                    action: 'edit'
                  })
                "
              ></UiAtomIcon>
              <UiAtomIcon
                v-if="canDelete"
                id="icon-remove"
                name="close"
                size="sm"
                cursor-pointer
                @click="
                  showConfirmActionDeleteProfile({
                    show: true,
                    item: [{ name: props.row.name }]
                  })
                "
              ></UiAtomIcon>
            </q-td>
          </template>
        </UiAtomTable>
      </div>
    </div>

    <template v-if="canSave || canDelete" #actions>
      <UiAtomButton
        v-if="canDelete"
        id="button-prodile-remove-selected"
        label="DELETAR SELECIONADOS"
        outline
        bold
        icon="close"
        :disabled="loading.delete"
        style="width: 220px"
        @click="
          showConfirmActionDeleteProfile({
            show: true,
            item: profileTable.selected
          })
        "
      ></UiAtomButton>
      <UiAtomButton
        v-if="canSave"
        id="button-prodile-add"
        label="NOVO PERFIL"
        class="q-ml-xs"
        @click="toggleDialog({ show: true })"
      ></UiAtomButton>
    </template>
  </AdminPage>
  <UiMoleculeDialog v-model="dialog">
    <template #title>{{ dialogTitle }}</template>
    <template #content>
      <template v-if="loading.getProfile">
        <UiAtomCircularProgress></UiAtomCircularProgress
      ></template>
      <template v-else>
        <q-form ref="formSubmit" class="q-gutter-md">
          <div class="row">
            <div class="col-6 q-pa-sm">
              <UiAtomInputText
                id="input-text-profile-name"
                v-model="profile.name"
                label="Perfil *"
                max-length="30"
                :mask="mask.wordAndNumber"
                placeholder="Informe o nome do perfil"
                lazy-rules
                :disable="isAbout || isEdit"
                :rules="[
                (val: any) => (val && val.length > 0) || 'Campo obrigatório!'
              ]"
              ></UiAtomInputText>
            </div>
            <div class="col-6 q-pa-sm">
              <UiAtomInputSelect
                id="input-select-application"
                v-model="profile.application"
                label="Aplicação *"
                :options="applications"
                return-single-value
                lazy-rules
                :disable="isAbout || isEdit"
                :rules="[
                (val:any) => (val && val.length > 0) || 'Campo obrigatório!'
              ]"
              ></UiAtomInputSelect>
            </div>

            <div class="col-12 q-pa-sm">
              <UiAtomInputText
                id="input-text-description"
                v-model="profile.description"
                :disable="isAbout"
                label="Descrição"
                max-length="255"
                type="textarea"
                lazy-rules
                placeholder="Informe uma descrição"
                height="100px"
              ></UiAtomInputText>
            </div>
          </div>
        </q-form>
        <UiAtomTabs
          id="tab-selection-profile"
          v-model="tab.selected"
          :tabs-name="tab.tabs"
          align-tabs="center"
        >
          <template #tab-0>
            <div class="row justify-between q-pb-md">
              <div class="col-12 q-pa-sm">
                <template v-if="loading.functionalities"
                  ><UiAtomCircularProgress
                /></template>
                <template v-else>
                  <UiAtomTree
                    v-model="functionalitiesSelected"
                    :nodes="functionalities"
                    filter
                    default-expand-all
                    :disable="isAbout"
                  >
                    <template #default-header="prop">
                      {{ $t(prop.node.label) }}
                    </template>
                  </UiAtomTree>
                </template>
              </div>
            </div>
          </template>
          <template #tab-1>
            <q-form
              ref="formSearchUser"
              class="q-gutter-md"
              @submit="searchUsers"
            >
              <div class="row q-pb-md">
                <div class="col-6 q-pa-sm">
                  <UiAtomInputText
                    id="input-text-re"
                    v-model="assignedUsers.re"
                    label="RE"
                    mask="##########"
                    max-length="10"
                    :disable="!!assignedUsers.cpf || !canGetUsers"
                    placeholder="RE"
                  ></UiAtomInputText>
                </div>
                <div class="col-6 q-pa-sm">
                  <UiAtomInputText
                    id="input-text-cpf"
                    v-model="assignedUsers.cpf"
                    label="CPF"
                    :mask="mask.cpf"
                    max-length="14"
                    placeholder="Informe o CPF"
                    :disable="!!assignedUsers.re || !canGetUsers"
                  ></UiAtomInputText>
                </div>
                <div class="col-2 q-pa-sm">
                  <UiAtomButton
                    id="button-search-users"
                    label="Buscar"
                    class="q-mt-md"
                    :loading="loading.users"
                    :disable="!canGetUsers"
                    type="submit"
                  ></UiAtomButton>
                </div>
              </div>
            </q-form>
            <div class="row justify-between">
              <div class="col-6 q-pa-sm">
                <UiAtomLabel id="title-all-functionality"
                  >Usuários não associados</UiAtomLabel
                >
                <q-separator class="q-mt-sm q-mb-md"></q-separator>

                <UiAtomTable
                  id="table-profiles-not-assigned"
                  :columns="userTable.columns"
                  :rows="userTable.rows"
                  :hide-bottom="$q.screen.lt.sm"
                  :hide-header="$q.screen.lt.sm"
                  :bordered="$q.screen.lt.sm"
                  :grid="$q.screen.lt.sm"
                  :loading="loading.users"
                  row-key="id"
                  :disabled="isAbout"
                  @row-click="addAssignedUSers"
                >
                  <template #body="props">
                    <q-tr
                      class="cursor-pointer"
                      :props="props"
                      @click="addAssignedUSers(props.row)"
                    >
                      <q-td
                        v-for="col in props.cols"
                        :key="col.name"
                        :props="props"
                      >
                        {{ col.value }}
                      </q-td>
                    </q-tr>
                  </template>
                </UiAtomTable>
              </div>
              <div class="col-6 q-pa-sm">
                <UiAtomLabel id="title-all-functionality"
                  >Usuários Associados</UiAtomLabel
                >
                <q-separator class="q-mt-sm q-mb-md"></q-separator>

                <UiAtomTable
                  id="table-profiles-assigned"
                  :columns="userAssignedTable.columns"
                  :rows="userAssignedTable.rows"
                  :hide-bottom="$q.screen.lt.sm"
                  :hide-header="$q.screen.lt.sm"
                  :bordered="$q.screen.lt.sm"
                  :grid="$q.screen.lt.sm"
                  :loading="loading.users"
                  row-key="id"
                  :disabled="isAbout"
                >
                  <template #body="props">
                    <q-tr
                      class="cursor-pointer"
                      :props="props"
                      @click="removeAssignedUSers(props.row)"
                    >
                      <q-td
                        v-for="col in props.cols"
                        :key="col.name"
                        :props="props"
                      >
                        {{ col.value }}
                      </q-td>
                    </q-tr>
                  </template>
                </UiAtomTable>
              </div>
            </div>
          </template>
        </UiAtomTabs>
      </template>
    </template>
    <template #actions>
      <UiAtomButton
        id="button-close-dialog"
        label="VOLTAR"
        outline
        bold
        @click="toggleDialog({ show: false })"
      ></UiAtomButton>
      <UiAtomButton
        v-if="!isAbout"
        id="button-prodile-add-new"
        label="SALVAR"
        :loading="loading.submit"
        :disable="loading.getProfile"
        @click="submit"
      ></UiAtomButton>
    </template>
  </UiMoleculeDialog>
  <UiOrganismBaseModal v-model="showModal" persistent>
    <template #header>{{ customMessageConfirmDelete }}</template>

    <template #footer>
      <UiAtomButton
        id="button-modal-cancel-action"
        label="CANCELAR"
        outline
        bold
        @click="showConfirmActionDeleteProfile({ show: false })"
      ></UiAtomButton>
      <UiAtomButton
        id="button-modal-confirm-action"
        label="CONFIRMAR"
        class="q-ml-xs"
        :loading="loading.delete"
        @click="deleteSelectedProfiles"
      ></UiAtomButton>
    </template>
  </UiOrganismBaseModal>
</template>

<script setup lang="ts">
import { watch } from 'vue';
import { Column } from '~~/../../lib/ui/components/v1/atom/table/UiAtomTable.vue';
import { ErrorCodeEnum } from '@pmesp/logic/dist/core/enums/ErrorCodeEnum';
import { GetAllProfilesDTO } from '@pmesp/logic/dist/modules/profiles/use-cases/GetAllProfiles/GetAllProfilesDTO';
import { RoleEnum } from '@pmesp/logic/dist/modules/functionality/enums/RoleEnum';
import {
  ProfileType,
  ProfileTypeKey
} from '@pmesp/logic/dist/modules/profiles/enums/ProfileTypeEnum';
import { FilterType } from '@pmesp/logic/dist/modules/users/enums/FilterypeEnum';
import { Helper } from '@pmesp/logic/dist/core/helpers/Helper';
import { GetAllFunctionalitiesDTO } from '@pmesp/logic/dist/modules/functionality/use-cases/GetAllFunctionalities/GetAllFunctionalitiesDTO';
import { DeleteProfileDTO } from '@pmesp/logic/dist/modules/profiles/use-cases/DeleteProfile/DeleteProfileDTO';
import { useI18n } from 'vue-i18n';
import { GetAllUsersDTO } from '@pmesp/logic/dist/modules/users/use-cases/GetAllUsers/GetAllUsersDTO';
import { GetProfileByNameDTO } from '@pmesp/logic/dist/modules/profiles/use-cases/GetProfileByName/GetProfileByNameDTO';
import { StatusType, StatusTypeKey, useNotifyStore } from '~/store/notify';
import { useRolesStore } from '~/store/roles';
import { MaskHelper } from '@/helpers/MaskHelper';

enum TitleType {
  about = 'Visualizar Perfil',
  add = 'Cadastrar Perfil',
  edit = 'Editar Perfil'
}

export type TitleKey = `${TitleType}`;

enum ActionType {
  ABOUT = 'about',
  ADD = 'add',
  EDIT = 'edit'
}

export type ActionKey = `${ActionType}`;

const { $UseCase, $q } = useNuxtApp();
const { signOut } = useAuth();

const { t } = useI18n();

definePageMeta({ title: 'Administração / Perfis' });

/** DATA */

const mask = {
  wordAndNumber: MaskHelper.Mask.WordAndNumber(30),
  cpf: MaskHelper.Mask.Cpf
};

const notifyStore = useNotifyStore();

const rolesStore = useRolesStore();

const tab = ref({
  selected: 0,
  tabs: ['Funcionalidades', 'Associação de usuários']
});

const dialog = ref<boolean>(false);

const profileTable = ref({
  selected: [] as DeleteProfileDTO.Request,
  columns: [
    {
      name: 'name',
      field: 'name',
      label: 'Perfil',
      align: 'left'
    },
    {
      name: 'description',
      field: 'description',
      align: 'left',
      label: 'Descrição',
      style: 'word-break: break-all; white-space: pre-line !important;'
    },
    {
      name: 'application',
      field: 'application',
      label: 'Aplicação',
      align: 'center',
      format: (val: string) => `${t(val)}`
    },
    {
      name: 'action',
      field: 'action',
      label: 'Ações',
      align: 'center',
      style: 'width: 100px'
    }
  ] as Column[],
  rows: [] as GetAllProfilesDTO.Profile[] | []
});

const userTable = ref({
  columns: [
    {
      name: 'name',
      field: 'name',
      label: 'Nome',
      align: 'left'
    },

    {
      name: 'cpf',
      field: 'cpf',
      align: 'left',
      label: 'CPF'
    }
  ] as Column[],
  rows: [] as GetAllUsersDTO.Profile[] | [],
  unassigned: [] as GetAllUsersDTO.Profile[] | []
});

const userAssignedTable = ref({
  columns: [
    {
      name: 'name',
      field: 'name',
      label: 'Nome',
      align: 'left'
    },
    {
      name: 'cpf',
      field: 'cpf',
      align: 'left',
      label: 'CPF'
    }
  ] as Column[],

  rows: [] as GetAllUsersDTO.Profile[] | []
});

const showModal = ref<boolean>(false);

const loading = ref({
  profiles: false as boolean,
  profile: false as boolean,
  submit: false as boolean,
  users: false as boolean,
  functionalities: false as boolean,
  delete: false as boolean,
  getProfile: false as boolean
});

const profile = ref({
  id: undefined as string | undefined,
  name: undefined as string | undefined,
  description: undefined as string | undefined,
  application: undefined as ProfileTypeKey | undefined
  // assignedUsers: undefined as AddProfileDTO.AssignedUser | undefined
});

const assignedUsers = ref({
  re: undefined as string | undefined,
  cpf: undefined as string | undefined
});

const searchProfile = ref<string | undefined>(undefined);
const applicationSearchProfile = ref<string | undefined>(undefined);

const applications = [
  { label: 'Interna', value: ProfileType.Internal }
  // { label: 'Externa', value: ProfileType.External }
];

const tabSelected = computed(() => {
  return tab.value.selected;
});

const formSubmit = ref<boolean | undefined>(undefined);

const functionalitiesSelected = ref<string[] | []>([]);

const functionalities = ref<GetAllFunctionalitiesDTO.Functionality[] | []>([]);

const dialogAction = ref<ActionKey>(ActionType.ADD);

/** ESSENTIALS */

watch(tabSelected, value => {
  if (value === 0) {
    clearTabs('functionalities');
    return;
  }
  clearTabs('assigned');
});

watch(dialog, value => {
  if (!value) {
    clearData();
  }
});

onMounted(async () => {
  await getAllProfiles();
  // await getAllFunctionalities();
});

const canDelete = computed(() => {
  return rolesStore.existRoles(RoleEnum.Profile.Delete);
});

const canSave = computed(() => {
  return rolesStore.existRoles(RoleEnum.Profile.Post);
});

const canUpdate = computed(() => {
  return rolesStore.existRoles(RoleEnum.Profile.Put);
});

const canGetUserByName = computed(() => {
  return rolesStore.existRoles(RoleEnum.Profile.GetByName);
});

const canList = computed(() => {
  return rolesStore.existRoles(RoleEnum.Profile.Get);
});

const canGetUsers = computed(() => {
  return rolesStore.existRoles(RoleEnum.User.Get);
});

const isAbout = computed(() => {
  return dialogAction.value === ActionType.ABOUT;
});

const isEdit = computed(() => {
  return dialogAction.value === ActionType.EDIT;
});

const dialogTitle = computed(() => {
  const action = dialogAction.value;

  return TitleType[action];
});

const canUseDeleteButton = computed(() => {
  const selected = profileTable.value.selected;

  return !(Helper.isDefined(selected) && selected.length > 0);
});

const customMessageConfirmDelete = computed(() => {
  const selected = profileTable.value.selected;

  return Helper.isDefined(selected) && selected.length > 1
    ? 'Deseja deletar o(s) perfil(is)?'
    : 'Deseja deletar o perfil?';
});

const customMessageProfileDeleted = computed(() => {
  const selected = profileTable.value.selected;

  return Helper.isDefined(selected) && selected.length > 1
    ? 'Perfi(is) deletado(s) com sucesso'
    : 'Perfil deletado com sucesso';
});

const haveFunctionalitiesSelected = computed(() => {
  return (
    Array.isArray(functionalitiesSelected.value) &&
    functionalitiesSelected.value.length > 0
  );
});
/** METHODS */

function showNotify(value: { type: StatusTypeKey; message: string }) {
  notifyStore.toggleNotify();
  notifyStore.toggleNotify({
    type: value.type,
    message: value.message
  });
}

function removeAssignedUSers(value: GetAllUsersDTO.Profile) {
  if (Helper.isDefined(value) && Helper.isDefined(value.id)) {
    const index = userAssignedTable.value.rows.findIndex(
      i => i.id === value.id
    );
    userAssignedTable.value.rows.splice(index, 1);

    const { id, assigned, cpf, name, profile, re } = value;
    const user: GetAllUsersDTO.Profile = {
      id,
      cpf,
      re,
      name,
      profile,
      assigned: !assigned
    };
    userTable.value.rows.push(user);
    userTable.value.unassigned.push(user);
  }
}
function addAssignedUSers(value: GetAllUsersDTO.Profile) {
  if (Helper.isDefined(value) && Helper.isDefined(value.id)) {
    const indexUserTable = userTable.value.rows.findIndex(
      i => i.id === value.id
    );
    userTable.value.rows.splice(indexUserTable, 1);

    const indexUnassingnedUser = userTable.value.rows.findIndex(
      i => i.id === value.id
    );
    userTable.value.unassigned.splice(indexUnassingnedUser, 1);

    const { id, assigned, cpf, name, profile, re } = value;
    const user: GetAllUsersDTO.Profile = {
      id,
      cpf,
      re,
      name,
      profile,
      assigned: !assigned
    };
    userAssignedTable.value.rows.push(user);
  }
}

async function clearTabs(value?: 'assigned' | 'functionalities') {
  if (value === 'assigned' || Helper.isNotDefined(value)) {
    assignedUsers.value.cpf = undefined;
    assignedUsers.value.re = undefined;
    userAssignedTable.value.rows = [];
    userTable.value.rows = [];
  }
  if (value === 'functionalities' || Helper.isNotDefined(value)) {
    await getAllFunctionalities();
  }
}

function clearData() {
  clearTabs();
  profile.value.name = undefined;
  profile.value.description = undefined;
  profile.value.application = undefined;
  profile.value.id = undefined;
  functionalitiesSelected.value = [];
  assignedUsers.value.cpf = undefined;
  assignedUsers.value.re = undefined;
  userAssignedTable.value.rows = [];
  userTable.value.rows = [];

  tab.value.selected = 0;
}

async function getAllProfiles() {
  if (canList.value) {
    profileTable.value.rows = [];
    // const res = await getAllProfilesUseCase.execute();
    loading.value.profiles = true;
    const res = await $UseCase.Profile.GetAllProfiles.execute();
    loading.value.profiles = false;
    if (res.isLeft()) {
      const code = res.value.errorValue().code;

      if (code === ErrorCodeEnum.AccessDenied) {
        await signOut({
          redirect: true,
          callbackUrl: `http://intranet.policiamilitar.sp.gov.br/`
        });
      }

      if (code === ErrorCodeEnum.NotFound) {
        return;
      }
      showNotify({
        type: StatusType.ERROR,
        message: 'Ocorreu um erro ao listar perfis!'
      });

      return;
    }
    const profiles = res.value.getValue();
    profileTable.value.rows = profiles;
  } else {
    await signOut({
      redirect: true,
      callbackUrl: `http://intranet.policiamilitar.sp.gov.br/`
    });
  }
}

async function getAllUsers() {
  if (
    Helper.isDefined(assignedUsers.value.cpf) ||
    Helper.isDefined(assignedUsers.value.re)
  ) {
    userTable.value.rows = [];

    const type = Helper.isNotEmpty(assignedUsers.value.cpf)
      ? FilterType.CPF
      : FilterType.RE;
    const value = Helper.isNotEmpty(assignedUsers.value.cpf)
      ? assignedUsers.value.cpf
      : assignedUsers.value.re;

    const input = {
      type,
      value,
      profile: {
        id: profile.value?.id
      }
    };

    loading.value.users = true;
    const res = await $UseCase.Users.GetAllUsers.execute(input);
    loading.value.users = false;
    if (res.isLeft()) {
      const code = res.value.errorValue().code;

      if (code === ErrorCodeEnum.AccessDenied) {
        await signOut({
          redirect: true,
          callbackUrl: `http://intranet.policiamilitar.sp.gov.br/`
        });
      }

      if (code === ErrorCodeEnum.NotFound) {
        return;
      }

      showNotify({
        type: StatusType.ERROR,
        message: 'Ocorreu um erro ao listar usuários!'
      });

      return;
    }
    const users = res.value.getValue();
    userTable.value.rows = users.unassigned;
    userAssignedTable.value.rows = users.assigned;
  }
}

async function searchProfiles() {
  if (
    (Helper.isNotEmpty(searchProfile.value) &&
      Helper.isDefined(searchProfile.value)) ||
    (Helper.isNotEmpty(applicationSearchProfile.value) &&
      Helper.isDefined(applicationSearchProfile.value))
  ) {
    const input = {
      profile: searchProfile.value,
      application:
        applicationSearchProfile.value === 'Internal'
          ? ProfileType.Internal
          : ProfileType.External
    };
    loading.value.getProfile = true;
    const res = await $UseCase.Profile.GetProfile.execute(input);
    loading.value.getProfile = false;

    if (res.isLeft()) {
      const code = res.value.errorValue().code;

      if (code === ErrorCodeEnum.BadRequest) {
        showNotify({
          type: StatusType.WARNING,
          message: 'Perfil não encontrado!'
        });
        return;
      }

      if (code === ErrorCodeEnum.AccessDenied) {
        await signOut({
          redirect: true,
          callbackUrl: `http://intranet.policiamilitar.sp.gov.br/`
        });
      }

      if (code === ErrorCodeEnum.NotFound) {
        return;
      }

      showNotify({
        type: StatusType.ERROR,
        message: 'Ocorreu um erro ao listar usuários!'
      });

      return;
    }
    const profileDetails = res.value.getValue();
    profileTable.value.rows = profileDetails;
    return;
  }
  await getAllProfiles();
}

async function searchUsers() {
  if (
    (Helper.isDefined(assignedUsers.value.cpf) &&
      Helper.isNotEmpty(assignedUsers.value.cpf)) ||
    (Helper.isDefined(assignedUsers.value.re) &&
      Helper.isNotEmpty(assignedUsers.value.re))
  ) {
    await getAllUsers();
  } else {
    showNotify({
      type: StatusType.WARNING,
      message: 'Informe pelo menos um parâmetro de busca'
    });
  }
}

async function getProfileByName(
  value: GetProfileByNameDTO.Request
): Promise<GetProfileByNameDTO.ResponseBody | void> {
  const input = {
    profile: value.profile
  };
  loading.value.getProfile = true;
  const res = await $UseCase.Profile.GetProfileByName.execute(input);
  loading.value.getProfile = false;

  if (res.isLeft()) {
    const code = res.value.errorValue().code;

    if (code === ErrorCodeEnum.BadRequest) {
      showNotify({
        type: StatusType.WARNING,
        message: 'Perfil não encontrado!'
      });
      return;
    }

    if (code === ErrorCodeEnum.AccessDenied) {
      await signOut({
        redirect: true,
        callbackUrl: `http://intranet.policiamilitar.sp.gov.br/`
      });
    }

    if (code === ErrorCodeEnum.NotFound) {
      return;
    }

    showNotify({
      type: StatusType.ERROR,
      message: 'Ocorreu um erro ao listar usuários!'
    });

    return;
  }
  const profileDetails = res.value.getValue();
  profile.value.id = profileDetails.id;
  profile.value.name = profileDetails.name;
  profile.value.description = profileDetails.description;
  profile.value.application = profileDetails.application;
  functionalitiesSelected.value = profileDetails.functionalities;

  return profileDetails;
}

async function deleteProfile(value: DeleteProfileDTO.Request) {
  if (Array.isArray(value) && value.length > 0) {
    const input = value.map(i => {
      return {
        name: i.name
      };
    });
    loading.value.delete = true;
    const res = await $UseCase.Profile.DeleteProfile.execute(input);
    loading.value.delete = false;

    if (res.isLeft()) {
      const code = res.value.errorValue().code;

      if (code === ErrorCodeEnum.AccessDenied) {
        await signOut({
          redirect: true,
          callbackUrl: `http://intranet.policiamilitar.sp.gov.br/`
        });
      }
      showNotify({ type: StatusType.ERROR, message: 'Ocorreu um erro!' });
      return;
    }
    showNotify({
      type: StatusType.SUCCESS,
      message: customMessageProfileDeleted.value
    });
  }
}

async function addProfile() {
  if (
    Helper.isDefined(profile.value.name) &&
    Helper.isDefined(profile.value.application)
  ) {
    const input = {
      name: profile.value.name,
      description: profile.value?.description,
      application: profile.value.application,
      assignedUsers: JSON.parse(JSON.stringify(userAssignedTable.value.rows)),
      functionalities: JSON.parse(JSON.stringify(functionalitiesSelected.value))
    };

    loading.value.submit = true;
    const res = await $UseCase.Profile.AddProfile.execute(input);
    loading.value.submit = false;

    if (res.isLeft()) {
      const code = res.value.errorValue().code;

      if (code === ErrorCodeEnum.AccessDenied) {
        await signOut({
          redirect: true,
          callbackUrl: `http://intranet.policiamilitar.sp.gov.br/`
        });
      }

      if (code === ErrorCodeEnum.BadRequest) {
        showNotify({
          type: StatusType.WARNING,
          message: 'Este nome já está sendo utilizado por outro perfil'
        });
        return;
      }
      showNotify({ type: StatusType.ERROR, message: 'Ocorreu um erro!' });
      return;
    }
    showNotify({
      type: StatusType.SUCCESS,
      message: 'Salvo com sucesso!'
    });
    toggleDialog({ show: false });
    await getAllProfiles();
  }
}

async function updateProfile() {
  if (
    Helper.isDefined(profile.value.name) &&
    Helper.isDefined(profile.value.application)
  ) {
    const assignedUsers = [
      ...JSON.parse(JSON.stringify(userAssignedTable.value.rows)),
      ...JSON.parse(JSON.stringify(userTable.value.unassigned))
    ];
    const input = {
      name: profile.value.name,
      description: profile.value.description,
      application: profile.value.application,
      assignedUsers,
      functionalities: JSON.parse(JSON.stringify(functionalitiesSelected.value))
    };

    loading.value.submit = true;
    const res = await $UseCase.Profile.UpdateProfile.execute(input);
    loading.value.submit = false;

    if (res.isLeft()) {
      const code = res.value.errorValue().code;

      if (code === ErrorCodeEnum.AccessDenied) {
        await signOut({
          redirect: true,
          callbackUrl: `http://intranet.policiamilitar.sp.gov.br/`
        });
      }
      showNotify({ type: StatusType.ERROR, message: 'Ocorreu um erro!' });

      return;
    }
    showNotify({
      type: StatusType.SUCCESS,
      message: 'Atualizado com sucesso!'
    });
    toggleDialog({ show: false });
    await getAllProfiles();
  }
}

async function validate(): Promise<boolean> {
  // @ts-ignore
  return await formSubmit.value.validate().then((success: any) => {
    if (success) {
      return true;
    }
    return false;
  });
}

async function submit() {
  const isValidate = await validate();
  if (isValidate) {
    if (!haveFunctionalitiesSelected.value) {
      showNotify({
        type: StatusType.WARNING,
        message: 'Informe ao menos uma funcionalidade!'
      });
      return;
    }

    if (Helper.isDefined(profile.value.id)) {
      await updateProfile();
      return;
    }
    await addProfile();
  }
}

async function openDialogWithProfileSelected(value: {
  item: string;
  action?: ActionKey;
}) {
  if (value.item) {
    toggleDialog({ show: true, action: value.action });
    await getProfileByName({ profile: value.item });
  }
}

function showConfirmActionDeleteProfile(value: {
  show: boolean;
  item?: DeleteProfileDTO.Request;
}) {
  profileTable.value.selected = value?.item ?? [];

  if (!canUseDeleteButton.value || value.show === false) {
    showModal.value = value?.show;
  } else {
    showNotify({
      type: StatusType.WARNING,
      message: 'Nenhum perfil selecionado'
    });
  }
}

async function deleteSelectedProfiles() {
  const selected = profileTable.value.selected;

  await deleteProfile(JSON.parse(JSON.stringify(selected)));
  showConfirmActionDeleteProfile({ show: false });
  await getAllProfiles();
}
async function toggleDialog(value: { show: boolean; action?: ActionKey }) {
  const show = value.show;
  const action = value?.action ?? ActionType.ADD;
  dialog.value = show;

  if (show === true) {
    await getAllFunctionalities();
    dialogAction.value = action;
  }

  // if (action === ActionType.ADD) {
  //   clearData();
  // }
}

async function getAllFunctionalities() {
  loading.value.functionalities = true;
  const res = await $UseCase.Functionalities.GetAllFunctionalities.execute();
  loading.value.functionalities = false;

  if (res.isLeft()) {
    const code = res.value.errorValue().code;

    if (code === ErrorCodeEnum.NotFound) {
      return;
    }

    showNotify({
      type: StatusType.ERROR,
      message: 'Ocorreu um erro ao listar as Funcionalidades!'
    });

    return;
  }
  const resFunctionalities = res.value.getValue();

  functionalities.value = resFunctionalities;
}
</script>

<style lang="scss" scoped></style>
