<template>
  <AdminPage>
    <div class="row q-mt-md">
      <div class="col-12">
        <UiAtomTable
          id="table-profiles"
          :columns="termConfidentialityTable.columns"
          :rows="termConfidentialityTable.rows"
          :hide-bottom="$q.screen.lt.sm"
          :hide-header="$q.screen.lt.sm"
          :bordered="$q.screen.lt.sm"
          :loading="loading.termConfidentiality"
          :grid="$q.screen.lt.sm"
          row-key="id"
        >
          <template #body-cell-action="props">
            <q-td :props="props">
              <UiAtomIcon
                v-if="canDetails"
                id="icon-search"
                icon="search"
                size="sm"
                cursor-pointer
                @click="
                  openDialogWithIconSelected({
                    action: 'about',
                    value: props.row.id
                  })
                "
              ></UiAtomIcon>
              <UiAtomIcon
                v-if="canUpdate"
                id="icon-edit"
                icon="edit"
                size="sm"
                cursor-pointer
                @click="
                  openDialogWithIconSelected({
                    action: 'edit',
                    value: props.row.id
                  })
                "
              ></UiAtomIcon>
              <UiAtomIcon
                v-if="hideButtonWithPermission"
                id="icon-remove"
                name="close"
                size="sm"
                cursor-pointer
                @click="
                  showApprovalStatus({
                    show: true,
                    action: ApproveType.REJECT
                  })
                "
              ></UiAtomIcon>
              <UiAtomIcon
                v-if="hideButtonWithPermission"
                id="icon-check"
                name="done"
                size="sm"
                cursor-pointer
                @click="
                  showApprovalStatus({
                    show: true,
                    action: ApproveType.APPROVE
                  })
                "
              ></UiAtomIcon>
            </q-td>
          </template>
        </UiAtomTable>
      </div>
    </div>
  </AdminPage>
  <UiMoleculeDialog v-model="dialog">
    <template #title>Termo de Confidencialidade</template>
    <template #content>
      <template v-if="loading.getTermGridById">
        <UiAtomCircularProgress></UiAtomCircularProgress
      ></template>
      <div v-else class="row">
        <div class="col-12 q-pa-sm">
          <q-form ref="formSubmit" class="q-gutter-md">
            <div v-if="!isEdit" class="q-mb-lg">
              <div class="q-mb-md">
                <UiAtomText id="text-term-date" bold
                  >Data/Hora da Alteração:
                </UiAtomText>
                {{ termConfidentiality.updateRequestAt }}
              </div>
              <div>
                <UiAtomText id="text-term-user-name" bold
                  >Responsável: </UiAtomText
                >{{ termConfidentiality.updateRequestOwner }}
              </div>
            </div>
            <div v-else class="q-mb-md">
              <div>
                <UiAtomText id="text-term-text" color="negative" bold
                  >O conteúdo do termo de confidencialidade será visualizado por
                  todo usuário que acessar a plataforma.
                </UiAtomText>
              </div>
              <div>
                <UiAtomText id="text-date-text-2" color="negative" bold
                  >A utilização da plataforma será permitido apenas para aqueles
                  que concordarem com os termos descritos abaixo.</UiAtomText
                >
              </div>
            </div>
            <UiAtomEditor
              id="skeditor"
              v-model="term.content"
              label="Termo de Confidencialidade *"
              height="400px"
              :disable="isAbout"
              :rules="[
                (val: any) =>
                  (val &&
                    val.length > 0) ||
                  'Campo obrigatório!'
              ]"
            />
            <div
              v-if="isAbout && hideButtonWithPermission"
              class="row justify-center"
            >
              <UiAtomButton
                id="button-close-dialog"
                label="REJEITAR"
                color="red"
                class="q-mr-xl"
                bold
                @click="
                  showApprovalStatus({
                    show: true,
                    action: ApproveType.REJECT
                  })
                "
              ></UiAtomButton>
              <UiAtomButton
                id="button-prodile-add-new"
                label="APROVAR"
                color="green"
                @click="
                  showApprovalStatus({
                    show: true,
                    action: ApproveType.APPROVE
                  })
                "
              ></UiAtomButton>
            </div>
          </q-form>
        </div>
      </div>
    </template>
    <template #actions>
      <UiAtomButton
        id="button-term-close-dialog"
        label="VOLTAR"
        outline
        bold
        @click="toggleDialog({ show: false })"
      ></UiAtomButton>
      <UiAtomButton
        v-if="!isAbout"
        id="button-term-add-new"
        label="SALVAR"
        :loading="loading.submit"
        @click="handleSave"
      ></UiAtomButton>
    </template>
  </UiMoleculeDialog>
  <UiOrganismBaseModal v-model="showApprovalStatusModal" persistent>
    <template #header>Confirmar ação?</template>
    <div>
      <div>
        <UiAtomText id="text-date">Data/Hora da Alteração: </UiAtomText>
        {{ termConfidentiality.updateRequestAt }}
      </div>
      <div>
        <UiAtomText id="text-user-name">Responsável: </UiAtomText
        >{{ termConfidentiality.updateRequestOwner }}
      </div>
      <div>
        <UiAtomText id="text-action">Ação: </UiAtomText
        >{{ approvalStatus === ApproveType.APPROVE ? 'Aprovar' : 'Rejeitar' }}
      </div>
      <q-form ref="formSubmitReason">
        <div
          v-if="approvalStatus === ApproveType.REJECT"
          class="col-12 q-mt-sm"
        >
          <UiAtomInputText
            id="input-text-reason"
            v-model="reason"
            label="*Motivo"
            max-length="50"
            type="textarea"
            :rules="[
                (val: any) =>
                  (val &&
                    val.length > 0) ||
                  'Campo obrigatório!'
              ]"
            height="100px"
          ></UiAtomInputText>
        </div>
      </q-form>
    </div>
    <template #footer>
      <UiAtomButton
        id="button-modal-cancel-action"
        label="CANCELAR"
        outline
        bold
        @click="showApprovalStatus({ show: false })"
      ></UiAtomButton>
      <UiAtomButton
        id="button-modal-confirm-action"
        label="CONFIRMAR"
        class="q-ml-xs"
        :loading="loading.approveTerm"
        @click="handleApprovalTerm"
      ></UiAtomButton>
    </template>
  </UiOrganismBaseModal>
</template>

<script setup lang="ts">
import { Helper } from '@pmesp/logic/dist/core/helpers/Helper';
import { ErrorCodeEnum } from '@pmesp/logic/dist/core/enums/ErrorCodeEnum';
import { ApproveType } from '@pmesp/logic/dist/modules/term/enums/TermTypeEnum';
import { RoleEnum } from '@pmesp/logic/dist/modules/functionality/enums/RoleEnum';
import { GetTermGridByIdDTO } from '@pmesp/logic/dist/modules/term/use-cases/GetTermGridById/GetTermGridByIdDTO';
import { GetTermGridDTO } from '@pmesp/logic/dist/modules/term/use-cases/GetTermGrid/GetTermGridDTO';
import { Column } from '../../../../../../lib/ui/components/v1/atom/table/UiAtomTable.vue';
import { StatusType, StatusTypeKey, useNotifyStore } from '~/store/notify';
import { useRolesStore } from '~/store/roles';
definePageMeta({ title: 'Administração / Termo de Confidencialidade' });
const { getSession } = useAuth();
const session = await getSession({ required: true });

const { $UseCase, $q } = useNuxtApp();
const { signOut } = useAuth();

const notifyStore = useNotifyStore();

function showNotify(value: { type: StatusTypeKey; message: string }) {
  notifyStore.toggleNotify();
  notifyStore.toggleNotify({
    type: value.type,
    message: value.message
  });
}

// type & interfaces
enum ActionType {
  ABOUT = 'about',
  ADD = 'add',
  EDIT = 'edit'
}
export type ActionKey = `${ActionType}`;

const loading = ref({
  termConfidentiality: false as boolean,
  submit: false as boolean,
  approveTerm: false as boolean,
  getTermGridById: false as boolean
});

const dialog = ref<boolean>(false);

const formSubmit = ref<boolean | undefined>(undefined);

const formSubmitReason = ref<boolean | undefined>(undefined);

const dialogAction = ref<ActionKey>(ActionType.ADD);

const term = ref({
  id: undefined as string | undefined,
  name: undefined as string | undefined,
  content: '' as string
});

const showApprovalStatusModal = ref<boolean>(false);

const approvalStatus = ref<ApproveType>();

const reason = ref<string>();

const termConfidentialityTable = ref({
  columns: [
    {
      name: 'name',
      field: 'name',
      label: 'Nome',
      align: 'left'
    },
    {
      name: 'approvedAt',
      field: 'approvedAt',
      align: 'left',
      label: 'Data Última Edição Aprovada'
    },
    {
      name: 'updateRequestAt',
      field: 'updateRequestAt',
      label: 'Data/Hora da Última Edição Pendente de Aprovação',
      align: 'left'
    },
    {
      name: 'updateRequestOwner',
      field: 'updateRequestOwner',
      label: 'Responsável pela Última Edição',
      align: 'left'
    },
    {
      name: 'action',
      field: 'action',
      label: 'Ações',
      align: 'center'
    }
  ] as Column[],
  rows: [] as GetTermGridDTO.ResponseBody | []
});

const rolesStore = useRolesStore();

onMounted(async () => {
  await getTermGrid();
});

const termConfidentiality = computed(() => {
  return termConfidentialityTable.value.rows[0];
});

const canUpdate = computed(() => {
  return rolesStore.existRoles(RoleEnum.AcceptanceTerms.Put);
});

const canDetails = computed(() => {
  return rolesStore.existRoles(RoleEnum.AcceptanceTerms.GetById);
});

const canApprove = computed(() => {
  return rolesStore.existRoles(RoleEnum.AcceptanceTerms.Approve);
});

const isEdit = computed(() => {
  return dialogAction.value === ActionType.EDIT;
});

const isAbout = computed(() => {
  return dialogAction.value === ActionType.ABOUT;
});

const hideButtonWithPermission = computed(() => {
  return !!(
    canApprove.value &&
    termConfidentiality?.value.hasUpdateRequest &&
    termConfidentiality?.value.updateRequestOwner !== session.user?.name
  );
});

async function openDialogWithIconSelected(term: {
  action: ActionKey;
  value: string;
}) {
  if (Helper.isDefined(term.value)) {
    toggleDialog({ show: true, action: term.action });
    await getTermGridById({ id: term.value });
  }
}

function toggleDialog(value: { show: boolean; action?: ActionKey }) {
  const show = value.show;
  const action = value?.action ?? ActionType.ADD;
  dialog.value = show;
  if (show === true) {
    dialogAction.value = action;
  }
}

async function validate(): Promise<boolean> {
  // @ts-ignore
  return await formSubmit.value.validate().then((success: any) => {
    if (success) {
      return true;
    }
    return false;
  });
}

async function validateReason(): Promise<boolean> {
  // @ts-ignore
  return await formSubmitReason.value.validate().then((success: any) => {
    if (approvalStatus.value === ApproveType.APPROVE || success) {
      return true;
    }
    return false;
  });
}

async function getTermGrid() {
  termConfidentialityTable.value.rows = [];

  loading.value.termConfidentiality = true;
  const res = await $UseCase.Term.GetTermGrid.execute();
  loading.value.termConfidentiality = false;

  if (res.isLeft()) {
    const code = res.value.errorValue().code;

    if (code === ErrorCodeEnum.AccessDenied) {
      await signOut({
        redirect: true,
        callbackUrl: `http://intranet.policiamilitar.sp.gov.br/`
      });
    }

    if (code === ErrorCodeEnum.NotFound) {
      return;
    }
    showNotify({
      type: StatusType.ERROR,
      message: 'Ocorreu um erro ao listar informações!'
    });

    return;
  }
  const term = res.value.getValue();

  termConfidentialityTable.value.rows = term;
}

async function getTermGridById(
  value: GetTermGridByIdDTO.Request
): Promise<GetTermGridByIdDTO.ResponseBody | void> {
  if (Helper.isDefined(value.id)) {
    const input = {
      id: value.id
    };
    loading.value.getTermGridById = true;
    let res = await $UseCase.Term.GetTermGridById.execute(input);
    loading.value.getTermGridById = false;

    if (res.isLeft()) {
      const code = res.value.errorValue().code;

      if (code === ErrorCodeEnum.BadRequest) {
        showNotify({
          type: StatusType.WARNING,
          message: 'Template de E-mail não encontrado!'
        });
        return;
      }
      if (code === ErrorCodeEnum.AccessDenied) {
        await signOut({
          redirect: true,
          callbackUrl: `http://intranet.policiamilitar.sp.gov.br/`
        });
      }

      if (code === ErrorCodeEnum.NotFound) {
        return;
      }

      showNotify({
        type: StatusType.ERROR,
        message: 'Ocorreu um erro ao listar template de e-mail!'
      });

      return;
    }
    res = res.value.getValue();
    term.value.content = res.content;
  }
}

async function handleSave() {
  const isValidate = await validate();

  if (isValidate && Helper.isDefined(term.value.content)) {
    const input = {
      content: term.value.content
    };

    loading.value.submit = true;
    const res = await $UseCase.Term.UpdateTermContent.execute(input);
    loading.value.submit = false;

    if (res.isLeft()) {
      const code = res.value.errorValue().code;

      if (code === ErrorCodeEnum.AccessDenied) {
        await signOut({
          redirect: true,
          callbackUrl: `http://intranet.policiamilitar.sp.gov.br/`
        });
      }
      showNotify({ type: StatusType.ERROR, message: 'Ocorreu um erro!' });
      return;
    }
    showNotify({
      type: StatusType.SUCCESS,
      message: 'Editado com sucesso!'
    });
    toggleDialog({ show: false });
    await getTermGrid();
  }
}

function showApprovalStatus(value: { show: boolean; action?: ApproveType }) {
  showApprovalStatusModal.value = value?.show;
  approvalStatus.value = value.action;
}

async function handleApprovalTerm() {
  const isValidate = await validateReason();
  if (Helper.isDefined(approvalStatus) && isValidate) {
    loading.value.approveTerm = true;

    const input = {
      id: termConfidentiality.value.id,
      action: approvalStatus.value,
      reason: reason.value
    };
    const res = await $UseCase.Term.ApproveTerm.execute(input);
    loading.value.approveTerm = false;

    if (res.isLeft()) {
      const code = res.value.errorValue().code;

      if (code === ErrorCodeEnum.AccessDenied) {
        await signOut({
          redirect: true,
          callbackUrl: `http://intranet.policiamilitar.sp.gov.br/`
        });
      }
      if (code === ErrorCodeEnum.BadRequest) {
        showNotify({
          type: StatusType.WARNING,
          message: 'Usuário responsável pela alteração não pode ser aprovador!'
        });
        return;
      }
      showNotify({ type: StatusType.ERROR, message: 'Ocorreu um erro!' });
      return;
    }
    showNotify({
      type: StatusType.SUCCESS,
      message:
        approvalStatus.value === ApproveType.APPROVE
          ? 'Aprovado com sucesso!'
          : 'Rejeitado com sucesso!'
    });
    showApprovalStatus({ show: false });
    toggleDialog({ show: false });
    reason.value = undefined;
    await getTermGrid();
  }
}
</script>
<style lang="scss" scoped>
.q-scroll-area-variables {
  height: 170px;
}

@media only screen and (max-width: 900px) {
  .q-scroll-area-variables {
    height: 200px;
  }
}
</style>
