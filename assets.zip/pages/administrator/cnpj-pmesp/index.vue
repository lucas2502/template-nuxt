<template>
  <AdminPage>
    <div class="row q-mt-md">
      <div class="col-12">
        <UiAtomTable
          id="table-profiles-cnpj"
          :columns="table.columns"
          :rows="table.rows"
          :hide-bottom="$q.screen.lt.sm"
          :hide-header="$q.screen.lt.sm"
          :bordered="$q.screen.lt.sm"
          :loading="loading.allCompanies"
          :grid="$q.screen.lt.sm"
          row-key="id"
          wrap-cells
        >
          <template #body-cell-principal="props">
            <q-td :props="props">
              <UiAtomIcon
                id="icon-search-cnpj"
                :color="props.row.isMainCnpj ? 'yellow' : 'grey'"
                icon="grade"
                size="sm"
                cursor-pointer
                @click="
                  props.row.isMainCnpj
                    ? undefined
                    : handleCickStar({ show: true, id: props.row.id })
                "
              ></UiAtomIcon>
            </q-td>
          </template>
          <template #body-cell-phones="props">
            <q-td :props="props">
              <div v-for="phone in props.row.phone" :key="phone">
                {{ phone }}
              </div>
            </q-td>
          </template>
          <template #body-cell-action="props">
            <q-td :props="props">
              <UiAtomIcon
                v-if="canDetails"
                id="icon-search-action-cnpj"
                icon="search"
                size="sm"
                cursor-pointer
                @click="
                  openDialogSelected({
                    item: props.row.id,
                    action: 'about'
                  })
                "
              ></UiAtomIcon>
              <UiAtomIcon
                v-if="canEdit"
                id="icon-edit-action-cnpj"
                icon="edit"
                size="sm"
                cursor-pointer
                @click="
                  openDialogSelected({
                    item: props.row.id,
                    action: 'edit'
                  })
                "
              ></UiAtomIcon>
              <UiAtomIcon
                v-if="canDelete"
                id="icon-remove-action-cnpj"
                name="close"
                size="sm"
                cursor-pointer
                @click="
                  openDialogSelected({
                    item: props.row.id,
                    action: 'delete'
                  })
                "
              ></UiAtomIcon>
            </q-td>
          </template>
        </UiAtomTable>
      </div>
    </div>
    <template #actions>
      <UiAtomButton
        v-if="canSave"
        id="button-prodile-add-cnpj"
        label="ADICIONAR"
        class="q-ml-xs"
        @click="toggleDialog({ show: true })"
      ></UiAtomButton>
    </template>
  </AdminPage>
  <UiMoleculeDialog v-if="!isDelete" v-model="dialog">
    <template #title>Adicionar CNPJs?</template>
    <template #content>
      <template v-if="loading.companyById">
        <UiAtomCircularProgress></UiAtomCircularProgress>
      </template>
      <template v-else>
        <q-form ref="formSubmit">
          <div class="row q-mb-lg">
            <div class="col-5">
              <UiAtomInputText
                id="input-text-term-cnpj"
                v-model="companyData.cnpj"
                label="*CNPJ"
                max-length="18"
                mask="##.###.###/####-##"
                :disable="isAbout"
                :rules="[
                  (val: any) => !val || val.length === 0 ? 'Campo obrigatório!' : !Helper.isValidCnpj(val) ? 'CNPJ inválido!' : true
                ]"
              />
            </div>
          </div>
          <div class="row q-mb-lg">
            <div class="col-5 q-mr-lg">
              <UiAtomInputText
                id="input-text-term-legal-name-cnpj"
                v-model="companyData.legalName"
                label="*Razão Social"
                max-length="100"
                :disable="isAbout"
                :rules="[
                  (val: any) => (val && val.length > 0) || 'Campo obrigatório!'
                ]"
              />
            </div>
            <div class="col-5">
              <UiAtomInputText
                id="input-text-term-trade-name-cnpj"
                v-model="companyData.tradeName"
                label="*Título do Estabelecimento (Nome de Fantasia)"
                max-length="100"
                :disable="isAbout"
                :rules="[
                  (val: any) => (val && val.length > 0) || 'Campo obrigatório!'
                ]"
              />
            </div>
          </div>
          <div class="row q-mb-lg">
            <div class="q-col-auto col-5 q-mr-lg">
              <UiAtomInputText
                id="input-text-term-economic-activity-code-cnpj"
                v-model="companyData.economicActivityCode"
                label="*Código da Atividade Econômica Principal"
                max-length="10"
                mask="xx.xx-x-xx"
                :disable="isAbout"
                :rules="[
                  (val: any) => (val && val.length > 0) || 'Campo obrigatório!'
                ]"
              />
            </div>
            <div class="q-col-auto col-5">
              <UiAtomInputText
                id="input-text-term-legal-nature-code-cnpj"
                v-model="companyData.legalNatureCode"
                label="*Código de Natureza Jurídica"
                max-length="5"
                mask="xxx-x"
                :disable="isAbout"
                :rules="[
                  (val: any) => (val && val.length > 0) || 'Campo obrigatório!'
                ]"
              />
            </div>
          </div>

          <!-- Email -->
          <div class="row q-mb-lg">
            <div class="q-col-auto col-5 q-mr-lg">
              <UiAtomInputText
                :id="'input-text-email-cnpj'"
                v-model="companyData.email"
                label="*Email"
                max-length="100"
                :disable="isAbout"
                :rules="[
                  (val: any) => !val || val.length === 0 ? 'Campo obrigatório!' : !Helper.isValidEmail(val) ? 'E-mail inválido!' : true
                ]"
              />
            </div>
          </div>

          <!-- Telefones -->
          <div class="row q-mb-lg">
            <div class="col-9">
              <UiAtomInputText
                id="input-phone-chip-cnpj"
                v-model="phoneChip"
                label="*Telefones"
                :disable="isAbout"
                mask="(xx) xxxx-xxxx"
                max-length="14"
                :rules="[
                  () => companyData.phones.length > 0 || 'Campo obrigatório!'
                ]"
              ></UiAtomInputText>
            </div>
            <div class="col-2 q-pt-xs">
              <q-btn
                id="button-search-company-cnpj"
                label="+"
                color="primary"
                class="q-mt-md q-ml-sm"
                :disable="disableButtonAddEmail"
                @click="handlePushEmailChip"
              ></q-btn>
            </div>
            <q-chip
              v-for="name in companyData.phones"
              :key="name"
              class="q-mt-sm"
              removable
              :disable="isAbout"
              color="primary"
              text-color="white"
              @remove="handleRemoveEmailChip(name)"
            >
              {{ name }}
            </q-chip>
          </div>

          <!-- Responsável -->
          <div class="row q-mb-lg">
            <div class="col-5">
              <UiAtomInputText
                id="input-text-term-responsible-cnpj"
                v-model="companyData.responsiblePerson"
                label="*Responsável"
                max-length="100"
                :disable="isAbout"
                :rules="[
                  (val: any) => (val && val.length > 0) || 'Campo obrigatório!'
                ]"
              />
            </div>
          </div>

          <!-- CEP -->
          <div class="row q-mb-lg">
            <div class="q-col-auto col-3">
              <UiAtomInputText
                id="input-text-term-cep-cnpj"
                v-model="companyData.zipCode"
                label="*CEP"
                max-length="9"
                mask="XXXXX-XXX"
                :disable="isAbout"
                :rules="[
                  (val: any) => (val && val.length > 0) || 'Campo obrigatório!'
                ]"
                @blur="handleGetAddressByZipCode"
              />
            </div>
            <template v-if="loading.getByZepCode">
              <UiAtomCircularProgress size="sm"></UiAtomCircularProgress>
            </template>
          </div>

          <!-- Logradouro, Número e Complemento -->
          <div class="row q-mb-lg">
            <div class="q-col-auto col-5 q-mr-lg">
              <UiAtomInputText
                id="input-text-term-address-cnpj"
                v-model="companyData.address"
                label="*Logradouro"
                max-length="50"
                :disable="isAbout"
                :rules="[
                  (val: any) => (val && val.length > 0) || 'Campo obrigatório!'
                ]"
              />
            </div>
            <div class="q-col-auto col-1 q-mr-lg">
              <UiAtomInputText
                id="input-text-term-number-cnpj"
                v-model="companyData.number"
                label="Número"
                max-length="10"
                :disable="isAbout"
              />
            </div>
            <div class="q-col-auto col-5">
              <UiAtomInputText
                id="input-text-term-complement-cnpj"
                v-model="companyData.complement"
                label="Complemento"
                max-length="50"
                :disable="isAbout"
              />
            </div>
          </div>

          <!-- Bairro/Distrito e Município -->
          <div class="row q-mb-lg">
            <div class="q-col-auto col-4 q-mr-lg">
              <UiAtomInputText
                id="input-text-term-district-cnpj"
                v-model="companyData.district"
                label="*Bairro/Distrito"
                max-length="40"
                :disable="isAbout"
                :rules="[
                  (val: any) => (val && val.length > 0) || 'Campo obrigatório!'
                ]"
              />
            </div>
            <div class="q-col-auto col-4">
              <UiAtomInputText
                id="input-text-term-city-cnpj"
                v-model="companyData.city"
                label="*Município"
                max-length="40"
                :disable="isAbout"
                :rules="[
                  (val: any) => (val && val.length > 0) || 'Campo obrigatório!'
                ]"
              />
            </div>
          </div>

          <!-- Estado e UF -->
          <div class="row q-mb-lg">
            <div class="q-col-auto col-3 q-mr-lg">
              <UiAtomInputText
                id="input-text-term-state-cnpj"
                v-model="fixedValue.state"
                :disable="true"
                label="*Estado"
                max-length="30"
              />
            </div>
            <div class="q-col-auto col-1">
              <UiAtomInputText
                id="input-text-term-uf-cnpj"
                v-model="fixedValue.uf"
                :disable="true"
                label="*UF"
                max-length="30"
              />
            </div>
          </div>
        </q-form>
      </template>
    </template>
    <template #actions>
      <UiAtomButton
        id="button-modal-cancel-action-cnpj"
        label="CANCELAR"
        outline
        bold
        @click="toggleDialog({ show: false })"
      ></UiAtomButton>
      <UiAtomButton
        v-if="!isAbout"
        id="button-modal-confirm-action-cnpj"
        label="CONFIRMAR"
        class="q-ml-xs"
        :loading="loading.submit"
        @click="submit"
      ></UiAtomButton>
    </template>
  </UiMoleculeDialog>
  <UiMoleculeDialog v-if="isDelete" v-model="dialog" size="sm">
    <template #title> Confirmar Exclusão? </template>
    <template #content>
      <template v-if="loading.companyById">
        <UiAtomCircularProgress></UiAtomCircularProgress>
      </template>
      <template v-else>
        <div v-if="companyData.isMainCnpj">
          <UiAtomText id="text-main-cnpj" color="negative">
            Esse registro de CNPJ está definido como “CNPJ Principal” e não pode
            ser excluído. Caso queira excluir esse CNPJ, defina outro registro
            como “CNPJ principal”.
          </UiAtomText>
        </div>
        <div v-else>
          <div>
            <UiAtomText id="text-cnpj" bold>Número de inscrição: </UiAtomText>
            {{ companyData.cnpj }}
          </div>
          <div>
            <UiAtomText id="text-legal-name" bold>Nome Empresarial: </UiAtomText
            >{{ companyData.legalName }}
          </div>
          <div>
            <UiAtomText id="text-trade-name" bold>Nome Fantasia: </UiAtomText
            >{{ companyData.tradeName }}
          </div>
          <div>
            <UiAtomText id="text-city" bold>Cidade: </UiAtomText
            >{{ companyData.city }}
          </div>
          <div>
            <UiAtomText id="text-email" bold>E-mail: </UiAtomText
            >{{ companyData.email }}
          </div>
          <div>
            <UiAtomText id="text-responsible-person" bold
              >Responsável: </UiAtomText
            >{{ companyData.responsiblePerson }}
          </div>
        </div>
      </template>
    </template>
    <template #actions>
      <UiAtomButton
        id="button-cancel-cnpj"
        label="CANCELAR"
        outline
        bold
        @click="toggleDialog({ show: false })"
      >
      </UiAtomButton>
      <UiAtomButton
        v-if="isAbout || !companyData.isMainCnpj"
        id="button-confirm-cnpj"
        label="CONFIRMAR"
        class="q-ml-xs"
        :loading="loading.delete || loading.companyById"
        @click="handleDelete"
      ></UiAtomButton>
    </template>
  </UiMoleculeDialog>
  <UiMoleculeDialog v-if="canDefineMainCnpj" v-model="dialogMainCnpj" size="sm">
    <template #title> CONFIRMAR CNPJ COMO PRINCIPAL? </template>
    <template #content>
      <template v-if="loading.companyById">
        <UiAtomCircularProgress></UiAtomCircularProgress>
      </template>
      <template v-else>
        <div>
          <UiAtomText id="text-main-cnpj" color="negative">
            ATENÇÃO: Ao confirmar a ação, esse CNPJ será utilizado para todos os
            processamentos, pagamentos e saldos do Sistema de Folha de Pagamento
          </UiAtomText>
          <div class="q-mt-lg">
            <UiAtomText id="text-cnpj" bold>Número de inscrição: </UiAtomText>
            {{ companyData.cnpj }}
          </div>
          <div>
            <UiAtomText id="text-legal-name" bold>Nome Empresarial: </UiAtomText
            >{{ companyData.legalName }}
          </div>
          <div>
            <UiAtomText id="text-trade-name" bold>Nome Fantasia: </UiAtomText
            >{{ companyData.tradeName }}
          </div>
          <div>
            <UiAtomText id="text-city" bold>Cidade: </UiAtomText
            >{{ companyData.city }}
          </div>
          <div>
            <UiAtomText id="text-email" bold>E-mail: </UiAtomText
            >{{ companyData.email }}
          </div>
          <div>
            <UiAtomText id="text-responsible-person" bold
              >Responsável: </UiAtomText
            >{{ companyData.responsiblePerson }}
          </div>
        </div>
      </template>
    </template>
    <template #actions>
      <UiAtomButton
        id="button-cancel-cnpj"
        label="CANCELAR"
        outline
        bold
        @click="handleCickStar({ show: false })"
      >
      </UiAtomButton>
      <UiAtomButton
        v-if="isAbout || !companyData.isMainCnpj"
        id="button-confirm-cnpj"
        label="CONFIRMAR"
        class="q-ml-xs"
        :loading="loading.delete"
        @click="handleMadePrincipal"
      ></UiAtomButton>
    </template>
  </UiMoleculeDialog>
</template>
<script setup lang="ts">
import { ErrorCodeEnum } from '@pmesp/logic/dist/core/enums/ErrorCodeEnum';
import { Helper } from '@pmesp/logic/dist/core/helpers/Helper';
import { GetAllCompaniesDTO } from '@pmesp/logic/dist/modules/company/use-cases/GetAllCompanies/GetAllCompaniesDTO';
import { RoleEnum } from '@pmesp/logic/dist/modules/functionality/enums/RoleEnum';
import { StatusType, StatusTypeKey, useNotifyStore } from '~/store/notify';
import { useRolesStore } from '~/store/roles';

definePageMeta({ title: 'Administração / CNPJ PMESP' });

const loading = ref({
  allCompanies: false as boolean,
  companyById: false as boolean,
  submit: false as boolean,
  delete: false as boolean,
  getByZepCode: false as boolean
});

const notifyStore = useNotifyStore();

enum ActionType {
  ABOUT = 'about',
  ADD = 'add',
  EDIT = 'edit',
  DELETE = 'delete'
}

export type ActionKey = `${ActionType}`;
const { $UseCase, $q } = useNuxtApp();
const { signOut } = useAuth();

const dialog = ref<boolean>(false);

const dialogMainCnpj = ref<boolean>(false);

const dialogAction = ref<ActionKey>(ActionType.ADD);

const formSubmit = ref<boolean | undefined>(undefined);

const table = ref({
  columns: [
    {
      name: 'principal',
      field: 'principal',
      label: 'Principal',
      align: 'center'
    },
    {
      name: 'CNPJ',
      field: 'cnpj',
      label: 'CNPJ',
      align: 'left',
      style: 'width: 250px'
    },
    {
      name: 'Razão Social',
      field: 'legalName',
      align: 'left',
      label: 'Razão Social'
    },
    {
      name: 'Nome Fantasia',
      field: 'tradeName',
      label: 'Nome Fantasia',
      align: 'center'
    },
    {
      name: 'Cidade',
      field: 'city',
      label: 'Cidade',
      align: 'center'
    },
    {
      name: 'E-mail',
      field: 'email',
      label: 'E-mail',
      align: 'center'
    },
    {
      name: 'Responsável',
      field: 'responsiblePerson',
      label: 'Responsável',
      align: 'center'
    },
    {
      name: 'phones',
      field: 'phones',
      label: 'Telefone',
      align: 'center',
      style: 'width: 200px'
    },
    {
      name: 'action',
      field: 'action',
      label: 'Ações',
      align: 'center',
      style: 'width: 100px'
    }
  ],
  rows: [] as GetAllCompaniesDTO.ResponseProps[]
});

const genericErrorText =
  'No momento, o sistema de folha de pagamento está passando por uma indisponibilidade e a ação não pode ser concluída. Por favor, aguarde alguns minutos e tente novamente. Caso o problema persista, entre em contato com os Administradores do Sistema.';

const fixedValue = ref({
  state: 'São Paulo' as string,
  uf: 'SP' as string
});
const companyData = ref({
  id: undefined as string | undefined,
  cnpj: undefined as string | undefined,
  legalName: undefined as string | undefined,
  tradeName: undefined as string | undefined,
  economicActivityCode: undefined as string | undefined,
  legalNatureCode: undefined as string | undefined,
  responsiblePerson: undefined as string | undefined,
  address: undefined as string | undefined,
  number: undefined as string | undefined,
  complement: undefined as string | undefined,
  zipCode: undefined as string | undefined,
  district: undefined as string | undefined,
  city: undefined as string | undefined,
  email: undefined as string | undefined,
  phones: [] as string[],
  isMainCnpj: undefined as boolean | undefined,
  active: undefined as boolean | undefined
});

const phoneChip = ref<string | undefined>(undefined);

onMounted(async () => {
  await getAllCompanies();
});

const disableButtonAddEmail = computed(() => {
  return !!(
    Helper.isEmpty(phoneChip.value) ||
    Helper.isNotDefined(phoneChip.value) ||
    Helper.isNotDefined(companyData.value.phones.length) ||
    isAbout.value ||
    companyData.value.phones.length >= 3
  );
});

const isAbout = computed(() => {
  return dialogAction.value === ActionType.ABOUT;
});

const isDelete = computed(() => {
  return dialogAction.value === ActionType.DELETE;
});

const rolesStore = useRolesStore();

const canSave = computed(() => {
  return rolesStore.existRoles(RoleEnum.Company.Post);
});

const canEdit = computed(() => {
  return rolesStore.existRoles(RoleEnum.Company.Put);
});

const canDelete = computed(() => {
  return rolesStore.existRoles(RoleEnum.Company.Delete);
});

const canDetails = computed(() => {
  return rolesStore.existRoles(RoleEnum.Company.GetById);
});

const canDefineMainCnpj = computed(() => {
  return rolesStore.existRoles(RoleEnum.Company.GetById);
});

watch(dialog, value => {
  if (Helper.isNotDefined(value)) {
    clearData();
  }
});

watch(dialogMainCnpj, value => {
  if (Helper.isNotDefined(value)) {
    clearData();
  }
});

function showNotify(value: { type: StatusTypeKey; message: string }) {
  notifyStore.toggleNotify();
  notifyStore.toggleNotify({
    type: value.type,
    message: value.message
  });
}
async function getAllCompanies() {
  loading.value.allCompanies = true;
  const res = await $UseCase.Company.GetAllCompanies.execute();
  loading.value.allCompanies = false;

  if (res.isLeft()) {
    const code = res.value.errorValue().code;

    if (code === ErrorCodeEnum.AccessDenied) {
      await signOut({
        redirect: true,
        callbackUrl: `http://intranet.policiamilitar.sp.gov.br/`
      });
    }

    if (code === ErrorCodeEnum.NotFound) {
      return;
    }
    showNotify({
      type: StatusType.ERROR,
      message: 'Ocorreu um erro ao listar informações!'
    });
  }

  table.value.rows = res.value.getValue();
}

async function getCompanyById(id: string) {
  if (Helper.isDefined(id)) {
    loading.value.companyById = true;
    const req = {
      id
    };
    const res = await $UseCase.Company.GetCompanyById.execute(req);
    loading.value.companyById = false;

    if (res.isLeft()) {
      const code = res.value.errorValue().code;

      if (code === ErrorCodeEnum.AccessDenied) {
        await signOut({
          redirect: true,
          callbackUrl: `http://intranet.policiamilitar.sp.gov.br/`
        });
      }

      if (code === ErrorCodeEnum.NotFound) {
        return;
      }
      showNotify({
        type: StatusType.ERROR,
        message: 'Ocorreu um erro ao listar informações!'
      });
    }

    for (const key in companyData.value) {
      // @ts-ignore
      companyData.value[key] = res.value.getValue()[key];
    }
  }
}

function handlePushEmailChip() {
  if (!Array.isArray(companyData.value.phones)) {
    companyData.value.phones = [];
  }
  if (
    Helper.isDefined(companyData.value.phones) &&
    Helper.isDefined(phoneChip.value) &&
    companyData.value.phones.filter(e => e === phoneChip.value).length <= 0
  ) {
    companyData.value.phones.push(phoneChip.value);
    phoneChip.value = undefined;
  }
}

function handleRemoveEmailChip(name: string) {
  if (Helper.isDefined(companyData.value.phones)) {
    const index = companyData.value.phones.indexOf(name);
    if (index !== -1) {
      companyData.value.phones.splice(index, 1);
    }
  }
}

async function openDialogSelected(value: { item: string; action?: ActionKey }) {
  if (value.item) {
    toggleDialog({ show: true, action: value.action });
    await getCompanyById(value.item);
  }
}

async function validate(): Promise<boolean> {
  // @ts-ignore
  return await formSubmit.value.validate().then((success: any) => {
    if (success) {
      return true;
    }
    return false;
  });
}

async function submit() {
  const isValidate = await validate();
  if (isValidate) {
    if (Helper.isDefined(companyData.value.id)) {
      return await updateCompany();
    }
    await createCompany();
  }
}

async function createCompany() {
  if (
    Helper.isDefined(companyData.value.cnpj) &&
    Helper.isDefined(companyData.value.legalName) &&
    Helper.isDefined(companyData.value.tradeName) &&
    Helper.isDefined(companyData.value.economicActivityCode) &&
    Helper.isDefined(companyData.value.legalNatureCode) &&
    Helper.isDefined(companyData.value.responsiblePerson) &&
    Helper.isDefined(companyData.value.address) &&
    Helper.isDefined(companyData.value.zipCode) &&
    Helper.isDefined(companyData.value.district) &&
    Helper.isDefined(companyData.value.city) &&
    Helper.isDefined(companyData.value.email) &&
    Helper.isDefined(companyData.value.phones)
  ) {
    const input = {
      cnpj: companyData.value.cnpj,
      legalName: companyData.value.legalName,
      tradeName: companyData.value.tradeName,
      economicActivityCode: companyData.value.economicActivityCode,
      legalNatureCode: companyData.value.legalNatureCode,
      responsiblePerson: companyData.value.responsiblePerson,
      address: companyData.value.address,
      number: companyData.value.number,
      complement: companyData.value.complement,
      zipCode: companyData.value.zipCode,
      district: companyData.value.district,
      city: companyData.value.city,
      email: companyData.value.email,
      phones: companyData.value.phones,
      isMainCnpj: companyData.value.isMainCnpj
    };

    loading.value.submit = true;
    const res = await $UseCase.Company.CreateCompany.execute(input);
    loading.value.submit = false;

    if (res.isLeft()) {
      const code = res.value.errorValue().code;
      if (code === ErrorCodeEnum.AccessDenied) {
        await signOut({
          redirect: true,
          callbackUrl: `http://intranet.policiamilitar.sp.gov.br/`
        });
      }

      if (code === ErrorCodeEnum.BadRequest) {
        showNotify({
          type: StatusType.WARNING,
          message: genericErrorText
        });
        return;
      }

      showNotify({
        type: StatusType.ERROR,
        message: 'A razão social informada já está cadastrada.'
      });
      return;
    }
    showNotify({
      type: StatusType.SUCCESS,
      message: 'CNPJ Incluído com Sucesso!'
    });
    toggleDialog({ show: false });
    await getAllCompanies();
  }
}

function toggleDialog(value: { show: boolean; action?: ActionKey }) {
  const show = value.show;
  const action = value?.action ?? ActionType.ADD;
  dialog.value = show;

  if (show === true) {
    dialogAction.value = action;
  }
}

async function updateCompany() {
  if (
    Helper.isDefined(companyData.value.id) &&
    Helper.isDefined(companyData.value.cnpj) &&
    Helper.isDefined(companyData.value.legalName) &&
    Helper.isDefined(companyData.value.tradeName) &&
    Helper.isDefined(companyData.value.economicActivityCode) &&
    Helper.isDefined(companyData.value.legalNatureCode) &&
    Helper.isDefined(companyData.value.responsiblePerson) &&
    Helper.isDefined(companyData.value.address) &&
    Helper.isDefined(companyData.value.zipCode) &&
    Helper.isDefined(companyData.value.district) &&
    Helper.isDefined(companyData.value.city) &&
    Helper.isDefined(companyData.value.email) &&
    Helper.isDefined(companyData.value.phones)
  ) {
    const input = {
      id: companyData.value.id,
      cnpj: companyData.value.cnpj,
      legalName: companyData.value.legalName,
      tradeName: companyData.value.tradeName,
      economicActivityCode: companyData.value.economicActivityCode,
      legalNatureCode: companyData.value.legalNatureCode,
      responsiblePerson: companyData.value.responsiblePerson,
      address: companyData.value.address,
      number: companyData.value.number,
      complement: companyData.value.complement,
      zipCode: companyData.value.zipCode,
      district: companyData.value.district,
      city: companyData.value.city,
      email: companyData.value.email,
      phones: companyData.value.phones,
      isMainCnpj: companyData.value.isMainCnpj
    };

    loading.value.submit = true;
    const res = await $UseCase.Company.UpdateCompany.execute(input);
    loading.value.submit = false;

    if (res.isLeft()) {
      const code = res.value.errorValue().code;

      if (code === ErrorCodeEnum.AccessDenied) {
        await signOut({
          redirect: true,
          callbackUrl: `http://intranet.policiamilitar.sp.gov.br/`
        });
      }

      if (code === ErrorCodeEnum.BadRequest) {
        showNotify({
          type: StatusType.WARNING,
          message: genericErrorText
        });
        return;
      }

      showNotify({
        type: StatusType.ERROR,
        message: 'A razão social informada já está cadastrada.'
      });
      return;
    }
    showNotify({
      type: StatusType.SUCCESS,
      message: 'CNPJ Editado com Sucesso!'
    });
    toggleDialog({ show: false });
    await getAllCompanies();
  }
}

async function handleDelete() {
  if (Helper.isDefined(companyData.value.id)) {
    const input = {
      id: companyData.value.id
    };

    loading.value.delete = true;
    const res = await $UseCase.Company.DeleteCompany.execute(input);
    loading.value.delete = false;

    if (res.isLeft()) {
      const code = res.value.errorValue().code;

      if (code === ErrorCodeEnum.AccessDenied) {
        await signOut({
          redirect: true,
          callbackUrl: `http://intranet.policiamilitar.sp.gov.br/`
        });
      }
      showNotify({
        type: StatusType.ERROR,
        message: genericErrorText
      });
      return;
    }
    showNotify({
      type: StatusType.SUCCESS,
      message: 'Perfil deletado com sucesso'
    });

    toggleDialog({ show: false });
    await getAllCompanies();
  }
}

async function handleCickStar(value: { show: boolean; id?: string }) {
  dialogMainCnpj.value = value.show;
  if (Helper.isDefined(value.id)) {
    await getCompanyById(value.id);
  }
}

async function handleMadePrincipal() {
  if (Helper.isDefined(companyData.value.id)) {
    const input = {
      id: companyData.value.id
    };

    loading.value.delete = true;
    const res = await $UseCase.Company.PatchMainCnpj.execute(input);
    loading.value.delete = false;

    if (res.isLeft()) {
      const code = res.value.errorValue().code;

      if (code === ErrorCodeEnum.AccessDenied) {
        await signOut({
          redirect: true,
          callbackUrl: `http://intranet.policiamilitar.sp.gov.br/`
        });
      }
      showNotify({
        type: StatusType.ERROR,
        message: genericErrorText
      });
      return;
    }
    showNotify({
      type: StatusType.SUCCESS,
      message: 'CNPJ Definido como Principal com Sucesso'
    });

    handleCickStar({ show: false });
    await getAllCompanies();
  }
}

async function handleGetAddressByZipCode() {
  if (canDefineMainCnpj && Helper.isDefined(companyData.value.zipCode)) {
    loading.value.getByZepCode = true;
    const req = {
      zipCode: companyData.value.zipCode
    };
    const res = await $UseCase.Company.GetAddressByZepCode.execute(req);
    loading.value.getByZepCode = false;

    if (res.isLeft()) {
      const code = res.value.errorValue().code;

      if (code === ErrorCodeEnum.AccessDenied) {
        await signOut({
          redirect: true,
          callbackUrl: `http://intranet.policiamilitar.sp.gov.br/`
        });
      }

      if (code === ErrorCodeEnum.NotFound) {
        return;
      }
      showNotify({
        type: StatusType.ERROR,
        message: 'Informe um CEP localizado no Estado de São Paulo'
      });
    }
    const response = res.value.getValue();
    companyData.value.address = response.logradouro;
    companyData.value.district = response.bairro;
    companyData.value.city = response.localidade;
  }
}

function clearData() {
  companyData.value.id = undefined;
  companyData.value.cnpj = undefined;
  companyData.value.legalName = undefined;
  companyData.value.tradeName = undefined;
  companyData.value.economicActivityCode = undefined;
  companyData.value.legalNatureCode = undefined;
  companyData.value.responsiblePerson = undefined;
  companyData.value.address = undefined;
  companyData.value.number = undefined;
  companyData.value.complement = undefined;
  companyData.value.zipCode = undefined;
  companyData.value.district = undefined;
  companyData.value.city = undefined;
  companyData.value.email = undefined;
  companyData.value.phones = [];
  phoneChip.value = undefined;
  companyData.value.isMainCnpj = undefined;
}
</script>
