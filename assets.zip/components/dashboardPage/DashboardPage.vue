<template>
  <div class="admin-layout column content-center">
    <UiAtomCard class="admin-layout__main q-mt-md q-mb-md">
      <slot></slot>
    </UiAtomCard>
  </div>
</template>

<script setup lang="ts">
// const route = useRoute();

// const breadcrumbs = computed(() => {
//   const crumbs = route.meta.title as string | undefined;
//   return crumbs ? crumbs.split('/') : [];
// });
</script>

<style lang="scss" scoped>
.admin-layout {
  min-height: inherit;

  &__main {
    height: auto;
    flex-grow: 1;
    flex-basis: auto;
    width: 90%;
    // border-radius: 20px;
  }
}
</style>
