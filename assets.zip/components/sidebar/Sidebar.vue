<template>
  <q-header v-if="drawer === false">
    <q-toolbar>
      <q-btn flat round dense icon="menu" @click="drawer = !drawer"></q-btn>
    </q-toolbar>
  </q-header>
  <q-drawer
    v-model="drawer"
    show-if-above
    :mini="!drawer || miniState"
    :width="250"
    :breakpoint="500"
    bordered
    @click.capture="drawerClick"
  >
    <div class="q-mini-drawer-hide absolute" style="top: 15px; right: -17px">
      <q-btn
        dense
        round
        unelevated
        color="primary"
        icon="chevron_left"
        @click="miniState = true"
      ></q-btn>
    </div>

    <div class="row q-pa-md justify-center">
      <UiAtomImage
        id="ciaf-logo"
        alt="ciaf-logo"
        class="sidebar__logo"
        :src="logo"
        width="75px"
      ></UiAtomImage>
      <UiAtomText
        v-if="miniState === false"
        id="text-system-name"
        size="xs"
        color="primary"
        class="q-mt-sm"
        >Sistema Folha de pagamento</UiAtomText
      >
    </div>

    <q-separator></q-separator>

    <q-scroll-area
      style="height: calc(100% - 360px)"
      :thumb-style="{ width: '5px' }"
    >
      <div>
        <q-item v-ripple clickable to="/" class="q-mt-sm" color="primary">
          <q-item-section avatar>
            <q-icon name="data_usage" color="primary" size="xs"></q-icon>
          </q-item-section>
          <q-item-section> Painel de controle </q-item-section>
        </q-item>

        <template v-for="(menu, index) in menuOptions" :key="index">
          <q-list>
            <q-expansion-item color="primary">
              <template #header>
                <q-item-section avatar>
                  <q-icon :name="menu.icon" color="primary" size="xs" />
                </q-item-section>
                <q-item-section>
                  {{ menu.label }}
                </q-item-section>
              </template>
              <template v-for="(submenu, key) in menu.children" :key="key">
                <q-item
                  v-if="submenu.show"
                  clickable
                  :to="submenu.to"
                  class="q-pl-lg"
                  color="primary"
                >
                  <q-item-section avatar>
                    <q-icon
                      :name="submenu.icon"
                      color="primary"
                      size="xs"
                    ></q-icon>
                  </q-item-section>
                  <q-item-section> {{ submenu.label }} </q-item-section>
                </q-item>
              </template>
            </q-expansion-item>
          </q-list>
          <!-- <q-item v-ripple clickable :active="item.label === 'Outbox'">
            <q-item-section avatar>
              <q-icon :name="item.icon"></q-icon>
            </q-item-section>
            <q-item-section>
              {{ item.label }}
            </q-item-section>
          </q-item>
          <q-separator v-if="item.separator" :key="'sep' + index"></q-separator> -->
        </template>
      </div>
    </q-scroll-area>
    <div class="fixed-bottom bottom-shadow">
      <div class="row q-pb-sm q-pt-sm justify-center">
        <q-item v-ripple>
          <q-avatar
            color="primary"
            size="md"
            class="q-mt-xs"
            text-color="white"
            >{{ user.initials }}</q-avatar
          >
          <q-item-section class="q-ml-sm">
            <q-item-label
              ><UiAtomText id="account-name" type="text" size="xs"
                ><span class="text-bold">{{ user.name }} </span></UiAtomText
              >
              <UiAtomCaption>
                <span class="text-bold">CPF:</span>
                {{ user.cpf }}</UiAtomCaption
              ></q-item-label
            >
          </q-item-section>
        </q-item>
      </div>

      <q-separator></q-separator>

      <q-item v-ripple clickable to="/configuration" disable color="primary">
        <q-item-section avatar>
          <q-icon name="settings" size="xs"></q-icon>
        </q-item-section>
        <q-item-section> Configuração </q-item-section>
      </q-item>
      <q-item v-ripple clickable color="primary" @click="doSignOut">
        <q-item-section avatar>
          <q-icon name="logout" size="xs"></q-icon>
        </q-item-section>
        <q-item-section> Sair </q-item-section>
      </q-item>
    </div>
  </q-drawer>
</template>
<script setup lang="ts">
import { ref } from 'vue';
import { FormatHelper } from '~/logic/core/helpers/FormatHelper';
import { RoleEnum } from '~/logic/modules/functionality/enums/RoleEnum';
import { useAuthStore } from '~/store/auth';
import { useRolesStore } from '~/store/roles';

const { signOut, data, getSession } = useAuth();

/* DATA */
const rolesStore = useRolesStore();
const logo = useAssets('/assets/img/ciaf.png');
const miniState = ref(false);
const drawer = ref(false);
const authStore = useAuthStore();
const runtimeConfig = useRuntimeConfig();

const menuOptions = [
  {
    icon: 'account_tree',
    label: 'Administração',
    separator: false,
    children: [
      {
        icon: 'account_circle',
        label: 'Perfil',
        to: '/administrator/profile',
        show: rolesStore.showMenuOption(RoleEnum.Menu.Profile)
      },
      {
        icon: 'alternate_email',
        label: 'Template de E-mail',
        to: '/administrator/email-template',
        show: rolesStore.showMenuOption(RoleEnum.Menu.Templates)
      },
      {
        icon: 'web_asset',
        label: 'Termo de Confidencialidade',
        to: '/administrator/confidentiality-term',
        show: rolesStore.showMenuOption(RoleEnum.Menu.AcceptanceTerms)
      },
      {
        icon: 'apartment',
        label: 'CNPJ PMESP',
        to: '/administrator/cnpj-pmesp',
        show: rolesStore.showMenuOption(RoleEnum.Menu.Company)
      }
    ]
  }
];

const loading = ref({
  signOut: false as boolean
});

const session = await getSession({ required: true });
// authStore.setSession(session);

const user = computed(() => {
  // @ts-ignore
  const name = data.value?.profile?.name;
  // @ts-ignore
  const cpf = data.value?.profile?.id;
  const initials = name
    ? name.replace(/^(\w)\w*\s+(\w)\w*(?:\s+\w*)*$/, '$1$2')
    : undefined;

  return {
    name: name?.replace(/^(\w+)\s+(\w+)(?:\s+\w+)*\s+(\w+)$/, '$1 $3'),
    initials,
    cpf: cpf ? FormatHelper.formatCpf(cpf) : undefined
  };
});

/* METHODS */

function drawerClick(e: any) {
  if (miniState.value) {
    miniState.value = false;

    e.stopPropagation();
  }
}

async function doSignOut() {
  try {
    loading.value.signOut = true;

    await clearSession();
    authStore.removeSession();

    await signOut({
      redirect: true,
      callbackUrl: `http://intranet.policiamilitar.sp.gov.br/`
    });

    loading.value.signOut = false;
    // navigateTo({ path: '/' });
  } catch (err) {
    console.warn(err);
  }
}

async function clearSession() {
  try {
    // @ts-ignore
    const uid = session?.uid;

    const url = `${runtimeConfig.keycloak.host}/admin/realms/${runtimeConfig.keycloak.realm}/sessions/${uid}`;
    const res = await $fetch(url, {
      method: 'DELETE'
    });

    console.log('DELETE SESSION', res);
    // eslint-disable-next-line no-debugger
    debugger;
  } catch (err) {
    console.warn(err);
  }
}
</script>

<style lang="scss" scoped>
.bottom-shadow {
  border-radius: var(--0px, 0px);
  box-shadow: 0px -1px 12px 0px rgba(0, 0, 0, 0.05);
}
</style>
