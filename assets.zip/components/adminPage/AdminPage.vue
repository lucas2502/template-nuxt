<template>
  <div class="admin-layout column content-center">
    <UiAtomCard class="admin-layout____breadcrumbs q-mt-md">
      <UiAtomBreadcrumbs :breadcrumbs="breadcrumbs" />
    </UiAtomCard>

    <UiAtomCard class="admin-layout__main q-mt-md q-pt-md">
      <slot></slot>
    </UiAtomCard>
    <template v-if="slots.actions">
      <UiAtomCard class="admin-layout__footer q-mt-md q-mb-md row justify-end">
        <slot name="actions"></slot>
      </UiAtomCard>
    </template>
  </div>
</template>

<script setup lang="ts">
const slots = useSlots();
const route = useRoute();

const breadcrumbs = computed(() => {
  const crumbs = route.meta.title as string | undefined;
  return crumbs ? crumbs.split('/') : [];
});
</script>

<style lang="scss" scoped>
.admin-layout {
  min-height: inherit;

  &__breadcrumbs {
    flex-grow: 0;
    width: 90%;
  }

  &__main {
    height: auto;
    flex-grow: 1;
    flex-basis: auto;
    width: 90%;
  }

  &__footer {
    flex-grow: 0;
    width: 90%;
  }
}
</style>
