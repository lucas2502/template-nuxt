<template>
  <UiMoleculeDialog v-model="dialog" persistent :close-icon="false">
    <!-- <template #title>Aceite de termo de confidencialidade</template> -->
    <template #content>
      <template v-if="loading.getTerm">
        <UiAtomCircularProgress></UiAtomCircularProgress
      ></template>
      <template v-else>
        <div class="row">
          <div class="col-12 q-pa-sm">
            <div v-html="term.content" />
          </div>
        </div>
      </template>
    </template>
    <template #actions>
      <UiAtomButton
        id="button-submit-term-agreement"
        label="ACEITO"
        :loading="loading.submit"
        @click="submit"
      ></UiAtomButton>
    </template>
  </UiMoleculeDialog>
</template>

<script lang="ts" setup>
import { ErrorCodeEnum } from '~/logic/core/enums/ErrorCodeEnum';
import { Helper } from '~/logic/core/helpers/Helper';
import { TermType } from '~/logic/modules/term/enums/TermTypeEnum';
import acceptTermUseCase from '~/logic/modules/term/use-cases/AcceptTerm';
import getTermAgreementUseCase from '~/logic/modules/term/use-cases/GetTermAgreement';
import getTermByTypeUseCase from '~/logic/modules/term/use-cases/GetTermByType';

import { StatusType, useNotifyStore } from '~/store/notify';

const { $UseCase, $q } = useNuxtApp();
const notifyStore = useNotifyStore();

const term = ref({
  content: undefined as string | undefined,
  accepted: false as boolean,
  termId: undefined as string | undefined
});

const loading = ref({
  getTerm: false as boolean,
  submit: false as boolean
});

const dialog = ref<boolean>(false);

onMounted(async () => {
  showLoading();
  await getTermAgreement();
  hideLoading();
});

function hideLoading() {
  // @ts-ignore
  return $q.loading.hide();
}

function showLoading() {
  // @ts-ignore
  return $q.loading.show({ message: 'Carregando suas informações...' });
}

async function submit() {
  await submitTemAgrreement();
  dialog.value = false;
}
async function getTermAgreement() {
  const input = {
    type: TermType.CURRENT
  };
  loading.value.getTerm = true;
  const res = await getTermByTypeUseCase.execute(input);
  loading.value.getTerm = false;

  if (res.isLeft()) {
    const code = res.value.errorValue().code;

    if (code === ErrorCodeEnum.NotFound) {
      return;
    }

    notifyStore.toggleNotify({
      type: StatusType.ERROR,
      message: 'Ocorreu um erro ao listar perfis!'
    });

    return;
  }
  const termAgreement = res.value.getValue();
  term.value.content = termAgreement.content;
  term.value.termId = termAgreement.id;
  await isTermAgreement();
}

async function isTermAgreement() {
  if (Helper.isDefined(term.value.termId)) {
    const input = {
      id: term.value.termId
    };
    loading.value.getTerm = true;
    const res = await getTermAgreementUseCase.execute(input);
    loading.value.getTerm = false;

    if (res.isLeft()) {
      const code = res.value.errorValue().code;

      if (code === ErrorCodeEnum.NotFound) {
        return;
      }

      notifyStore.toggleNotify({
        type: StatusType.ERROR,
        message: 'Ocorreu um erro ao listar perfis!'
      });

      return;
    }
    const termAgreement = res.value.getValue();

    term.value.accepted = termAgreement.accepted;
    if (!termAgreement.accepted) {
      dialog.value = true;
    }
  }
}

async function submitTemAgrreement() {
  if (Helper.isDefined(term.value.termId)) {
    const input = {
      id: term.value.termId
    };
    loading.value.submit = true;
    const res = await acceptTermUseCase.execute(input);
    loading.value.submit = false;

    if (res.isLeft()) {
      notifyStore.toggleNotify({
        type: StatusType.ERROR,
        message: 'Ocorreu um erro ao listar perfis!'
      });

      return;
    }
    notifyStore.toggleNotify({
      type: StatusType.SUCCESS,
      message: 'Aceito com sucesso! '
    });
  }
}
</script>
