<template><div></div></template>
<script setup lang="ts">
import { watch } from 'vue';
import { StatusType, useNotifyStore } from '~/store/notify';
const { $q } = useNuxtApp();

const notifyStore = useNotifyStore();

const options = computed(() => notifyStore.getNotifyOptions);

const typeClasses = {
  positive: StatusType.SUCCESS,
  warning: StatusType.WARNING,
  negative: StatusType.ERROR
};

const iconClasses = {
  warning: 'report_problem',
  positive: 'check_circle_outline',
  negative: 'highlight_off'
};

// const options = ref<>;

function showNotifs() {
  if (options.value.type && options.value.message) {
    $q.notify({
      type: typeClasses[options.value.type],
      message: options.value.message,
      icon: iconClasses[options.value.type],
      position: 'top',
      textColor: 'white',
      timeout: 3000,
      group: false,
      actions: [
        {
          icon: 'close',
          color: 'white',
          round: true,
          handler: () => {
            /* ... */
          }
        }
      ]
    });
  }
}

watch(options, value => {
  showNotifs();
});
</script>

<style lang="scss">
.q-notifications__list {
  margin: 0;
}
.q-notification {
  // width: 100vw;
  // max-width: 100vw;
  margin: 0;
  border-radius: 0;
}
</style>
