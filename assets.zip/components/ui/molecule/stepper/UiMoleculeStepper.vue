<template>
  <div class="stepper">
    <div class="step active">
      <span class="step-number">1</span>
      <UiAtomIcon
        id="step-check-icon"
        class="step-check"
        name="done"
        size="xs"
        color="white"
      ></UiAtomIcon>
      <span class="step-status"></span>
      <span class="step-label">{{ props.stepLabels.stepLabelOne }}</span>
      <slot name="step-content-one"></slot>
    </div>
    <div class="line"></div>
    <div class="step">
      <span class="step-number">2</span>
      <UiAtomIcon
        id="step-check-icon"
        class="step-check"
        name="done"
        size="xs"
        color="white"
      ></UiAtomIcon>
      <span class="step-status"></span>
      <span class="step-label">{{ props.stepLabels.stepLabelTwo }}</span>
      <slot name="step-content-two"></slot>
    </div>
    <div class="line"></div>
    <div class="step">
      <span class="step-number">3</span>
      <span class="step-status"></span>
      <span class="step-label">{{ props.stepLabels.stepLabelThree }}</span>
      <slot name="step-content-three"></slot>
    </div>
  </div>
  <UiAtomButton
    id="next-step-button"
    label="Próximo"
    class="q-mt-lg q-mr-md"
    @click="nextButton"
  ></UiAtomButton>
  <UiAtomButton
    id="back-step-button"
    label="Voltar"
    class="q-mt-lg"
    @click="previousButton"
  ></UiAtomButton>
</template>
<script setup lang="ts">
import UiAtomButton from '../../atom/button/UiAtomButton.vue';
import UiAtomIcon from '../../atom/icon/UiAtomIcon.vue';

export interface StepLabels {
  stepLabelOne: string;
  stepLabelTwo: string;
  stepLabelThree: string;
}
function nextButton() {
  const currentStep = document.querySelector('.step.active');
  const nextStep = currentStep?.nextElementSibling?.nextElementSibling;
  if (
    nextStep !== null &&
    nextStep !== undefined &&
    currentStep !== null &&
    currentStep !== undefined
  ) {
    currentStep.classList.remove('active');
    currentStep.classList.add('completed');
    nextStep.classList.add('active');
  }
}
function previousButton() {
  const currentStep = document.querySelector('.step.active');
  const previousStep =
    currentStep?.previousElementSibling?.previousElementSibling;
  if (
    previousStep !== null &&
    previousStep !== undefined &&
    currentStep !== null &&
    currentStep !== undefined
  ) {
    currentStep.classList.remove('active');
    previousStep.classList.remove('completed');
    previousStep.classList.add('active');
  }
}
interface IProps {
  stepLabels: StepLabels;
}

const props = withDefaults(defineProps<IProps>(), {});
</script>
<style scoped lang="scss">
.stepper {
  display: flex;
  justify-content: space-between;
}

.step {
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
}

.step:first-child,
.step:last-child {
  width: 50px;
}

.step-number,
.step-check {
  display: flex;
  justify-content: center;
  align-items: center;
  width: 30px;
  height: 30px;
  border: 2px solid #666;
  color: #666;
  border-radius: 50%;
  font-size: 18px;
  font-weight: bold;
}

.step.active .step-number,
.step.completed .step-check,
.step.completed .step-number {
  background-color: #609;
  border-color: #609;
  color: #fff;
}

.step.active .step-status {
  opacity: 1;
}

.step-label {
  margin-top: 8px;
  font-size: 12px;
  width: 75px;
  text-align: center;
  color: #666;
}
.step:last-child .step-label {
  text-align: right;
}
.line {
  flex-grow: 1;
  height: 2px;
  background-color: #ddd;
  margin: 14px 0 0 0;
  width: 1px;
}
.step.completed + .line {
  background-color: #609;
}
.step:nth-child(1) {
  align-items: start;
}
.step:last-child {
  align-items: end;
}

.step-check {
  display: none;
}
// Aparecer icone de check e sumir número caso o step esteja com o class completed
.step.completed .step-check {
  display: flex;
}
.step.completed .step-number {
  display: none;
}
</style>
