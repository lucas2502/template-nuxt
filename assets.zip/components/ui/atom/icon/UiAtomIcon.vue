<template>
  <q-icon
    :id="props.id"
    :data-testid="props.id"
    :name="name"
    :size="props.size"
    :color="props.color"
    :class="{
      'cursor-pointer': cursorPointer
    }"
  ></q-icon>
</template>

<script setup lang="ts">
import { computed } from 'vue';
enum Color {
  dark = 'dark',
  primary = 'primary',
  secondary = 'secondary',
  tertiary = 'tertiary',
  white = 'white',
  grey = 'grey',
  yellow = 'yellow'
}
interface IProps {
  id: string;
  size?: 'xs' | 'sm' | 'md';
  color?: Color | string;
  cursorPointer?: boolean;
  name?:
    | 'success'
    | 'close'
    | 'error'
    | 'warning'
    | 'plus'
    | 'done'
    | 'content_copy';
  icon?: string;
}

const nameClasses = {
  success: 'check_circle_outline',
  close: 'close',
  plus: 'add',
  error: 'highlight_off',
  warning: 'report_problem',
  done: 'done'
};

const name = computed(() => {
  return nameClasses[props?.name] ?? props?.icon;
});

const props = withDefaults(defineProps<IProps>(), {
  size: 'sm',
  cursorPointer: false,
  name: undefined,
  icon: undefined,
  color: Color.grey
});
</script>
<style scoped lang="scss"></style>
