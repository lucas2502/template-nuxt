<template>
  <q-btn
    :id="id"
    :data-testid="id"
    :disabled="disabled"
    :color="color"
    :to="to"
    :flat="flat"
    :size="sizeClasses[size]"
    :outline="outline"
    :icon="icon"
    :no-caps="capitalize"
    :loading="loading"
    :readonly="readonly"
    :rounded="rounded"
    style="width: 150px"
    class="text-bold-1"
    :class="[
      textColorClasses[textColor],
      {
        'btn--disabled': disabled,
        'btn--readonly': readonly,
        'full-width': fullWidth,
        'no-pointer-events': noPointerEvents,
        'btn--bold': bold
      }
    ]"
    @click="doClick"
  >
    {{ label }}
  </q-btn>
</template>

<script setup lang="ts">
interface IProps {
  id: string;
  color?: 'primary' | 'secondary' | 'tertiary' | 'grey' | 'negative' | string;
  textColor?: 'primary' | 'dark' | 'white';
  to?: string;
  label?: string;
  disabled?: boolean;
  flat?: boolean;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | 'default';
  fullWidth?: boolean;
  outline?: boolean;
  icon?: 'remove' | 'add' | 'download' | 'print' | 'close' | undefined;
  capitalize?: boolean;
  loading?: boolean;
  readonly?: boolean;
  noPointerEvents?: boolean;
  rounded?: boolean;
  bold?: boolean;
}

// TODO - Vamos ter que baixar a imagem de imprimir. Ela não existe no material icons. a opção "Print" de agora é só provisória.
withDefaults(defineProps<IProps>(), {
  color: 'primary',
  textColor: 'primary',
  to: undefined,
  label: undefined,
  disabled: false,
  flat: false,
  size: 'md',
  fullWidth: false,
  outline: false,
  icon: undefined,
  capitalize: true,
  loading: false,
  readonly: false,
  noPointerEvents: false,
  rounded: false,
  bold: true
});

const sizeClasses = {
  xs: 'xs',
  sm: 'sm',
  md: 'md',
  lg: 'lg',
  xl: 'xl',
  default: '16px'
};
const textColorClasses = {
  dark: 'text-dark',
  primary: 'text-primary',
  white: 'text-white',
  negative: 'text-negative'
};

interface IEmits {
  (e: 'click'): void;
}

const emit = defineEmits<IEmits>();

function doClick() {
  emit('click');
}
</script>

<style scoped lang="scss">
* {
  font-weight: 400;
}
.btn {
  &--disabled {
    color: var(--grey-sub-title) !important;
    background-color: var(--grey-disable) !important;
  }
  &--bold {
    font-weight: bold;
  }
}
</style>
