<template>
  <q-card class="atom-card" flat>
    <template v-if="slots.title">
      <q-card-section>
        <slot name="title"></slot>
      </q-card-section>
    </template>

    <q-card-section class="q-pt-xs q-pb-xs q-ma-xs">
      <slot></slot>
    </q-card-section>

    <template v-if="slots.footer">
      <q-separator dark />

      <q-card-actions>
        <slot name="footer"></slot>
      </q-card-actions>
    </template>
  </q-card>
</template>
<script setup lang="ts">
import { useSlots } from 'vue';

const slots = useSlots();
</script>
<style lang="scss" scoped>
.atom-card {
  border-radius: 15px;
  border: solid #dddddd 1px;
  // .q-card__section--vert {
  //   padding: 10px;
  // }
}
</style>
