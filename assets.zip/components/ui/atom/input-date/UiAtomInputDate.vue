<template>
  <q-label v-if="props.label" class="q-mb-sm"> {{ props.label }}</q-label>
  <q-input
    :id="props.id"
    mask="##/##/####"
    type="date"
    :model-value="modelValue"
    :data-test="props.id"
    :color="props.color"
    :maxlength="10"
    :outlined="outlined"
    dense
    :readonly="props.readonly"
    :disable="props.disable"
    :data-testid="props.id"
    :class="[sizeClasses[props.size]]"
    :rules="props.rules"
    no-error-icon
    :placeholder="placeholder"
    @update:model-value="$emit('update:model-value', $event)"
  >
  </q-input>
</template>

<script setup lang="ts">
interface IProps {
  id: string;
  color?: 'primary' | 'secondary' | 'tertiary';
  label?: string;
  modelValue?: string | number;
  disable?: boolean;
  readonly?: boolean;
  prepend?: string;
  append?: string;
  size?: 'sm' | 'default';
  rules?: ((value: string) => boolean | string)[];
  placeholder?: string;
  outlined?: boolean;
}

const props = withDefaults(defineProps<IProps>(), {
  color: 'primary',
  label: undefined,
  modelValue: undefined,
  disable: false,
  readonly: false,
  type: 'text',
  prepend: undefined,
  append: undefined,
  size: 'default',
  rules: undefined,
  placeholder: undefined,
  outlined: true
});

const sizeClasses = {
  sm: 'btn--sm',
  default: 'btn--default'
};

interface IEmits {
  (e: 'update:model-value'): void;
}
defineEmits<IEmits>();
</script>
<style scoped lang="scss">
.btn {
  padding-top: 0px;
  &--sm {
    width: 34px;
    .q-field__control {
      padding: 0 5px;
    }
  }
  &--default {
    width: 100%;
  }
}
</style>
