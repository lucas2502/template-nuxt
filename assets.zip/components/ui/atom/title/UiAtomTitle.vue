<template>
  <component
    :is="type"
    :id="id"
    :data-testid="id"
    :color="color"
    :class="[
      'q-my-none',
      typeClasses[type],
      colorClasses[color],

      {
        'title--bold': bold
      }
    ]"
    ><slot></slot
  ></component>
</template>

<script setup lang="ts">
interface IProps {
  type: 'h1' | 'h2' | 'h3' | 'h4' | 'h5' | 'h6';
  color?:
    | 'dark'
    | 'primary'
    | 'secondary'
    | 'tertiary'
    | 'grey-sub-title'
    | 'white';
  bold?: boolean;
  id: string;
}

withDefaults(defineProps<IProps>(), {
  type: 'h1',
  color: 'dark',
  bold: false
});

const typeClasses = {
  h1: 'text-h1',
  h2: 'text-h2',
  h3: 'text-h3',
  h4: 'text-h4',
  h5: 'text-h5',
  h6: 'text-h6'
};

const colorClasses = {
  dark: 'text-dark',
  primary: 'text-primary',
  secondary: 'text-secondary',
  tertiary: 'text-tertiary',
  white: 'text-white'
};
</script>
<style scoped lang="scss">
* {
  font-weight: 300;
}
.title {
  &--bold {
    font-weight: 500;
  }
}
</style>
