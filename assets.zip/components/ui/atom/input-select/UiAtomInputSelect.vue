<template>
  <q-label>{{ props.label }}</q-label>
  <q-select
    :id="props.id"
    :model-value="modelValue"
    :data-test="props.id"
    :color="props.color"
    :options="props.options"
    outlined
    dense
    :loading="props.loading"
    :disable="isDisabled"
    :readonly="props.readonly"
    :emit-value="props.returnSingleValue"
    :map-options="props.returnSingleValue"
    :rules="rules"
    no-error-icon
    lazy-rules
    @update:model-value="$emit('update:model-value', $event)"
  ></q-select>
</template>

<script setup lang="ts">
import { computed } from 'vue';

export interface IOptionInputSelect {
  label: string;
  value: string | number | boolean;
}

// const model = ref('' as string | {} as IOptionInputSelect);

const isDisabled = computed(() => {
  if (props.disable || props.loading) {
    return true;
  }
  return false;
});

interface IProps {
  id: string;
  color?: 'primary' | 'secondary' | 'tertiary';
  label?: string;
  modelValue?:
    | IOptionInputSelect['value']
    | IOptionInputSelect
    | string
    | number;
  options: IOptionInputSelect[] | [];
  loading?: boolean;
  disable?: boolean;
  readonly?: boolean;
  returnSingleValue?: boolean;
  rules?: ((value: string) => boolean | string)[];
}

const props = withDefaults(defineProps<IProps>(), {
  color: 'primary',
  label: undefined,
  modelValue: undefined,
  loading: false,
  disable: false,
  readonly: false,
  returnSingleValue: false,
  rules: undefined
});

interface IEmits {
  (e: 'update:model-value'): void;
}
defineEmits<IEmits>();
</script>
