<template>
  <component
    :is="typeComponent[props.type]"
    :id="props.id"
    :data-testid="props.id"
    class="q-my-none"
    :href="props.url"
    :class="[
      typeClasses[props.type],
      sizeClasses[props.size],
      colorClasses[props.color],
      {
        'text--bold': props.bold
      }
    ]"
    ><slot></slot
  ></component>
</template>

<script setup lang="ts">
interface IProps {
  type?: 'text' | 'link' | 'paragraph';
  url?: string;
  color?: 'dark' | 'primary' | 'secondary' | 'positive' | 'nether' | 'negative';
  size: 'xs' | 'sm' | 'md' | 'lg';
  bold?: boolean;
  id: string;
}

const props = withDefaults(defineProps<IProps>(), {
  type: 'text',
  url: undefined,
  color: 'dark',
  bold: false,
  size: 'sm'
});

const typeComponent = {
  link: 'a',
  paragraph: 'p',
  text: 'span'
};

const colorClasses = {
  dark: 'text-dark',
  primary: 'text-primary',
  secondary: 'text-secondary',
  positive: 'text-positive',
  nether: 'text-white',
  negative: 'text-negative'
};

const sizeClasses = {
  xs: 'text--xs',
  sm: 'text--sm',
  md: 'text--md',
  lg: 'text--lg'
};

const typeClasses = {
  link: 'text--link',
  text: 'text',
  paragraph: 'text'
};
</script>

<style scoped lang="scss">
.text {
  font-weight: 400;
  line-height: 20px;
  &--link {
    text-decoration-line: underline;
    color: var(--primary);
    cursor: pointer;
  }
  &--bold {
    font-weight: 500;
  }
  &--xs {
    font-size: 12px;
  }
  &--sm {
    font-size: 14px;
  }
  &--md {
    font-size: 16px;
  }
  &--lg {
    font-size: 24px;
  }
}
</style>
