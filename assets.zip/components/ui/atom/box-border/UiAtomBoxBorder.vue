<template>
  <div class="row flex justify-around box-border">
    <slot></slot>
  </div>
</template>

<script setup lang="ts"></script>

<style scoped lang="scss">
.box-border {
  background: #ffffff;
  border: 1px solid #dddddd;
  border-radius: 4px;
}
</style>
