<template>
  <q-tabs
    :model-value="modelValue"
    color="primary"
    class="text-grey"
    active-color="primary"
    indicator-color="primary"
    :align="alignTabs"
    narrow-indicator
    @update:model-value="$emit('update:model-value', $event)"
  >
    <q-tab
      v-for="(item, index) in tabsName"
      :id="`${index}-tab`"
      :key="index"
      :data-test="`${index}-tab`"
      :name="index"
      :label="item"
    >
    </q-tab>
  </q-tabs>

  <q-separator />

  <q-tab-panels :model-value="modelValue" animated>
    <q-tab-panel v-for="(item, index) in tabsName" :key="item" :name="index">
      <v-container fluid>
        <slot :name="`tab-${index}`"></slot>
      </v-container>
    </q-tab-panel>
  </q-tab-panels>
</template>

<script setup lang="ts">
// import { ref } from 'vue';

// const tab = ref<number | undefined>(undefined);

interface Props {
  id: string;
  color?: 'primary' | 'secondary' | 'tertiary';
  alignTabs?: 'left' | 'center' | 'right' | 'justify' | undefined;
  tabsName: string[] | [];
  modelValue: number | undefined;
}

withDefaults(defineProps<Props>(), {
  color: 'primary',
  alignTabs: 'center'
});
</script>
