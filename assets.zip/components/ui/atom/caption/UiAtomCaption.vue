<template>
  <p class="q-my-none text-caption caption" data-testid="caption">
    <slot></slot>
  </p>
</template>

<style scoped lang="scss">
.caption {
  font-weight: 400;
  font-size: 12px;
  line-height: 15px;
  color: var(--grey-caption);
  white-space: normal;
}
</style>
