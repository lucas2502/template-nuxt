<template>
  <q-file
    :id="props.id"
    :model-value="modelValue"
    :data-testid="props.id"
    :color="props.color"
    :loading="props.loading"
    :disable="props.disabled"
    :accept="props.accept"
    outlined
    :rules="props.rules"
    @update:model-value="$emit('update:model-value', $event)"
  >
    <template #prepend>
      <q-icon :name="props.icon" />
    </template>
  </q-file>
</template>
<script setup lang="ts">
interface IProps {
  id: string;
  color?: 'primary' | 'secondary' | 'tertiary';
  modelValue?: File;
  disabled?: boolean;
  loading?: boolean;
  icon?: string;
  rules?: Array<(data: File) => boolean | string>;
  accept?: string;
}

const props = withDefaults(defineProps<IProps>(), {
  color: 'primary',
  modelValue: undefined,
  accept: undefined,
  rules: undefined,
  disabled: false,
  loading: undefined,
  icon: 'attach_file'
});

interface IEmits {
  (e: 'update:model-value'): void;
}
defineEmits<IEmits>();
</script>
