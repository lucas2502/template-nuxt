<template>
  <div class="q-pa-md product-carousel">
    <q-carousel
      v-model="slide"
      transition-prev="slide-right"
      transition-next="slide-left"
      swipeable
      animated
      :arrows="Screen.xs ? true : arrows"
      :control-color="color"
      :navigation="Screen.xs ? false : shouldShowNavigation"
      :height="height"
      control-type="regular"
    >
      <template #navigation-icon="{ index, active, btnProps, onClick }">
        <q-btn
          v-if="index === 0 && (isInfinite || !isFirstSlide)"
          size="md"
          icon="chevron_left"
          color="primary"
          flat
          round
          dense
          @click="slideArrowClick(-1)"
        />

        <q-btn
          v-if="active"
          size="sm"
          :icon="btnProps.icon"
          :class="{ 'q-carousel__navigation-icon--active': active }"
          color="primary"
          flat
          round
          dense
          @click="onClick"
        />
        <q-btn
          v-else
          size="xs"
          :icon="btnProps.icon"
          class="q-carousel__navigation-icon--inactive"
          color="primary"
          flat
          round
          dense
          @click="onClick"
        />
        <q-btn
          v-if="index === itemGroups.length - 1 && (isInfinite || !isLastSlide)"
          size="md"
          icon="chevron_right"
          color="primary"
          flat
          round
          dense
          @click="slideArrowClick(1)"
        />
      </template>
      <q-carousel-slide
        v-for="(group, index) in itemGroups"
        :key="index"
        :name="index"
        class="column no-wrap"
      >
        <div
          class="row fit justify-center items-center q-gutter-xs q-col-gutter no-wrap"
        >
          <slot name="cards" :group="group"></slot>
        </div>
        <q-carousel-control
          position="bottom-right"
          :offset="[18, 18]"
          class="q-gutter-xs"
        >
        </q-carousel-control>
      </q-carousel-slide>
    </q-carousel>
  </div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue';
import { Screen } from 'quasar';

interface IProps {
  items: Array<any>;
  height?: string;
  color?: string;
  arrows?: boolean;
  isInfinite?: boolean;
}

const props = withDefaults(defineProps<IProps>(), {
  height: '760px',
  color: 'primary',
  arrows: false,
  isInfinite: false
});

const slide = ref(0);

// this part of the code ensures that the slide value is correctly adjusted when moving forward or backward through the carousel, considering the valid slide's interval.
const slideArrowClick = (direction: number) => {
  const totalSlides = itemGroups.value.length;
  if (props.isInfinite) {
    //  This is to ensure that the new slide value is within the valid range of 0 to totalSlides - 1
    slide.value = (slide.value + direction + totalSlides) % totalSlides;

    // this part of the code is responsible for making the carousel "loop" when we move back from the first slide. It adjusts the slide value to the last slide, allowing continuous carousel navigation.
    if (slide.value < 0) {
      slide.value += totalSlides;
    }
  } else {
    // It ensures that the new slide value is within the valid bounds of the slide range. Math.max is used to select the maximum value between 0 and the sum of the slide's current value and the direction. Then Math.min is used to select the minimum value between the previous result and totalSlides - 1, avoiding exceeding the total number of slides.

    slide.value = Math.max(
      0,
      Math.min(slide.value + direction, totalSlides - 1)
    );
  }
};

const itemGroups = computed(() => {
  const groups: any = [];

  // Show the quantity of slides based on the screen
  const itemsPerGroup = Screen.xs ? 1 : Screen.sm ? 2 : Screen.md ? 3 : 4;

  for (let i = 0; i < props.items.length; i += itemsPerGroup) {
    groups.push(props.items.slice(i, i + itemsPerGroup));
  }
  return groups;
});

const isFirstSlide = computed(() => slide.value === 0);
const isLastSlide = computed(() => slide.value === itemGroups.value.length - 1);
const shouldShowNavigation = computed(() => itemGroups.value.length > 1);
</script>

<style lang="scss">
div .q-carousel__next-arrow {
  background: linear-gradient(
    to right,
    rgba(255, 255, 255, 0),
    rgba(255, 255, 255, 1)
  );
  width: 150px;
}
div .q-carousel__prev-arrow {
  background: linear-gradient(
    to left,
    rgba(255, 255, 255, 0),
    rgba(255, 255, 255, 1)
  );

  width: 150px;
}
@media (max-width: 600px) {
  div .q-carousel__next-arrow {
    background: none;
    top: 93%;
    width: 200px;
  }
  div .q-carousel__prev-arrow {
    background: none;
    top: 93%;
    width: 200px;
  }
}
.product-carousel {
  max-width: 1300px;
}
</style>
