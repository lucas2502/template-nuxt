<template>
  <q-breadcrumbs gutter="md" class="text-grey">
    <q-breadcrumbs-el
      v-for="(item, index) in breadcrumbs"
      :key="index"
      :label="item"
    />
  </q-breadcrumbs>
</template>

<script setup lang="ts">
interface IProps {
  breadcrumbs: string[] | [];
}

withDefaults(defineProps<IProps>(), {
  breadcrumbs: undefined
});
</script>
