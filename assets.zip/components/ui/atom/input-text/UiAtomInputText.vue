<template>
  <q-label v-if="props.label" class="q-mb-sm"> {{ props.label }}</q-label>
  <q-input
    :id="props.id"
    :mask="props.mask"
    :model-value="modelValue"
    :data-test="props.id"
    :type="type"
    :color="props.color"
    :maxlength="props.maxLength"
    :outlined="outlined"
    dense
    :readonly="props.readonly"
    :disable="props.disable"
    :data-testid="props.id"
    :class="[sizeClasses[props.size]]"
    :rules="props.rules"
    no-error-icon
    :placeholder="placeholder"
    @update:model-value="$emit('update:model-value', $event)"
    @blur="handleBlur"
  >
    <template v-if="prepend" #prepend>
      <q-icon :name="prepend" />
    </template>
    <template v-if="append" #append>
      <q-icon :name="append" />
    </template>
  </q-input>
</template>

<script setup lang="ts">
interface IProps {
  id: string;
  color?: 'primary' | 'secondary' | 'tertiary';
  label?: string;
  modelValue?: string | number;
  disable?: boolean;
  readonly?: boolean;
  prepend?: string;
  append?: string;
  type?:
    | 'text'
    | 'password'
    | 'textarea'
    | 'email'
    | 'search'
    | 'tel'
    | 'file'
    | 'number'
    | 'url'
    | 'timedate';
  size?: 'sm' | 'default';
  mask?: string | string[];
  maxLength: string;
  rules?: ((value: string) => boolean | string)[];
  placeholder?: string;
  outlined?: boolean;
}

const props = withDefaults(defineProps<IProps>(), {
  color: 'primary',
  label: undefined,
  modelValue: undefined,
  disable: false,
  readonly: false,
  type: 'text',
  prepend: undefined,
  append: undefined,
  size: 'default',
  mask: undefined,
  rules: undefined,
  placeholder: undefined,
  outlined: true
});

const sizeClasses = {
  sm: 'btn--sm',
  default: 'btn--default'
};

const handleBlur = () => {
  emit('blur');
};

interface IEmits {
  (e: 'update:model-value' | 'blur'): void;
}
const emit = defineEmits<IEmits>();
</script>
<style scoped lang="scss">
.btn {
  padding-top: 0px;
  &--sm {
    width: 34px;
    .q-field__control {
      padding: 0 5px;
    }
  }
  &--default {
    width: 100%;
  }
}
</style>
