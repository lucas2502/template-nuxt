<template>
  <q-label
    :id="props.id"
    :class="[
      'label',
      {
        'label--bold': props.bold
      }
    ]"
    :data-test="props.id"
    ><slot></slot>
  </q-label>
</template>

<script setup lang="ts">
interface IProps {
  bold?: boolean;
  id: string;
}

const props = withDefaults(defineProps<IProps>(), {
  bold: false
});
</script>

<style scoped lang="scss">
.label {
  font-weight: 300;
  font-size: 16px;
  &--bold {
    font-weight: bold;
  }
}
</style>
