<template>
  <!-- <div class="q-pa-md q-gutter-sm"> -->
  <UiAtomInputText
    v-if="props.filter"
    id="input-filter-tree"
    ref="filterRef"
    v-model="filtered"
    max-length="20"
    placeholder="Buscar funcionalidade"
    :outlined="false"
    append="search"
  >
  </UiAtomInputText>

  <q-tree
    :key="nodes.length"
    v-model:selected="selected"
    v-model:ticked="ticked"
    v-model:expanded="expanded"
    :nodes="nodes"
    label-key="label"
    node-key="id"
    class="q-mt-md"
    :filter="filtered"
    :tick-strategy="tickStrategy"
    :default-expand-all="defaultExpandAll"
    :class="{ 'disabled-item': props.disable }"
    no-nodes-label="Lista vazia!"
    no-results-label="Nenhum resultado encontrado!"
    @update:ticked="$emit('update:model-value', $event)"
  >
    <template v-for="(_, slot) of $slots" #[slot]="scope">
      <slot :name="slot" v-bind="scope" />
    </template>
  </q-tree>
  <!-- </div> -->
</template>

<script setup lang="ts">
import { onBeforeUpdate, ref } from 'vue';
// import UiAtomInputText from '../input-text/UiAtomInputText.vue';

interface IProps {
  modelValue?: string[] | [];
  nodes: any[];
  filter?: boolean | undefined;
  defaultExpandAll?: boolean;
  tickStrategy?: 'none' | 'strict' | 'leaf' | 'leaf-filtered';
  disable?: boolean;
  nodesLabel?: string;
  nodesResultLabel?: string;
}

const props = withDefaults(defineProps<IProps>(), {
  modelValue: undefined,
  filter: false,
  defaultExpandAll: false,
  tickStrategy: 'leaf',
  disable: false,
  nodesLabel: 'Nenhuma informação disponível.',
  nodesResultLabel: 'Nenhum resultado encontrado.'
});

const filtered = ref<string | undefined>(undefined);
const filterRef = ref<string | undefined>(undefined);
const selected = ref<string | undefined>(undefined);
const ticked = ref<string[] | undefined>([]);
const expanded = ref<string[] | undefined>([]);

onBeforeUpdate(() => {
  ticked.value = props.modelValue ? props.modelValue : [];
});

interface IEmits {
  (e: 'update:model-value'): void;
}
defineEmits<IEmits>();
</script>
<style lang="scss" scoped>
.disabled-item {
  opacity: 0.5;
  pointer-events: none;
  .q-checkbox {
    pointer-events: none !important;
    .checkbox__inner {
      opacity: 0.6 !important;
      cursor: not-allowed !important;
    }
  }
}
</style>
