<template>
  <q-table
    :id="props.id"
    v-model:selected="selected"
    :data-testid="props.id"
    :columns="props.columns"
    :loading="props.loading"
    :rows="props.rows"
    class="q-my-none"
    :row-key="props.rowKey"
    virtual-scroll
    :flat="props.flat"
    :rows-per-page-options="props.rowsPerPageOptions"
    :selection="selection"
    dense
    hide-no-data
    hide-selected-banner
    :class="{ 'disabled-table': props.disabled }"
    @update:selected="$emit('update:model-value', $event)"
  >
    <template v-for="(_, slot) of $slots" #[slot]="scope">
      <slot :name="slot" v-bind="scope" />
    </template>
  </q-table>
</template>

<script setup lang="ts">
import { onBeforeUpdate, ref } from 'vue';
export interface Column {
  name: string;
  field: string;
  label?: string;
  align?: string;
}
interface IProps {
  rows: any[];
  columns: Column[] | [];
  loading?: boolean;
  rowKey?: string;
  rowsPerPageOptions?: number[];
  flat?: boolean;
  id: string;
  selection?: 'single' | 'multiple';
  modelValue?: [] | undefined;
  disabled?: boolean;
}

const props = withDefaults(defineProps<IProps>(), {
  loading: false,
  rowKey: undefined,
  rowsPerPageOptions: () => [10],
  flat: true,
  modelValue: undefined,
  selection: undefined,
  disabled: false
});

onBeforeUpdate(() => {
  selected.value = props.modelValue ? props.modelValue : [];
});

const selected = ref([]);
</script>
<style scoped lang="scss">
.disabled-table {
  opacity: 0.5;
  pointer-events: none !important;
  cursor: not-allowed !important;
}
</style>
