<template>
  <div class="q-pa-md flex flex-center">
    <q-circular-progress
      :key="size"
      :size="size"
      :value="value"
      :color="color"
      class="q-ma-md"
      indeterminate
    ></q-circular-progress>
  </div>
</template>

<script setup lang="ts">
interface IProps {
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  value?: number;
  color?: string;
}

withDefaults(defineProps<IProps>(), {
  value: 70,
  size: 'md',
  color: 'primary'
});
</script>
