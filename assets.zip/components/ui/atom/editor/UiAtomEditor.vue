<template>
  <q-label>{{ label }}</q-label>
  <q-field
    ref="fieldRef"
    :model-value="modelValue"
    :rules="rules"
    borderless
    no-error-icon
    class="q-my-none"
  >
    <template #control>
      <q-editor
        :model-value="modelValue"
        :min-height="height"
        :disable="disable"
        :style="
          fieldRef && fieldRef?.hasError
            ? 'border-color: var(--q-negative)'
            : ''
        "
        @update:model-value="$emit('update:model-value', $event)"
      />
    </template>
  </q-field>
  <!-- <q-editor
    :id="id"
    :model-value="modelValue"
    :disable="disable"
    :readonly="readonly"
    @update:model-value="$emit('update:model-value', $event)"
  ></q-editor> -->
</template>

<script setup lang="ts">
import { defineProps, ref } from 'vue';

interface IProps {
  id: string;
  label?: string;
  modelValue: string;
  height?: string;
  disable?: boolean;
  readonly?: boolean;
  rules?: ((value: string) => boolean | string)[];
}
const fieldRef = ref(undefined);
withDefaults(defineProps<IProps>(), {
  label: undefined,
  disable: false,
  readonly: false,
  height: undefined,
  rules: undefined
});

interface IEmits {
  (e: 'update:model-value'): void;
}
defineEmits<IEmits>();
</script>
<style scoped lang="scss">
.q-editor {
  width: inherit;
}
</style>
