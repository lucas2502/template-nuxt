<template>
  <q-img
    :id="props.id"
    :data-testid="props.id"
    :src="props.src"
    :alt="props.alt"
    :class="[
      sizeClasses[props.size],
      {
        'logo--disabled': props.disabled
      }
    ]"
  />
</template>

<script setup lang="ts">
export interface IAtomImage {
  src: string;
  alt: string;
}
interface IProps extends IAtomImage {
  size?: 'xs' | 'sm' | 'md' | 'auto';
  disabled?: boolean;
  id: string;
}

const props = withDefaults(defineProps<IProps>(), {
  disabled: false,
  size: 'auto'
});

const sizeClasses = {
  xs: 'logo--xs',
  sm: 'logo--sm',
  md: 'logo--md',
  auto: 'logo--auto'
};
</script>

<style scoped lang="scss">
.logo {
  &--disabled {
    -webkit-filter: grayscale(100%);
  }
  &--xs {
    width: 30px !important;
  }
  &--sm {
    width: 40px !important;
  }
  &--md {
    height: 41px !important;
    width: 100px !important;
  }
  &--auto {
    width: 100%;
  }
}
</style>
