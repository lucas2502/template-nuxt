<template>
  <q-dialog :model-value="props.modelValue" @hide="$emit('update:model-value')">
    <q-card class="q-pa-md">
      <q-card-section class="row items-center q-pb-none">
        <div class="text-h6"><slot name="header"></slot></div>
        <q-space />
        <q-btn v-close-popup icon="close" flat round dense />
      </q-card-section>

      <q-card-section class="q-mt-md q-mb-md">
        <slot name="default"></slot>
      </q-card-section>

      <q-card-actions align="right">
        <slot name="footer"></slot>
      </q-card-actions>
    </q-card>
  </q-dialog>
</template>

<script setup lang="ts">
export interface Props {
  modelValue: boolean | undefined;
  show?: boolean;
  persistent?: boolean;
}

const props = withDefaults(defineProps<Props>(), {
  show: false,
  persistent: false
});

interface IEmits {
  (e: 'update:model-value'): void;
}

defineEmits<IEmits>();
</script>

<style scoped lang="scss">
@import url('https://fonts.googleapis.com/css2?family=Ubuntu:wght@700&display=swap');

.q-card {
  width: 65vmin;

  border-radius: 15px;
  border: solid #dddddd 1px;
}

.header {
  font-family: 'Ubuntu';
  font-style: normal;
  font-weight: 700;
  font-size: 36px;
  color: $primary;
  line-height: 41px;
}
</style>
