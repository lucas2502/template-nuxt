// import { WebStorageHelper } from './WebStorageHelper';

// describe('Helpers: ui/core/Helper/WebStorageHelper', () => {
//   beforeAll(() => {});

//   test('Should get item and convert value from string to json', () => {
//     const input = { name: 'test' };
//     WebStorageHelper.setItem({ key: 'test', value: input });
//     const res = WebStorageHelper.getItem('test');

//     expect(res).toStrictEqual({ name: 'test' });
//     expect(typeof res).toBe('object');
//   });

//   // test('Should get item as string', () => {
//   //   const input = 'test';
//   //   WebStorageHelper.setItem({ key: 'test', value: input });
//   //   const res = WebStorageHelper.getItem('test');

//   //   expect(res).toStrictEqual('test');
//   //   expect(typeof res).toBe('string');
//   // });
// });
