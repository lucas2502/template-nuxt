export interface CallError {
  code: string;
  message: string;
}
