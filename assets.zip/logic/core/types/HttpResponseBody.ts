export type HttpResponseBody<T> = {
  data: T;
  headers: any;
};
