import type { Functionality } from '../models/Functionality';
import type { Role } from '../models/Role';

export namespace FunctionalityServiceDTO {
  export namespace GetAllFunctionalities {
    export interface Output extends Array<Functionality> {}
  }

  export namespace GetRolesByUser {
    export interface Output extends Array<Role> {}
  }

  export namespace GetFunctionalitiesById {
    export interface Input {
      id: string;
    }
    export interface Output extends Functionality {}
  }

  export namespace GetFunctionalitiesByRole {
    export interface Input {
      role: string;
    }
    export interface Output extends Functionality {}
  }

  export namespace GetFunctionalitiesByRoute {
    export interface Input {
      route: string;
    }
    export interface Output extends Functionality {}
  }

  export namespace AddFunctionality {
    export interface Input extends Functionality {}
    export type Output = void;
  }

  export namespace UpdateFunctionality {
    export interface Input extends Functionality {}
    export type Output = void;
  }
}
