import { MenuOptionType } from '../enums/MenuOptionTypeEnum';
import { RoleEnum } from '../enums/RoleEnum';
import type { IFunctionalityService } from './FunctionalityService';
import type { FunctionalityServiceDTO } from './FunctionalityServiceDTO';

export class FunctionalityServiceMock implements IFunctionalityService {
  async getAllFunctionalities(): Promise<FunctionalityServiceDTO.GetAllFunctionalities.Output> {
    const returnBody = [
      {
        id: '055a055f-9e87-4a3e-91ba-1bdcac76ebcd',
        menuOptions: 'Profile',
        functionalityName: 'Atualizar Perfis',
        route: 'api/v1/Profile/Put',
        roles: []
      },
      {
        id: '0776373a-242e-4b15-a593-c9117ba97f47',
        menuOptions: 'Profile',
        functionalityName: 'Listar Perfis',
        route: 'api/v1/Profile/Get',
        roles: [
          'ListarPerfis',
          'TesteAtualizarFuncionalidades',
          'AtualizarPerfis'
        ]
      },
      {
        id: '451f914e-de12-4173-9aaf-b83970699c2c',
        menuOptions: 'Profile',
        functionalityName: 'Cadastrar Perfis',
        route: 'api/v1/Profile/Post',
        roles: ['CadastrarPerfil']
      },
      {
        id: 'a5e891fb-bd56-4c81-8ef2-fdf203c11bee',
        menuOptions: 'Profile',
        functionalityName: 'Deletar Perfis',
        route: 'api/v1/Profile/Delete',
        roles: ['DeletarPerfis']
      },
      {
        id: 'b13e0ad8-9e69-489c-bd1b-13aeac5a5d80',
        menuOptions: 'AcceptanceTerms',
        functionalityName: 'Aprovador',
        route: 'api/Term/Approve',
        roles: []
      },
      {
        id: 'ca96ecea-f95e-4e80-8f17-a868238b551e',
        menuOptions: 'Profile',
        functionalityName: 'Listar Perfis por Nome',
        route: 'api/v1/Profile/GetByName',
        roles: ['ListarPerfisPorNomes']
      },
      {
        id: 'fe292744-4ccf-4a40-a359-ca0c5d7fcecf',
        menuOptions: 'Profile',
        functionalityName: 'Listar Usuarios',
        route: 'api/v1/User',
        roles: ['ListarUsuarios']
      }
    ];

    return await new Promise((resolve, reject) => {
      try {
        setTimeout(() => {
          resolve(returnBody);
        }, 1000);
      } catch (err) {
        return reject(err);
      }
    });
  }

  async getRoles(): Promise<FunctionalityServiceDTO.GetRolesByUser.Output> {
    const returnBody = [
      {
        menu: RoleEnum.Menu.Profile,
        functionalitiesRoutes: [
          RoleEnum.Profile.Get,
          RoleEnum.Profile.Put,
          RoleEnum.Profile.Post,
          RoleEnum.Profile.GetByName,
          RoleEnum.Profile.Delete,
          RoleEnum.User.Get
        ]
      },
      {
        menu: RoleEnum.Menu.Templates,
        functionalitiesRoutes: [
          RoleEnum.Templates.Get,
          RoleEnum.Templates.Put,
          RoleEnum.Templates.Post,
          RoleEnum.Templates.GetById,
          RoleEnum.Templates.Delete
        ]
      },
      {
        menu: RoleEnum.Menu.Company,
        functionalitiesRoutes: [
          RoleEnum.Company.Put,
          RoleEnum.Company.Delete,
          RoleEnum.Company.GetById,
          RoleEnum.Company.Post
        ]
      },
      {
        menu: RoleEnum.Menu.AcceptanceTerms,
        functionalitiesRoutes: [
          RoleEnum.AcceptanceTerms.Post,
          RoleEnum.AcceptanceTerms.Put,
          RoleEnum.AcceptanceTerms.Approve,
          RoleEnum.AcceptanceTerms.GetById
        ]
      }
    ];

    return await new Promise((resolve, reject) => {
      try {
        setTimeout(() => {
          // @ts-ignore
          resolve(returnBody);
        }, 1000);
      } catch (err) {
        return reject(err);
      }
    });
  }

  async getFunctionalitiesById(
    _input: FunctionalityServiceDTO.GetFunctionalitiesById.Input
  ): Promise<FunctionalityServiceDTO.GetFunctionalitiesById.Output> {
    const returnBody = {
      id: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
      menuOptions: MenuOptionType.Profile,
      functionalityName: 'Administração',
      route: '/api/Profile',
      roles: ['Cadastrar']
    };

    return await new Promise((resolve, reject) => {
      try {
        setTimeout(() => {
          resolve(returnBody);
        }, 1000);
      } catch (err) {
        return reject(err);
      }
    });
  }

  async getFunctionalitiesByRole(
    _input: FunctionalityServiceDTO.GetFunctionalitiesByRole.Input
  ): Promise<FunctionalityServiceDTO.GetFunctionalitiesByRole.Output> {
    const returnBody = {
      id: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
      menuOptions: MenuOptionType.Profile,
      functionalityName: 'Administração',
      route: '/api/Profile',
      roles: ['Cadastrar']
    };

    return await new Promise((resolve, reject) => {
      try {
        setTimeout(() => {
          resolve(returnBody);
        }, 1000);
      } catch (err) {
        return reject(err);
      }
    });
  }

  async getFunctionalitiesByRoute(
    _input: FunctionalityServiceDTO.GetFunctionalitiesByRoute.Input
  ): Promise<FunctionalityServiceDTO.GetFunctionalitiesByRoute.Output> {
    const returnBody = {
      id: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
      menuOptions: MenuOptionType.Profile,
      functionalityName: 'Administração',
      route: '/api/Profile',
      roles: ['Cadastrar']
    };

    return await new Promise((resolve, reject) => {
      try {
        setTimeout(() => {
          resolve(returnBody);
        }, 1000);
      } catch (err) {
        return reject(err);
      }
    });
  }

  async addFunctionality(
    _input: FunctionalityServiceDTO.AddFunctionality.Input
  ): Promise<FunctionalityServiceDTO.AddFunctionality.Output> {
    return await new Promise((resolve, reject) => {
      try {
        setTimeout(() => {
          resolve();
        }, 1000);
      } catch (err) {
        return reject(err);
      }
    });
  }

  async updateFunctionality(
    _input: FunctionalityServiceDTO.UpdateFunctionality.Input
  ): Promise<FunctionalityServiceDTO.UpdateFunctionality.Output> {
    return await new Promise((resolve, reject) => {
      try {
        setTimeout(() => {
          resolve();
        }, 1000);
      } catch (err) {
        return reject(err);
      }
    });
  }
}
