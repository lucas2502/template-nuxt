import type { FunctionalityServiceDTO } from './FunctionalityServiceDTO';
import type { HttpResponseBody } from '~/logic/core/types/HttpResponseBody';
import { HttpAdapter } from '~/logic/core/adapter/HttpAdapter';

export interface IFunctionalityService {
  getAllFunctionalities(): Promise<FunctionalityServiceDTO.GetAllFunctionalities.Output>;
  getRoles(): Promise<FunctionalityServiceDTO.GetRolesByUser.Output>;
  getFunctionalitiesById(
    input: FunctionalityServiceDTO.GetFunctionalitiesById.Input
  ): Promise<FunctionalityServiceDTO.GetFunctionalitiesById.Output>;
  getFunctionalitiesByRole(
    input: FunctionalityServiceDTO.GetFunctionalitiesByRole.Input
  ): Promise<FunctionalityServiceDTO.GetFunctionalitiesByRole.Output>;
  getFunctionalitiesByRoute(
    input: FunctionalityServiceDTO.GetFunctionalitiesByRoute.Input
  ): Promise<FunctionalityServiceDTO.GetFunctionalitiesByRoute.Output>;
  addFunctionality(
    input: FunctionalityServiceDTO.AddFunctionality.Input
  ): Promise<FunctionalityServiceDTO.AddFunctionality.Output>;
  updateFunctionality(
    input: FunctionalityServiceDTO.UpdateFunctionality.Input
  ): Promise<FunctionalityServiceDTO.UpdateFunctionality.Output>;
}

export class FunctionalityService implements IFunctionalityService {
  constructor(private httpAdapter: HttpAdapter) {
    this.httpAdapter = httpAdapter;
  }

  async getAllFunctionalities(): Promise<FunctionalityServiceDTO.GetAllFunctionalities.Output> {
    const url = `${process.env.API_BASE_URL}/functionality/api/v1/Functionalities`;

    const res: HttpResponseBody<FunctionalityServiceDTO.GetAllFunctionalities.Output> =
      await this.httpAdapter.get({
        url
      });

    return res.data;
  }

  async getRoles(): Promise<FunctionalityServiceDTO.GetRolesByUser.Output> {
    const url = `${process.env.API_BASE_URL}/functionality/api/v1/Functionalities/GetByRoles`;

    const res: HttpResponseBody<FunctionalityServiceDTO.GetRolesByUser.Output> =
      await this.httpAdapter.get({
        url
      });

    return res.data;
  }

  async getFunctionalitiesById(
    input: FunctionalityServiceDTO.GetFunctionalitiesById.Input
  ): Promise<FunctionalityServiceDTO.GetFunctionalitiesById.Output> {
    const id = input.id;
    const url = `${process.env.API_BASE_URL}/functionality/api/v1/Functionalities/${id}`;

    const res: HttpResponseBody<FunctionalityServiceDTO.GetFunctionalitiesById.Output> =
      await this.httpAdapter.get({
        url
      });

    return res.data;
  }

  async getFunctionalitiesByRole(
    input: FunctionalityServiceDTO.GetFunctionalitiesByRole.Input
  ): Promise<FunctionalityServiceDTO.GetFunctionalitiesByRole.Output> {
    const role = input.role;
    const url = `${process.env.API_BASE_URL}/functionality/api/v1/Functionalities/${role}`;

    const res: HttpResponseBody<FunctionalityServiceDTO.GetFunctionalitiesByRole.Output> =
      await this.httpAdapter.get({
        url
      });

    return res.data;
  }

  async getFunctionalitiesByRoute(
    input: FunctionalityServiceDTO.GetFunctionalitiesByRoute.Input
  ): Promise<FunctionalityServiceDTO.GetFunctionalitiesByRoute.Output> {
    const route = input.route;
    const url = `${process.env.API_BASE_URL}/functionality/api/v1/Functionalities/${route}`;

    const res: HttpResponseBody<FunctionalityServiceDTO.GetFunctionalitiesByRoute.Output> =
      await this.httpAdapter.get({
        url
      });

    return res.data;
  }

  async addFunctionality(
    input: FunctionalityServiceDTO.AddFunctionality.Input
  ): Promise<FunctionalityServiceDTO.AddFunctionality.Output> {
    const url = `${process.env.API_BASE_URL}/functionality/api/v1/Functionalities`;

    const body = { ...input };

    const res: HttpResponseBody<FunctionalityServiceDTO.AddFunctionality.Output> =
      await this.httpAdapter.post({
        url,
        body
      });

    return res.data;
  }

  async updateFunctionality(
    input: FunctionalityServiceDTO.UpdateFunctionality.Input
  ): Promise<FunctionalityServiceDTO.UpdateFunctionality.Output> {
    const url = `${process.env.API_BASE_URL}/functionality/api/v1/Functionalities`;

    const body = { ...input };

    const res: HttpResponseBody<FunctionalityServiceDTO.UpdateFunctionality.Output> =
      await this.httpAdapter.put({
        url,
        body
      });

    return res.data;
  }
}
