export enum MenuOptionType {
  Profile = 'Profile',
  AcceptanceTerms = 'AcceptanceTerms',
  Templates = 'Templates',
  Company = 'Company'
}

export type MenuOptionTypeKey = `${MenuOptionType}`;
