export namespace RoleEnum {
  export enum Menu {
    Profile = 'profile',
    AcceptanceTerms = 'acceptance-terms',
    Templates = 'templates',
    Company = 'company'
  }

  export enum Profile {
    Delete = 'api/v1/profile/delete',
    Post = 'api/v1/profile/post',
    Put = 'api/v1/profile/put',
    Get = 'api/v1/profile/get',
    GetByName = 'api/v1/profile/get-by-name'
  }
  export enum User {
    Get = 'api/v1/user'
  }
  export enum AcceptanceTerms {
    Post = 'api/term/approve',
    Put = 'api/v1/term/put',
    Approve = 'api/v1/term/approve',
    GetById = 'api/v1/term/get-by-id'
  }
  export enum Templates {
    Delete = 'api/v1/template-email/delete',
    Post = 'api/v1/template-email/post',
    Put = 'api/v1/template-email/put',
    Get = 'api/v1/template-email/get',
    GetById = 'api/v1/template-email/get-by-id',
    Search = 'api/v1/template-email/search'
  }
  export enum Company {
    Post = 'api/v1/company/post',
    Put = 'api/v1/company/put',
    Delete = 'api/v1/company/delete',
    GetById = 'api/v1/company/get-by-id',
    Patch = 'api/v1/company/patch'
  }
}

export type RoleEnumProfileKey = `${RoleEnum.Profile}`;
export type RoleEnumUserKey = `${RoleEnum.User}`;

export type RoleEnumEmailTemplateKey = `${RoleEnum.Templates}`;

export type RoleEnumCompanyKey = `${RoleEnum.Company}`;

export type RoleEnumAcceptanceTermsKey = `${RoleEnum.AcceptanceTerms}`;

export type RoleEnumMenuKey = `${RoleEnum.Menu}`;

export type RoleEnumKey =
  | `${RoleEnumProfileKey}`
  | `${RoleEnumUserKey}`
  | `${RoleEnumEmailTemplateKey}`
  | `${RoleEnumCompanyKey}`
  | `${RoleEnumAcceptanceTermsKey}`;
