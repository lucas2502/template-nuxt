export interface Role {
  menu: string;
  functionalitiesRoutes: string[];
}
