// import type { MenuOptionTypeKey } from '../enums/MenuOptionTypeEnum';

export interface Functionality {
  id: string;
  menuOptions: string; // MenuOptionTypeKey;
  functionalityName: string;
  route: string;
  roles: string[];
}
