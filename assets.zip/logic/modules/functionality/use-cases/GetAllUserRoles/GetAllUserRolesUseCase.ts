import type { RoleEnumKey } from '../../enums/RoleEnum';
import type { GetAllUserRolesDTO } from './GetAllUserRolesDTO';
import type { UseCase } from '~/logic/core/base/UseCase';
import { AppError } from '~/logic/core/base/AppError';
import { left, right } from '~/logic/core/base/Either';
import { Result } from '~/logic/core/base/Result';
import type { CallError } from '~/logic/core/types/ErrorType';
import { HttpHelper } from '~/logic/core/helpers/HttpHelper';
import type { IFunctionalityService } from '~/logic/modules/functionality/services/FunctionalityService';
import { FormatHelper } from '~/logic/core/helpers/FormatHelper';

export class GetAllUserRolesUseCase
  implements UseCase<undefined, GetAllUserRolesDTO.Response>
{
  constructor(private functionalityService: IFunctionalityService) {
    this.functionalityService = functionalityService;
  }

  public async execute(): Promise<GetAllUserRolesDTO.Response> {
    try {
      const functionalities = await this.functionalityService.getRoles();

      const userRoles = functionalities.map(item => {
        const { menu, functionalitiesRoutes } = item;
        return {
          menu: FormatHelper.sanitizeString(menu),
          routes: functionalitiesRoutes.map(i => {
            return FormatHelper.sanitizeString(i);
          }) as RoleEnumKey[]
        };
      });

      return right(Result.ok(userRoles));
    } catch (err) {
      if (HttpHelper.isNotFoundError(err as CallError)) {
        return left(new AppError.DataNotFound(err));
      }

      if (HttpHelper.isUnauthorizedError(err as CallError)) {
        return left(new AppError.AccessDeniedError(err));
      }
      return left(new AppError.UnexpectedError(err));
    }
  }
}
