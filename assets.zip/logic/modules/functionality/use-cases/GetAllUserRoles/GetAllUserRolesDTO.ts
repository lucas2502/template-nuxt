import { AppError } from '~/logic/core/base/AppError';
import type { Either } from '~/logic/core/base/Either';
import { Result } from '~/logic/core/base/Result';
import type { RoleEnumKey } from '../../enums/RoleEnum';

export namespace GetAllUserRolesDTO {
  export interface Role {
    menu: string;
    routes: RoleEnumKey[] | [];
  }

  export interface ResponseBody extends Array<Role> {}

  export type Response = Either<
    AppError.UnexpectedError | AppError.DataNotFound | AppError.Unauthorized,
    Result<ResponseBody>
  >;
}
