import { GetAllUserRolesUseCase } from './GetAllUserRolesUseCase';
import { Helper } from '~/logic/core/helpers/Helper';
import { HttpAdapter } from '~/logic/core/adapter/HttpAdapter';
import { FunctionalityServiceMock } from '~/logic/modules/functionality/services/FunctionalityServiceMock';
import { FunctionalityService } from '~/logic/modules/functionality/services/FunctionalityService';

const MOCK = Helper.isTestMode();

const httpAdapter = new HttpAdapter();

const functionalityService = MOCK
  ? new FunctionalityServiceMock()
  : new FunctionalityService(httpAdapter);

const getAllUserRolesUseCase = new GetAllUserRolesUseCase(functionalityService);

export default getAllUserRolesUseCase;
