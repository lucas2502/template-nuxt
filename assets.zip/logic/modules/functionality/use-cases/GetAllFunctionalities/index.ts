import { FunctionalityServiceMock } from '../../services/FunctionalityServiceMock';
import { FunctionalityService } from '../../services/FunctionalityService';
import { GetAllFunctionalitiesUseCase } from './GetAllFunctionalitiesUseCase';
import { HttpAdapter } from '~/logic/core/adapter/HttpAdapter';
import { Helper } from '~/logic/core/helpers/Helper';

const MOCK = Helper.isTestMode();

const httpAdapter = new HttpAdapter();

const profileService = MOCK
  ? new FunctionalityServiceMock()
  : new FunctionalityService(httpAdapter);

const getAllFunctionalitiesUseCase = new GetAllFunctionalitiesUseCase(
  profileService
);

export default getAllFunctionalitiesUseCase;
