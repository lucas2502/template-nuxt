import { AppError } from '~/logic/core/base/AppError';
import type { Either } from '~/logic/core/base/Either';
import { Result } from '~/logic/core/base/Result';

export namespace GetAllFunctionalitiesDTO {
  interface Children {
    id: string;
    label: string;
    // route: string;
    // children: Children[];
  }
  export interface Functionality {
    id: string;
    label: string;
    // route: string;
    children: Children[];
  }

  export interface ResponseBody extends Array<Functionality> {}

  export type Response = Either<
    AppError.UnexpectedError | AppError.DataNotFound | AppError.Unauthorized,
    Result<ResponseBody>
  >;
}
