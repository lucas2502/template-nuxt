import type { IFunctionalityService } from '../../services/FunctionalityService';
import type { GetAllFunctionalitiesDTO } from './GetAllFunctionalitiesDTO';
import type { UseCase } from '~/logic/core/base/UseCase';
import { AppError } from '~/logic/core/base/AppError';
import { left, right } from '~/logic/core/base/Either';
import { Result } from '~/logic/core/base/Result';
import type { CallError } from '~/logic/core/types/ErrorType';
import { HttpHelper } from '~/logic/core/helpers/HttpHelper';

function newArrayFunctionalities(value: any) {
  return value.reduce((acc: any, item: any, index: number) => {
    const existingGroup = acc.find(
      (group: any) => group.label === item.menuOptions
    ); // Usando menuOptions para agrupar

    if (existingGroup) {
      existingGroup.children.push({
        id: item.id,
        label: item.functionalityName
        // route: item.route,
        // roles: item.roles
      });
    } else {
      acc.push({
        id: `${item.id}-${index}`,
        label: item.menuOptions, // Atribuindo o label corretamente
        children: [
          {
            id: item.id,
            label: item.functionalityName
            // route: item.route,
            // roles: item.roles
          }
        ]
      });
    }

    return acc;
  }, []);
}

export class GetAllFunctionalitiesUseCase
  implements UseCase<undefined, GetAllFunctionalitiesDTO.Response>
{
  constructor(private functionalityService: IFunctionalityService) {
    this.functionalityService = functionalityService;
  }

  public async execute(): Promise<GetAllFunctionalitiesDTO.Response> {
    try {
      const res = await this.functionalityService.getAllFunctionalities();

      const functionalities = [
        {
          id: '0',
          label: 'Todos',
          children: [
            {
              id: '01',
              label: 'Administração',
              children: newArrayFunctionalities(res)
            }
          ]
        }
      ];

      return right(Result.ok(functionalities));
    } catch (err) {
      if (HttpHelper.isNotFoundError(err as CallError)) {
        return left(new AppError.DataNotFound(err));
      }
      if (HttpHelper.isUnauthorizedError(err as CallError)) {
        return left(new AppError.AccessDeniedError(err));
      }

      return left(new AppError.UnexpectedError(err));
    }
  }
}
