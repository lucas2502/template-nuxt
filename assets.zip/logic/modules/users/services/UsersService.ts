import { UsersServiceDTO } from './UsersServiceDTO';
import { HttpResponseBody } from '@/core/types/HttpResponseBody';
import { HttpAdapter } from '@/core/adapter/HttpAdapter';
import { Config } from '@/config';

export interface IUsersService {
  getAllUsers(
    input: UsersServiceDTO.GetAllUsers.Input
  ): Promise<UsersServiceDTO.GetAllUsers.Output>;
}

export class UsersService implements IUsersService {
  constructor(private httpAdapter: HttpAdapter) {
    this.httpAdapter = httpAdapter;
  }

  async getAllUsers(
    input: UsersServiceDTO.GetAllUsers.Input
  ): Promise<UsersServiceDTO.GetAllUsers.Output> {
    const profileId = input.profileId;
    const url = profileId
      ? `${Config.getInstance.apiBaseUrl}/profile/api/v1/User?filterType=${input.filterType}&filterValue=${input.filterValue}&profileId=${profileId}`
      : `${Config.getInstance.apiBaseUrl}/profile/api/v1/User?filterType=${input.filterType}&filterValue=${input.filterValue}`;

    const res: HttpResponseBody<UsersServiceDTO.GetAllUsers.Output> =
      await this.httpAdapter.get({
        url
        //  params
      });

    return res.data;
  }
}
