import { FilterTypeKey } from '../enums/FilterypeEnum';
import { Users } from '../models/Users';

export namespace UsersServiceDTO {
  export namespace GetAllUsers {
    export interface Input {
      filterType: FilterTypeKey;
      filterValue: string;
      profileId?: string;
    }
    export interface Output extends Array<Users> {}
  }
}
