export interface Users {
  id: string;
  fullName: string;
  re: string;
  assignedProfile: boolean;
  profileId: string;
  cpf: string;
}
