import { AppError } from 'core/base/AppError';
import type { Either } from 'core/base/Either';
import { Result } from 'core/base/Result';
import { FilterTypeKey } from '../../enums/FilterypeEnum';

export namespace GetAllUsersDTO {
  export interface Request {
    type: FilterTypeKey;
    value: string;
    profile?: {
      id: string;
    };
  }
  export interface Profile {
    id: string;
    name: string;
    re: string;
    cpf: string;
    assigned: boolean;
    profile: {
      id: string;
    };
  }

  export interface ResponseBody {
    assigned: Profile[];
    unassigned: Profile[];
  }

  export type Response = Either<
    AppError.UnexpectedError | AppError.DataNotFound,
    Result<ResponseBody>
  >;
}
