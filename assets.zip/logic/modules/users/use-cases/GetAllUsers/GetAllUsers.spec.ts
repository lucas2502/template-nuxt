import { vi } from 'vitest';
import { FilterType } from '../../enums/FilterypeEnum';
import { UsersServiceMock } from '../../services/UsersServiceMock';
import { GetAllUsersDTO } from './GetAllUsersDTO';
import { GetAllUsersUseCase } from './GetAllUsersUseCase';
import { UseCase } from '@/core/base/UseCase';
import { ErrorCodeEnum } from '@/core/enums/ErrorCodeEnum';
import { UseCaseError } from '@/core/base/UseCaseError';

describe('UseCase: Users/GetAllUsers', () => {
  let useCase: UseCase<GetAllUsersDTO.Request, GetAllUsersDTO.Response>;

  beforeAll(async () => {
    useCase = (await import('.')).default;
  });

  test('should get users using CPF with success', async () => {
    const res = await useCase.execute({
      type: FilterType.CPF,
      value: '972.282.504-00'
    });

    expect(res.isRight()).toBe(true);

    const successValue = res.value.getValue() as GetAllUsersDTO.ResponseBody;

    expect(successValue).toBeDefined();
  });

  test('should get users using RE with success', async () => {
    const res = await useCase.execute({
      type: FilterType.RE,
      value: '628106'
    });

    expect(res.isRight()).toBeDefined();

    const successValue = res.value.getValue() as GetAllUsersDTO.ResponseBody;

    expect(successValue).toBeDefined();
  });

  test('should return error when request items is empty', async () => {
    const res = await useCase.execute({
      // @ts-ignore
      value: '',
      // @ts-ignore
      type: ''
    });

    expect(res.isRight()).toBe(false);

    const errorValue = (
      res as GetAllUsersDTO.Response
    ).value.errorValue() as UseCaseError;

    expect(errorValue.code).toBe(ErrorCodeEnum.RequiredFields);
  });

  test('should return error when request items is null', async () => {
    const res = await useCase.execute({
      // @ts-ignore
      value: null,
      // @ts-ignore
      type: null
    });

    expect(res.isRight()).toBe(false);

    const errorValue = (
      res as GetAllUsersDTO.Response
    ).value.errorValue() as UseCaseError;

    expect(errorValue.code).toBe(ErrorCodeEnum.RequiredFields);
  });

  test('should return error when request items is undefined', async () => {
    const res = await useCase.execute({
      // @ts-ignore
      value: undefined,
      // @ts-ignore
      type: undefined
    });

    expect(res.isRight()).toBe(false);

    const errorValue = (
      res as GetAllUsersDTO.Response
    ).value.errorValue() as UseCaseError;

    expect(errorValue.code).toBe(ErrorCodeEnum.RequiredFields);
  });

  test('should return Unexpected Error', async () => {
    const service = new UsersServiceMock();

    const spy = vi.spyOn(service, 'getAllUsers');

    spy.mockImplementationOnce((): any => {
      return Promise.reject(new Error('Unexpexted error'));
    });

    const useCase = new GetAllUsersUseCase(service);

    const res = await useCase.execute({
      type: FilterType.CPF,
      value: '972.282.504-00'
    });

    expect(res.isRight()).toBe(false);

    const errorValue = (
      res as GetAllUsersDTO.Response
    ).value.errorValue() as UseCaseError;

    expect(errorValue.code).toBe(ErrorCodeEnum.UnexpectedError);
  });

  test('should return Bad Request Error', async () => {
    const service = new UsersServiceMock();

    const spy = vi.spyOn(service, 'getAllUsers');

    spy.mockImplementationOnce((): any => {
      return Promise.reject(new Error('Bad Request'));
    });

    const useCase = new GetAllUsersUseCase(service);

    const res = await useCase.execute({
      type: FilterType.CPF,
      value: '972.282.504-00'
    });

    expect(res.isRight()).toBe(false);

    const errorValue = (
      res as GetAllUsersDTO.Response
    ).value.errorValue() as UseCaseError;

    expect(errorValue.code).toBe(ErrorCodeEnum.BadRequest);
  });

  test('should return Not Found Error', async () => {
    const service = new UsersServiceMock();

    const spy = vi.spyOn(service, 'getAllUsers');

    spy.mockImplementationOnce((): any => {
      return Promise.reject(new Error('404 Not Found'));
    });

    const useCase = new GetAllUsersUseCase(service);

    const res = await useCase.execute({
      type: FilterType.CPF,
      value: '972.282.504-00'
    });

    expect(res.isRight()).toBe(false);

    const errorValue = (
      res as GetAllUsersDTO.Response
    ).value.errorValue() as UseCaseError;

    expect(errorValue.code).toBe(ErrorCodeEnum.NotFound);
  });
});
