import { IUsersService } from '../../services/UsersService';
import { GetAllUsersDTO } from './GetAllUsersDTO';
import { UseCase } from '@/core/base/UseCase';
import { AppError } from '@/core/base/AppError';
import { left, right } from '@/core/base/Either';
import { Result } from '@/core/base/Result';
import { CallError } from '@/core/types/ErrorType';
import { HttpHelper } from '@/core/helpers/HttpHelper';
import { Helper } from '@/core/helpers/Helper';
import { FormatHelper } from '@/core/helpers/FormatHelper';

export class GetAllUsersUseCase
  implements UseCase<GetAllUsersDTO.Request, GetAllUsersDTO.Response>
{
  constructor(private usersService: IUsersService) {
    this.usersService = usersService;
  }

  public async execute(
    req: GetAllUsersDTO.Request
  ): Promise<GetAllUsersDTO.Response> {
    try {
      if (Helper.isEmpty(req.type) || Helper.isEmpty(req.value)) {
        return left(new AppError.RequiredFields());
      }

      const input = {
        filterType: req.type,
        filterValue: FormatHelper.removeSpecialCharsFromString(req.value),
        profileId: req.profile?.id
      };

      const res = await this.usersService.getAllUsers(input);

      const assigned: GetAllUsersDTO.Profile[] = [];

      const unassigned: GetAllUsersDTO.Profile[] = [];

      res.forEach(item => {
        const { id, fullName, re, assignedProfile, profileId, cpf } = item;

        if (assignedProfile === true) {
          assigned.push({
            id,
            name: fullName,
            re,
            cpf: FormatHelper.formatCpf(cpf),
            assigned: assignedProfile,
            profile: {
              id: profileId
            }
          });
        } else {
          unassigned.push({
            id,
            name: fullName,
            re,
            cpf: FormatHelper.formatCpf(cpf),
            assigned: assignedProfile,
            profile: {
              id: profileId
            }
          });
        }
      });

      const users = {
        assigned,
        unassigned
      };

      return right(Result.ok(users));
    } catch (err) {
      if (HttpHelper.isNotFoundError(err as CallError)) {
        return left(new AppError.DataNotFound(err));
      }
      if (HttpHelper.isBadRequestError(err as CallError)) {
        return left(new AppError.BadRequest(err));
      }
      if (HttpHelper.isUnauthorizedError(err as CallError)) {
        return left(new AppError.AccessDeniedError(err));
      }
      return left(new AppError.UnexpectedError(err));
    }
  }
}
