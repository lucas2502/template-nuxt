export enum FilterType {
  RE = 'RE',
  CPF = 'CPF'
}

export type FilterTypeKey = `${FilterType}`;
