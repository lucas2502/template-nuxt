import { EmailTemplateService } from '../../services/EmailTemplateService';
import { EmailTemplateServiceMock } from '../../services/EmailTemplateServiceMock';
import { GetEmailTemplateByIdUseCase } from './GetEmailTemplateByIdUseCase';
import { HttpAdapter } from '@/core/adapter/HttpAdapter';
import { Helper } from '@/core/helpers/Helper';

const MOCK = Helper.isTestMode();

const httpAdapter = new HttpAdapter();

const profileService = MOCK
  ? new EmailTemplateServiceMock()
  : new EmailTemplateService(httpAdapter);

const getEmailTemplateByIdUseCase = new GetEmailTemplateByIdUseCase(
  profileService
);

export default getEmailTemplateByIdUseCase;
