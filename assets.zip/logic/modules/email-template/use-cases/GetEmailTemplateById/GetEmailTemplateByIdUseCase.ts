import { IEmailTemplateService } from '../../services/EmailTemplateService';
import { GetEmailTemplateByIdDTO } from './GetEmailTemplateByIdDTO';
import { UseCase } from '@/core/base/UseCase';
import { AppError } from '@/core/base/AppError';
import { left, right } from '@/core/base/Either';
import { Result } from '@/core/base/Result';
import { CallError } from '@/core/types/ErrorType';
import { HttpHelper } from '@/core/helpers/HttpHelper';
import { FormatHelper } from '@/core/helpers/FormatHelper';
import { Helper } from '@/core/helpers/Helper';

export class GetEmailTemplateByIdUseCase
  implements
    UseCase<GetEmailTemplateByIdDTO.Request, GetEmailTemplateByIdDTO.Response>
{
  constructor(private emailTemplateService: IEmailTemplateService) {
    this.emailTemplateService = emailTemplateService;
  }

  public async execute(
    req: GetEmailTemplateByIdDTO.Request
  ): Promise<GetEmailTemplateByIdDTO.Response> {
    if (Helper.isNotDefined(req.id)) {
      return left(new AppError.RequiredFields());
    }

    try {
      const res = await this.emailTemplateService.getEmailTemplateById(req);
      if (Helper.isNotDefined(res[0])) {
        return left(new AppError.DataNotFound());
      }
      const {
        monthYear,
        id,
        name,
        description,
        active,
        author,
        emailList,
        templateContent
      } = res[0];
      const formattedResponse = {
        id,
        name,
        description,
        active,
        author,
        emailList: Helper.isDefined(emailList) ? emailList : undefined,
        templateContent: Helper.isDefined(templateContent)
          ? templateContent
          : '',
        monthYear: Helper.isDefined(monthYear)
          ? FormatHelper.formatIsoDateToDdMmYyyy(monthYear)
          : ''
      };
      return right(Result.ok(formattedResponse));
    } catch (err) {
      if (HttpHelper.isNotFoundError(err as CallError)) {
        return left(new AppError.DataNotFound(err));
      }

      if (HttpHelper.isBadRequestError(err as CallError)) {
        return left(new AppError.BadRequest(err));
      }

      if (HttpHelper.isUnauthorizedError(err as CallError)) {
        return left(new AppError.AccessDeniedError(err));
      }
      return left(new AppError.UnexpectedError(err));
    }
  }
}
