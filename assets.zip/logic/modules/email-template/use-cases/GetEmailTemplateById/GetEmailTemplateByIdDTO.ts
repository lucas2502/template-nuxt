import { AppError } from 'core/base/AppError';
import type { Either } from 'core/base/Either';
import { Result } from 'core/base/Result';

export namespace GetEmailTemplateByIdDTO {
  export interface Request {
    id: string;
  }

  export interface ResponseBody {
    id: string;
    name: string;
    description?: string;
    emailList?: string[];
    templateContent?: string;
    author?: string;
    monthYear: string;
    active: boolean;
  }

  export type Response = Either<
    | AppError.UnexpectedError
    | AppError.DataNotFound
    | AppError.BadRequest
    | AppError.Unauthorized
    | AppError.RequiredFields,
    Result<ResponseBody>
  >;
}
