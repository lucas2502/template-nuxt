import { EmailTemplateService } from '../../services/EmailTemplateService';
import { EmailTemplateServiceMock } from '../../services/EmailTemplateServiceMock';
import { DeleteEmailTemplateUseCase } from './DeleteEmailTemplateUseCase';
import { Helper } from '@/core/helpers/Helper';
import { HttpAdapter } from '@/core/adapter/HttpAdapter';

const MOCK = Helper.isTestMode();

const httpAdapter = new HttpAdapter();

const profileService = MOCK
  ? new EmailTemplateServiceMock()
  : new EmailTemplateService(httpAdapter);

const deleteEmailTemplateUseCase = new DeleteEmailTemplateUseCase(
  profileService
);

export default deleteEmailTemplateUseCase;
