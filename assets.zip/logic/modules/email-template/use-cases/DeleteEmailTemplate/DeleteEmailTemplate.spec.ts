import { EmailTemplateServiceMock } from '../../services/EmailTemplateServiceMock';
import { DeleteEmailTemplateDTO } from './DeleteEmailTemplateDTO';
import { DeleteEmailTemplateUseCase } from './DeleteEmailTemplateUseCase';
import { UseCase } from '@/core/base/UseCase';
import { UseCaseError } from '@/core/base/UseCaseError';
import { ErrorCodeEnum } from '@/core/enums/ErrorCodeEnum';

describe('UseCase: EmailTemplate/DeleteEmailTemplate', () => {
  let useCase: UseCase<
    DeleteEmailTemplateDTO.Request,
    DeleteEmailTemplateDTO.Response
  >;

  beforeAll(async () => {
    useCase = (await import('.')).default;
  });

  const mockData = {
    id: '0'
  };

  test('should get all emailTemplates with success', async () => {
    const res = await useCase.execute(mockData);
    expect(res.isRight()).toBe(true);
    const successValue =
      res.value.getValue() as DeleteEmailTemplateDTO.ResponseBody;
    expect(successValue.success).toBeDefined();
  });

  test('should return Unexpected Error', async () => {
    const service = new EmailTemplateServiceMock();

    const spy = vi.spyOn(service, 'deleteEmailTemplate');

    spy.mockImplementationOnce((): any => {
      return Promise.reject(new Error('Unexpexted error'));
    });

    const useCase = new DeleteEmailTemplateUseCase(service);

    const res = await useCase.execute(mockData);

    expect(res.isRight()).toBe(false);

    const errorValue = (
      res as DeleteEmailTemplateDTO.Response
    ).value.errorValue() as UseCaseError;

    expect(errorValue.code).toBe(ErrorCodeEnum.UnexpectedError);
  });

  test('should return Bad Request Error', async () => {
    const service = new EmailTemplateServiceMock();

    const spy = vi.spyOn(service, 'deleteEmailTemplate');

    spy.mockImplementationOnce((): any => {
      return Promise.reject(new Error('400 Bad Request'));
    });

    const useCase = new DeleteEmailTemplateUseCase(service);

    const res = await useCase.execute(mockData);

    expect(res.isRight()).toBe(false);

    const errorValue = (
      res as DeleteEmailTemplateDTO.Response
    ).value.errorValue() as UseCaseError;

    expect(errorValue.code).toBe(ErrorCodeEnum.BadRequest);
  });

  test('should return Access Denied Error', async () => {
    const service = new EmailTemplateServiceMock();

    const spy = vi.spyOn(service, 'deleteEmailTemplate');

    spy.mockImplementationOnce((): any => {
      return Promise.reject(new Error('401 Access Denied'));
    });

    const useCase = new DeleteEmailTemplateUseCase(service);

    const res = await useCase.execute(mockData);

    expect(res.isRight()).toBe(false);

    const errorValue = (
      res as DeleteEmailTemplateDTO.Response
    ).value.errorValue() as UseCaseError;

    expect(errorValue.code).toBe(ErrorCodeEnum.AccessDenied);
  });
});
