import { AppError } from 'core/base/AppError';
import type { Either } from 'core/base/Either';
import { Result } from 'core/base/Result';

export namespace CreateEmailTemplateDTO {
  export interface EmailTemplate {
    templateName: string;
    description: string;
    emailList?: string[];
    templateContent: string;
  }

  export interface Request extends EmailTemplate {}

  export interface ResponseBody {
    success: boolean;
  }

  export type Response = Either<
    AppError.UnexpectedError | AppError.BadRequest | AppError.Unauthorized,
    Result<ResponseBody>
  >;
}
