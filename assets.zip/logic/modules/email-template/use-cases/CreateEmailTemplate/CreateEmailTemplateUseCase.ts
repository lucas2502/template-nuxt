import { IEmailTemplateService } from '../../services/EmailTemplateService';
import { CreateEmailTemplateDTO } from './CreateEmailTemplateDTO';
import { UseCase } from '@/core/base/UseCase';
import { AppError } from '@/core/base/AppError';
import { left, right } from '@/core/base/Either';
import { Result } from '@/core/base/Result';
import { CallError } from '@/core/types/ErrorType';
import { HttpHelper } from '@/core/helpers/HttpHelper';

export class CreateEmailTemplateUseCase
  implements
    UseCase<CreateEmailTemplateDTO.Request, CreateEmailTemplateDTO.Response>
{
  constructor(private emailTemplateService: IEmailTemplateService) {
    this.emailTemplateService = emailTemplateService;
  }

  public async execute(
    req: CreateEmailTemplateDTO.Request
  ): Promise<CreateEmailTemplateDTO.Response> {
    try {
      const res = await this.emailTemplateService.createEmailTemplate(req);
      return right(Result.ok(res));
    } catch (err) {
      if (HttpHelper.isNotFoundError(err as CallError)) {
        return left(new AppError.DataNotFound(err));
      }
      if (HttpHelper.isUnauthorizedError(err as CallError)) {
        return left(new AppError.AccessDeniedError(err));
      }
      return left(new AppError.UnexpectedError(err));
    }
  }
}
