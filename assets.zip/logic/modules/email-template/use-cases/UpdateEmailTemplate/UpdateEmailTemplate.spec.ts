import { EmailTemplateServiceMock } from '../../services/EmailTemplateServiceMock';
import { UpdateEmailTemplateDTO } from './UpdateEmailTemplateDTO';
import { UpdateEmailTemplateUseCase } from './UpdateEmailTemplateUseCase';
import { UseCase } from '@/core/base/UseCase';
import { UseCaseError } from '@/core/base/UseCaseError';
import { ErrorCodeEnum } from '@/core/enums/ErrorCodeEnum';

describe('UseCase: EmailTemplate/UpdateEmailTemplateDTO', () => {
  let useCase: UseCase<
    UpdateEmailTemplateDTO.Request,
    UpdateEmailTemplateDTO.Response
  >;

  beforeAll(async () => {
    useCase = (await import('.')).default;
  });

  const mockData = {
    id: '0',
    templateName: 'Esse é um teste de template',
    description: 'Descrição de conteudo do email teste',
    emailList: ['teste@teste.com.br'],
    templateContent: '<h4>Esse é um teste de template</h4>'
  };

  test('should get all emailTemplates with success', async () => {
    const res = await useCase.execute(mockData);
    expect(res.isRight()).toBe(true);
    const successValue =
      res.value.getValue() as UpdateEmailTemplateDTO.ResponseBody;
    expect(successValue.id).toBeDefined();
  });

  test('should return Unexpected Error', async () => {
    const service = new EmailTemplateServiceMock();

    const spy = vi.spyOn(service, 'updateEmailTemplate');

    spy.mockImplementationOnce((): any => {
      return Promise.reject(new Error('Unexpexted error'));
    });

    const useCase = new UpdateEmailTemplateUseCase(service);

    const res = await useCase.execute(mockData);

    expect(res.isRight()).toBe(false);

    const errorValue = (
      res as UpdateEmailTemplateDTO.Response
    ).value.errorValue() as UseCaseError;

    expect(errorValue.code).toBe(ErrorCodeEnum.UnexpectedError);
  });

  test('should return Bad Request Error', async () => {
    const service = new EmailTemplateServiceMock();

    const spy = vi.spyOn(service, 'updateEmailTemplate');

    spy.mockImplementationOnce((): any => {
      return Promise.reject(new Error('400 Bad Request'));
    });

    const useCase = new UpdateEmailTemplateUseCase(service);

    const res = await useCase.execute(mockData);

    expect(res.isRight()).toBe(false);

    const errorValue = (
      res as UpdateEmailTemplateDTO.Response
    ).value.errorValue() as UseCaseError;

    expect(errorValue.code).toBe(ErrorCodeEnum.BadRequest);
  });

  test('should return Access Denied Error', async () => {
    const service = new EmailTemplateServiceMock();

    const spy = vi.spyOn(service, 'updateEmailTemplate');

    spy.mockImplementationOnce((): any => {
      return Promise.reject(new Error('401 Access Denied'));
    });

    const useCase = new UpdateEmailTemplateUseCase(service);

    const res = await useCase.execute(mockData);

    expect(res.isRight()).toBe(false);

    const errorValue = (
      res as UpdateEmailTemplateDTO.Response
    ).value.errorValue() as UseCaseError;

    expect(errorValue.code).toBe(ErrorCodeEnum.AccessDenied);
  });
});
