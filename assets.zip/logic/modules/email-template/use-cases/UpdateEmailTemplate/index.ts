import { EmailTemplateService } from '../../services/EmailTemplateService';
import { EmailTemplateServiceMock } from '../../services/EmailTemplateServiceMock';
import { UpdateEmailTemplateUseCase } from './UpdateEmailTemplateUseCase';
import { Helper } from '@/core/helpers/Helper';
import { HttpAdapter } from '@/core/adapter/HttpAdapter';

const MOCK = Helper.isTestMode();

const httpAdapter = new HttpAdapter();

const profileService = MOCK
  ? new EmailTemplateServiceMock()
  : new EmailTemplateService(httpAdapter);

const updateEmailTemplateUseCase = new UpdateEmailTemplateUseCase(
  profileService
);

export default updateEmailTemplateUseCase;
