import { IEmailTemplateService } from '../../services/EmailTemplateService';
import { UpdateEmailTemplateDTO } from './UpdateEmailTemplateDTO';
import { UseCase } from '@/core/base/UseCase';
import { AppError } from '@/core/base/AppError';
import { left, right } from '@/core/base/Either';
import { Result } from '@/core/base/Result';
import { CallError } from '@/core/types/ErrorType';
import { HttpHelper } from '@/core/helpers/HttpHelper';

export class UpdateEmailTemplateUseCase
  implements
    UseCase<UpdateEmailTemplateDTO.Request, UpdateEmailTemplateDTO.Response>
{
  constructor(private emailTemplateService: IEmailTemplateService) {
    this.emailTemplateService = emailTemplateService;
  }

  public async execute(
    req: UpdateEmailTemplateDTO.Request
  ): Promise<UpdateEmailTemplateDTO.Response> {
    try {
      const res = await this.emailTemplateService.updateEmailTemplate(req);
      return right(Result.ok(res));
    } catch (err) {
      if (HttpHelper.isBadRequestError(err as CallError)) {
        return left(new AppError.BadRequest(err));
      }
      if (HttpHelper.isUnauthorizedError(err as CallError)) {
        return left(new AppError.AccessDeniedError(err));
      }
      return left(new AppError.UnexpectedError(err));
    }
  }
}
