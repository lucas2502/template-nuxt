import { AppError } from 'core/base/AppError';
import type { Either } from 'core/base/Either';
import { Result } from 'core/base/Result';

export namespace UpdateEmailTemplateDTO {
  export interface EmailTemplate {
    id: string;
    templateName: string;
    description: string;
    emailList?: string[];
    templateContent: string;
  }

  export interface Request extends EmailTemplate {}

  export interface ResponseBody {
    id: string;
  }

  export type Response = Either<
    AppError.UnexpectedError | AppError.BadRequest | AppError.Unauthorized,
    Result<ResponseBody>
  >;
}
