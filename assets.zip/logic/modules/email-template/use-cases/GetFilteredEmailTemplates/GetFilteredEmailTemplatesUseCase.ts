import { IEmailTemplateService } from '../../services/EmailTemplateService';
import { GetFilteredEmailTemplatesDTO } from './GetFilteredEmailTemplatesDTO';
import { UseCase } from '@/core/base/UseCase';
import { AppError } from '@/core/base/AppError';
import { left, right } from '@/core/base/Either';
import { Result } from '@/core/base/Result';
import { CallError } from '@/core/types/ErrorType';
import { HttpHelper } from '@/core/helpers/HttpHelper';
import { Helper } from '@/core/helpers/Helper';
import { FormatHelper } from '@/core/helpers/FormatHelper';

export class GetFilteredEmailTemplatesUseCase
  implements
    UseCase<
      GetFilteredEmailTemplatesDTO.Request,
      GetFilteredEmailTemplatesDTO.Response
    >
{
  constructor(private emailTemplateService: IEmailTemplateService) {
    this.emailTemplateService = emailTemplateService;
  }

  public async execute(
    req: GetFilteredEmailTemplatesDTO.Request
  ): Promise<GetFilteredEmailTemplatesDTO.Response> {
    try {
      const body = {
        ...req,
        startDate: req.startDate
          ? FormatHelper.parseYyyyMmDdToDate(req.startDate)
          : undefined,
        endDate: req.endDate
          ? FormatHelper.parseYyyyMmDdToDate(req.endDate)
          : undefined
      };
      const res = await this.emailTemplateService.getFilteredEmailTemplates(
        body
      );

      const formattedResponse = res.map(item => ({
        ...item,
        monthYear: item.monthYear
          ? Helper.formatIsoDateToDdMmYyyy(item.monthYear)
          : ''
      }));
      return right(Result.ok(formattedResponse));
    } catch (err) {
      if (HttpHelper.isNotFoundError(err as CallError)) {
        return left(new AppError.DataNotFound(err));
      }
      if (HttpHelper.isUnauthorizedError(err as CallError)) {
        return left(new AppError.AccessDeniedError(err));
      }
      if (HttpHelper.isBadRequestError(err as CallError)) {
        return left(new AppError.BadRequest(err));
      }
      return left(new AppError.UnexpectedError(err));
    }
  }
}
