import { EmailTemplateServiceMock } from '../../services/EmailTemplateServiceMock';
import { EmailTemplateService } from '../../services/EmailTemplateService';
import { GetFilteredEmailTemplatesUseCase } from './GetFilteredEmailTemplatesUseCase';
import { Helper } from '@/core/helpers/Helper';
import { HttpAdapter } from '@/core/adapter/HttpAdapter';

const MOCK = Helper.isTestMode();

const httpAdapter = new HttpAdapter();

const profileService = MOCK
  ? new EmailTemplateServiceMock()
  : new EmailTemplateService(httpAdapter);

const getFilteredEmailTemplatesUseCase = new GetFilteredEmailTemplatesUseCase(
  profileService
);

export default getFilteredEmailTemplatesUseCase;
