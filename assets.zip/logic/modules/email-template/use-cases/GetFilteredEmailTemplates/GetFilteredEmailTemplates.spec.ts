import { EmailTemplateServiceMock } from '../../services/EmailTemplateServiceMock';
import { GetFilteredEmailTemplatesDTO } from './GetFilteredEmailTemplatesDTO';
import { GetFilteredEmailTemplatesUseCase } from './GetFilteredEmailTemplatesUseCase';
import { UseCaseError } from '@/core/base/UseCaseError';
import { UseCase } from '@/core/base/UseCase';
import { ErrorCodeEnum } from '@/core/enums/ErrorCodeEnum';

describe('UseCase: EmailTemplate/GetFilteredEmailTemplates', () => {
  let useCase: UseCase<
    GetFilteredEmailTemplatesDTO.Request,
    GetFilteredEmailTemplatesDTO.Response
  >;

  beforeAll(async () => {
    useCase = (await import('.')).default;
  });

  test('should get all emailTemplates with success', async () => {
    const res = await useCase.execute({
      templateName: 'Projeto'
    });

    expect(res.isRight()).toBe(true);

    const successValue =
      res.value.getValue() as GetFilteredEmailTemplatesDTO.ResponseBody;
    expect(successValue).toBeDefined();
  });

  test('should return Unexpected Error', async () => {
    const service = new EmailTemplateServiceMock();

    const spy = vi.spyOn(service, 'getFilteredEmailTemplates');

    spy.mockImplementationOnce((): any => {
      return Promise.reject(new Error('Unexpexted error'));
    });

    const useCase = new GetFilteredEmailTemplatesUseCase(service);

    const res = await useCase.execute({
      templateName: 'Projeto'
    });

    expect(res.isRight()).toBe(false);

    const errorValue = (
      res as GetFilteredEmailTemplatesDTO.Response
    ).value.errorValue() as UseCaseError;

    expect(errorValue.code).toBe(ErrorCodeEnum.UnexpectedError);
  });

  test('should return Not Found Error', async () => {
    const service = new EmailTemplateServiceMock();

    const spy = vi.spyOn(service, 'getFilteredEmailTemplates');

    spy.mockImplementationOnce((): any => {
      return Promise.reject(new Error('404 Not Found'));
    });

    const useCase = new GetFilteredEmailTemplatesUseCase(service);

    const res = await useCase.execute({
      templateName: 'Projeto'
    });

    expect(res.isRight()).toBe(false);

    const errorValue = (
      res as GetFilteredEmailTemplatesDTO.Response
    ).value.errorValue() as UseCaseError;

    expect(errorValue.code).toBe(ErrorCodeEnum.NotFound);
  });

  test('should return Access Denied Error', async () => {
    const service = new EmailTemplateServiceMock();

    const spy = vi.spyOn(service, 'getFilteredEmailTemplates');

    spy.mockImplementationOnce((): any => {
      return Promise.reject(new Error('401 Access Denied'));
    });

    const useCase = new GetFilteredEmailTemplatesUseCase(service);

    const res = await useCase.execute({
      templateName: 'Projeto'
    });

    expect(res.isRight()).toBe(false);

    const errorValue = (
      res as GetFilteredEmailTemplatesDTO.Response
    ).value.errorValue() as UseCaseError;

    expect(errorValue.code).toBe(ErrorCodeEnum.AccessDenied);
  });
});
