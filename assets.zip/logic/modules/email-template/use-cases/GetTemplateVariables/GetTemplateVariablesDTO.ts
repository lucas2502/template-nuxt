export namespace GetTemplateVariablesDTO {
  export interface variablesProps {
    key: string;
    value: string;
  }

  export interface ResponseBody {
    variables: Array<variablesProps>;
  }

  export type Response = ResponseBody;
}
