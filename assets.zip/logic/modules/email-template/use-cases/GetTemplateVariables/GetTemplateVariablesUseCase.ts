import { GetTemplateVariablesDTO } from './GetTemplateVariablesDTO';
import { UseCase } from '@/core/base/UseCase';

export class GetTemplateVariablesUseCase
  implements UseCase<undefined, GetTemplateVariablesDTO.Response>
{
  constructor(private emailTemplateService: any) {
    this.emailTemplateService = emailTemplateService;
  }

  public execute(): GetTemplateVariablesDTO.Response {
    return this.emailTemplateService.getTemplateVariables();
  }
}
