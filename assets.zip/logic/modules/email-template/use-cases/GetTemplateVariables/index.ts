import { EmailTemplateServiceMock } from '../../services/EmailTemplateServiceMock';
import { GetTemplateVariablesUseCase } from './GetTemplateVariablesUseCase';

const profileService = new EmailTemplateServiceMock();

const getTemplateVariablesUseCase = new GetTemplateVariablesUseCase(
  profileService
);

export default getTemplateVariablesUseCase;
