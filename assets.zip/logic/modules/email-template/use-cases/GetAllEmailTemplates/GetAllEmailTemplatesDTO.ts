import { AppError } from 'core/base/AppError';
import type { Either } from 'core/base/Either';
import { Result } from 'core/base/Result';

export namespace GetAllEmailTemplatesDTO {
  export interface EmailTemplate {
    id: string;
    name: string;
    description?: string;
    emailList?: string[];
    templateContent?: string;
    author?: string;
    monthYear: string;
    active: boolean;
  }

  export interface ResponseBody extends Array<EmailTemplate> {}

  export type Response = Either<
    | AppError.UnexpectedError
    | AppError.DataNotFound
    | AppError.BadRequest
    | AppError.Unauthorized,
    Result<ResponseBody>
  >;
}
