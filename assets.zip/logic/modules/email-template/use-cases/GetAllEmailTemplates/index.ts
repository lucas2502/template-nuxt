import { EmailTemplateServiceMock } from '../../services/EmailTemplateServiceMock';
import { EmailTemplateService } from '../../services/EmailTemplateService';
import { GetAllEmailTemplatesUseCase } from './GetAllEmailTemplatesUseCase';
import { HttpAdapter } from '@/core/adapter/HttpAdapter';
import { Helper } from '@/core/helpers/Helper';

const MOCK = Helper.isTestMode();

const httpAdapter = new HttpAdapter();

const profileService = MOCK
  ? new EmailTemplateServiceMock()
  : new EmailTemplateService(httpAdapter);

const getAllEmailTemplatesUseCase = new GetAllEmailTemplatesUseCase(
  profileService
);

export default getAllEmailTemplatesUseCase;
