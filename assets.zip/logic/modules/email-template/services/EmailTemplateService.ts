import { EmailTemplateServiceDTO } from './EmailTemplateServiceDTO';
import { HttpResponseBody } from '@/core/types/HttpResponseBody';
import { HttpAdapter } from '@/core/adapter/HttpAdapter';
import { Config } from '@/config';

export interface IEmailTemplateService {
  getAllEmailTemplates(): Promise<EmailTemplateServiceDTO.GetAllEmailTemplates.Output>;
  getFilteredEmailTemplates(
    input: EmailTemplateServiceDTO.GetFilteredEmailTemplates.input
  ): Promise<EmailTemplateServiceDTO.GetFilteredEmailTemplates.Output>;
  createEmailTemplate(
    input: EmailTemplateServiceDTO.CreateEmailTemplate.input
  ): Promise<EmailTemplateServiceDTO.CreateEmailTemplate.Output>;
  getEmailTemplateById(
    input: EmailTemplateServiceDTO.GetEmailTemplateById.input
  ): Promise<EmailTemplateServiceDTO.GetEmailTemplateById.Output>;
  updateEmailTemplate(
    input: EmailTemplateServiceDTO.UpdateEmailTemplate.input
  ): Promise<EmailTemplateServiceDTO.UpdateEmailTemplate.Output>;
  deleteEmailTemplate(
    input: EmailTemplateServiceDTO.deleteEmailTemplate.input
  ): Promise<EmailTemplateServiceDTO.deleteEmailTemplate.Output>;
}

export class EmailTemplateService implements IEmailTemplateService {
  constructor(private httpAdapter: HttpAdapter) {
    this.httpAdapter = httpAdapter;
  }

  async getAllEmailTemplates(): Promise<EmailTemplateServiceDTO.GetAllEmailTemplates.Output> {
    const url = `${Config.getInstance.apiBaseUrl}/email/api/v1/TemplateEmail`;

    const res: HttpResponseBody<EmailTemplateServiceDTO.GetAllEmailTemplates.Output> =
      await this.httpAdapter.get({
        url
      });

    return res.data;
  }

  async getFilteredEmailTemplates(
    input: EmailTemplateServiceDTO.GetFilteredEmailTemplates.input
  ): Promise<EmailTemplateServiceDTO.GetFilteredEmailTemplates.Output> {
    const url = `${Config.getInstance.apiBaseUrl}/email/api/v1/TemplateEmail/Search`;
    const body = { ...input };
    const res: HttpResponseBody<EmailTemplateServiceDTO.GetAllEmailTemplates.Output> =
      await this.httpAdapter.post({
        url,
        body
      });

    return res.data;
  }

  async createEmailTemplate(
    input: EmailTemplateServiceDTO.CreateEmailTemplate.input
  ): Promise<EmailTemplateServiceDTO.CreateEmailTemplate.Output> {
    const url = `${Config.getInstance.apiBaseUrl}/email/api/v1/TemplateEmail`;
    const body = { ...input };
    const res: HttpResponseBody<EmailTemplateServiceDTO.CreateEmailTemplate.Output> =
      await this.httpAdapter.post({
        url,
        body
      });

    return res.data;
  }

  async getEmailTemplateById(
    input: EmailTemplateServiceDTO.GetEmailTemplateById.input
  ): Promise<EmailTemplateServiceDTO.GetEmailTemplateById.Output> {
    const id = input.id;
    const url = `${Config.getInstance.apiBaseUrl}/email/api/v1/TemplateEmail/id/${id}`;
    const res: HttpResponseBody<EmailTemplateServiceDTO.GetEmailTemplateById.Output> =
      await this.httpAdapter.get({
        url
      });

    return res.data;
  }

  async updateEmailTemplate(
    input: EmailTemplateServiceDTO.UpdateEmailTemplate.input
  ): Promise<EmailTemplateServiceDTO.UpdateEmailTemplate.Output> {
    const url = `${Config.getInstance.apiBaseUrl}/email/api/v1/TemplateEmail`;
    const body = { ...input };
    const res: HttpResponseBody<EmailTemplateServiceDTO.UpdateEmailTemplate.Output> =
      await this.httpAdapter.put({
        url,
        body
      });

    return res.data;
  }

  async deleteEmailTemplate(
    input: EmailTemplateServiceDTO.deleteEmailTemplate.input
  ): Promise<EmailTemplateServiceDTO.deleteEmailTemplate.Output> {
    const templateId = input.templateId;
    const url = `${Config.getInstance.apiBaseUrl}/email/api/v1/TemplateEmail?templateId=${templateId}`;
    const res: HttpResponseBody<EmailTemplateServiceDTO.deleteEmailTemplate.Output> =
      await this.httpAdapter.delete({
        url
      });

    return res.data;
  }
}
