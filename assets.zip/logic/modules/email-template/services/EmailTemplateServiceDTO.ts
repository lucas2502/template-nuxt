import {
  EmailTemplateProps,
  createAndUpdateEmailTemplateProps
} from '../models/EmailTemplate';

export namespace EmailTemplateServiceDTO {
  export namespace GetAllEmailTemplates {
    export interface Output extends Array<EmailTemplateProps> {}
  }
  export namespace GetFilteredEmailTemplates {
    export interface input {
      templateName?: string;
      startDate?: string;
      endDate?: string;
    }
    export interface Output extends Array<EmailTemplateProps> {}
  }

  export namespace CreateEmailTemplate {
    export interface input extends createAndUpdateEmailTemplateProps {}
    export interface Output {
      success: boolean;
    }
  }

  export namespace GetEmailTemplateById {
    export interface input {
      id: string;
    }
    export interface Output extends Array<EmailTemplateProps> {}
  }

  export namespace UpdateEmailTemplate {
    export interface input extends createAndUpdateEmailTemplateProps {
      id: string;
    }
    export interface Output extends EmailTemplateProps {}
  }

  export namespace deleteEmailTemplate {
    export interface input {
      templateId: string;
    }
    export interface Output {
      success: boolean;
    }
  }

  export namespace getTemplateVariables {
    export interface variablesProps {
      key: string;
      value: string;
    }
    export interface Output {
      variables: Array<variablesProps>;
    }
  }
}
