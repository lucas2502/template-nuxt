import { IEmailTemplateService } from './EmailTemplateService';
import { EmailTemplateServiceDTO } from './EmailTemplateServiceDTO';

export class EmailTemplateServiceMock implements IEmailTemplateService {
  async getAllEmailTemplates(): Promise<EmailTemplateServiceDTO.GetAllEmailTemplates.Output> {
    const returnBody = [
      {
        id: '1ddsdsd-eq313-123123',
        name: 'Projeto A',
        description: 'Descrição do Projeto A',
        emailList: ['email1@example.com', 'email2@example.com'],
        templateContent: '<p>Conteúdo do modelo A</p>',
        author: 'Autor A',
        monthYear: 'Tue Jan 24 2024 10:30:00 GMT-0800', // Janeiro de 2024
        active: true
      },
      {
        id: '2',
        name: 'Projeto B',
        description: 'Descrição do Projeto B',
        emailList: ['email3@example.com', 'email4@example.com'],
        templateContent: '<p>Conteúdo do modelo B</p>',
        author: 'Autor B',
        monthYear: 'Tue Jan 24 2024 10:30:00 GMT-0800', // Fevereiro de 2024
        active: false
      },
      {
        id: '3',
        name: 'Projeto C',
        description: 'Descrição do Projeto C',
        emailList: ['email5@example.com', 'email6@example.com'],
        templateContent: '<p>Conteúdo do modelo C</p>',
        author: 'Autor C',
        monthYear: 'Tue Jan 24 2024 10:30:00 GMT-0800', // Março de 2024
        active: true
      }
    ];

    return await new Promise((resolve, reject) => {
      try {
        setTimeout(() => {
          resolve(returnBody);
        }, 1000);
      } catch (err) {
        return reject(err);
      }
    });
  }

  async getFilteredEmailTemplates(): Promise<EmailTemplateServiceDTO.GetFilteredEmailTemplates.Output> {
    const returnBody = [
      {
        id: '1',
        name: 'Projeto',
        description: 'Descrição do Projeto A',
        emailList: ['email1@example.com', 'email2@example.com'],
        templateContent: '<p>Conteúdo do modelo A</p>',
        author: 'Autor A',
        monthYear: 'Tue Jan 24 2024 10:30:00 GMT-0800',
        active: true
      },
      {
        id: '2',
        name: 'Projeto',
        description: 'Descrição do Projeto B',
        emailList: ['email3@example.com', 'email4@example.com'],
        templateContent: '<p>Conteúdo do modelo B</p>',
        author: 'Autor B',
        monthYear: 'Tue Jan 24 2024 10:30:00 GMT-0800',
        active: false
      },
      {
        id: '3',
        name: 'Projeto',
        description: 'Descrição do Projeto C',
        emailList: ['email5@example.com', 'email6@example.com'],
        templateContent: '<p>Conteúdo do modelo C</p>',
        author: 'Autor C',
        monthYear: 'Tue Jan 24 2024 10:30:00 GMT-0800',
        active: true
      }
    ];

    return await new Promise((resolve, reject) => {
      try {
        setTimeout(() => {
          resolve(returnBody);
        }, 1000);
      } catch (err) {
        return reject(err);
      }
    });
  }

  async createEmailTemplate(): Promise<EmailTemplateServiceDTO.CreateEmailTemplate.Output> {
    const returnBody = { success: true };

    return await new Promise((resolve, reject) => {
      try {
        setTimeout(() => {
          resolve(returnBody);
        }, 1000);
      } catch (err) {
        return reject(err);
      }
    });
  }

  async getEmailTemplateById(): Promise<EmailTemplateServiceDTO.GetEmailTemplateById.Output> {
    const returnBody = [
      {
        id: '1',
        name: 'Projeto',
        description: 'Descrição do Projeto A',
        emailList: ['email1@example.com', 'email2@example.com'],
        templateContent: '<h2>Conteúdo do modelo A</h2>',
        author: 'Autor A',
        monthYear: 'Tue Jan 24 2024 10:30:00 GMT-0800',
        active: true
      }
    ];

    return await new Promise((resolve, reject) => {
      try {
        setTimeout(() => {
          resolve(returnBody);
        }, 200);
      } catch (err) {
        return reject(err);
      }
    });
  }

  async updateEmailTemplate(
    input: EmailTemplateServiceDTO.UpdateEmailTemplate.input
  ): Promise<EmailTemplateServiceDTO.UpdateEmailTemplate.Output> {
    let returnBody: EmailTemplateServiceDTO.UpdateEmailTemplate.Output;
    if (input.id === '0') {
      returnBody = {
        id: '1',
        name: 'Projeto',
        description: 'Descrição do Projeto A',
        emailList: ['email1@example.com', 'email2@example.com'],
        templateContent: '<p>Conteúdo do modelo A</p>',
        author: 'Autor A',
        monthYear: 'Tue Jan 24 2024 10:30:00 GMT-0800',
        active: true
      };
    }

    return await new Promise((resolve, reject) => {
      try {
        setTimeout(() => {
          resolve(returnBody);
        }, 1000);
      } catch (err) {
        return reject(err);
      }
    });
  }

  async deleteEmailTemplate(
    input: EmailTemplateServiceDTO.deleteEmailTemplate.input
  ): Promise<EmailTemplateServiceDTO.deleteEmailTemplate.Output> {
    let returnBody: EmailTemplateServiceDTO.deleteEmailTemplate.Output;
    if (input.templateId === '0') {
      returnBody = {
        success: true
      };
    }
    return await new Promise((resolve, reject) => {
      try {
        setTimeout(() => {
          resolve(returnBody);
        }, 1000);
      } catch (err) {
        return reject(err);
      }
    });
  }

  getTemplateVariables(): EmailTemplateServiceDTO.getTemplateVariables.Output {
    const returnBody = {
      variables: [
        {
          key: 'Nome Completo',
          value: '%NOME_USUARIO%'
        },
        {
          key: 'Data Nascimento',
          value: '%DATA_NASCIMENTO%'
        },
        {
          key: 'Posto Graduação',
          value: '%POSTO_GRADUACAO%'
        },
        {
          key: 'Número RE',
          value: '%NUMERO_RE%'
        },
        {
          key: 'OPM do Usuário',
          value: '%OPM_USUARIO%'
        },
        {
          key: 'CPF do Usuário',
          value: '%CPF_USUARIO%'
        },
        {
          key: 'E-mail do Usuário',
          value: '%EMAIL_USUARIO%'
        },
        {
          key: 'Login do Usuário',
          value: '%LOGIN_USUARIO%'
        },
        {
          key: 'Data de Cadastro',
          value: '%DT_CADASTRO_USUARIO%'
        },
        {
          key: 'Data Alteração de Senha',
          value: '%DT_ALTERACAO_SENHA%'
        },
        {
          key: 'Logradouro do Endereço',
          value: '%LOGRADOURO_END_USUARIO%'
        },
        {
          key: 'Complemento do Endereço',
          value: '%COMPLEMENTO_END_USUARIO%'
        },
        {
          key: 'Número do Endereço',
          value: '%NUMERO_END_USUARIO%'
        },
        {
          key: 'CEP do Endereço',
          value: '%CEP_END_USUARIO%'
        },
        {
          key: 'Bairro do Endereço',
          value: '%BAIRRO_END_USUARIO%'
        },
        {
          key: 'Município do Endereço',
          value: '%MUNICIPIO_END_USUARIO%'
        },
        {
          key: 'Estado do Endereço',
          value: '%ESTADO_END_USUARIO%'
        }
      ]
    };
    return returnBody;
  }
}
