export interface EmailTemplateProps {
  id: string;
  name: string;
  description?: string;
  emailList?: string[];
  templateContent?: string;
  author?: string;
  monthYear: string;
  active: boolean;
}

export interface createAndUpdateEmailTemplateProps {
  templateName?: string;
  description?: string;
  emailList?: string[];
  templateContent?: string;
}
