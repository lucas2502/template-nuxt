export interface Term {
  id: string;
  name?: string;
  content?: string;
}

export interface TermWithoutContent {
  termId: string;
  name?: string;
  approvedAt?: string;
  updateRequestAt?: string;
  updateRequestOwner?: string;
  hasUpdateRequest: boolean;
}
