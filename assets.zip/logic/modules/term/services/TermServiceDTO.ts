import { ApproveTypeKey, TermTypeKey } from '../enums/TermTypeEnum';
import { Term, TermWithoutContent } from '../models/Term';

export namespace TermServiceDTO {
  export namespace GetTermGrid {
    export interface Output extends TermWithoutContent {}
  }
  export namespace GetTermGriById {
    export interface input {
      id: string;
    }
    export interface Output extends Term {}
  }

  export namespace GetTermByType {
    export interface input {
      termType: TermTypeKey;
    }
    export interface Output extends Term {}
  }

  export namespace ApproveTerm {
    export interface input {
      termId: string;
      action: ApproveTypeKey;
      reason?: string;
    }
    export type Output = void;
  }

  export namespace UpdateTermContent {
    export interface input {
      content: string;
    }
    export interface Output extends TermWithoutContent {}
  }

  export namespace AcceptTerm {
    export interface Input {
      termId: string;
    }
    export type Output = void;
  }

  export namespace GetTermAgreement {
    export interface Input {
      termId: string;
    }
    export interface Output {
      username: string;
      accepted: boolean;
    }
  }
}
