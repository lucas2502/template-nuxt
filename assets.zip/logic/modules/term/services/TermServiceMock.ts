import { TermServiceDTO } from './TermServiceDTO';
import { ITermService } from '@/modules/term/services/TermService';

export class TermServiceMock implements ITermService {
  async getTermGrid(): Promise<TermServiceDTO.GetTermGrid.Output> {
    const returnBody = {
      termId: 'th211s-w423s2s-s2243s',
      name: 'Termo de confidencialidade',
      approvedAt: '2024-02-01T12:20:07.313Z',
      updateRequestAt: '2024-02-01T12:20:07.313Z',
      updateRequestOwner: 'Steve Jobs',
      hasUpdateRequest: true
    };

    return await new Promise((resolve, reject) => {
      try {
        setTimeout(() => {
          return resolve(returnBody);
        }, 1000);
      } catch (err) {
        return reject(err);
      }
    });
  }

  async getTermGridById(): Promise<TermServiceDTO.GetTermGriById.Output> {
    const returnBody = {
      id: '1',
      name: 'Termo de confidencialidade',
      content: '<p>Teste em mock do content</p>',
      editor: 'string',
      approver: 'Steve Jobs',
      lastPendingEditDate: '2024-02-01T12:42:46.355Z',
      lastApprovalDate: '2024-02-01T12:42:46.355Z'
    };

    return await new Promise((resolve, reject) => {
      try {
        setTimeout(() => {
          return resolve(returnBody);
        }, 1000);
      } catch (err) {
        return reject(err);
      }
    });
  }

  async getTermByType(): Promise<TermServiceDTO.GetTermByType.Output> {
    const returnBody = {
      id: '1',
      name: 'Termo de confidencialidade',
      content: `<h6>TERMO DE COMPROMISSO DE MANUTENÇÃO DE SIGILO</h6><br/>
      <p>Eu, <bold>Lucas Gonçalves de França </bold>, portador do documento de identidade
      <bold>012345-55</bold> e CPF <bold>123.456.789-00</bold> de acordo com o prescrito nos artigos 59 e 60
      do Decreto Federal nº 4.553/02, comprometo-me a guardar sigilo sobre todos os
      assuntos e atividades dos quais tenha tomado conhecimento ou tido acesso no
      desempenho de minhas funções no (a) Centro Integrado de Apoio Financeiro e
      demais OPM da Polícia Militar do Estado de São Paulo e, ainda, tomar todas as
      medidas de segurança adequadas à proteção dos documentos, dos materiais, das áreas e dos sistemas de informações sigilosos sob minha responsabilidade e
      custódia.</p>
      <p>Declaro ainda, estar ciente da aplicação da legislação, especial e comum (artigos 153, 154, 314, 325 e 326 do Código Penal Brasileiro; artigo 207 do Código de Processo Penal Brasileiro; artigos 4º, 6º, 23 e 25 da Lei nº 8.159/91 – Lei de Arquivos; e do Decreto Federal nº 4.553/02 – Normas para Salvaguarda), sem prejuízo de outras sanções de natureza administrativa que possam advir do não cumprimento do presente termo.</p>
      <p><bold>São Paulo, 29 de agosto de 2023</bold></p>`,
      editor: 'string',
      approver: 'Steve Jobs',
      lastPendingEditDate: '2024-02-01T12:42:46.355Z',
      lastApprovalDate: '2024-02-01T12:42:46.355Z'
    };

    return await new Promise((resolve, reject) => {
      try {
        setTimeout(() => {
          return resolve(returnBody);
        }, 1000);
      } catch (err) {
        return reject(err);
      }
    });
  }

  async approveTerm(): Promise<TermServiceDTO.ApproveTerm.Output> {
    return await new Promise((resolve, reject) => {
      try {
        setTimeout(() => {
          return resolve();
        }, 1000);
      } catch (err) {
        return reject(err);
      }
    });
  }

  async updateTermContent(): Promise<TermServiceDTO.UpdateTermContent.Output> {
    const returnBody = {
      termId: '1',
      name: 'Termo de confidencialidade',
      content: `<h6>TERMO DE COMPROMISSO DE MANUTENÇÃO DE SIGILO</h6><br/>
      <p>Eu, <bold>Lucas Gonçalves de França </bold>, portador do documento de identidade
      <bold>012345-55</bold> e CPF <bold>123.456.789-00</bold> de acordo com o prescrito nos artigos 59 e 60
      do Decreto Federal nº 4.553/02, comprometo-me a guardar sigilo sobre todos os
      assuntos e atividades dos quais tenha tomado conhecimento ou tido acesso no
      desempenho de minhas funções no (a) Centro Integrado de Apoio Financeiro e
      demais OPM da Polícia Militar do Estado de São Paulo e, ainda, tomar todas as
      medidas de segurança adequadas à proteção dos documentos, dos materiais, das áreas e dos sistemas de informações sigilosos sob minha responsabilidade e
      custódia.</p>
      <p>Declaro ainda, estar ciente da aplicação da legislação, especial e comum (artigos 153, 154, 314, 325 e 326 do Código Penal Brasileiro; artigo 207 do Código de Processo Penal Brasileiro; artigos 4º, 6º, 23 e 25 da Lei nº 8.159/91 – Lei de Arquivos; e do Decreto Federal nº 4.553/02 – Normas para Salvaguarda), sem prejuízo de outras sanções de natureza administrativa que possam advir do não cumprimento do presente termo.</p>
      <p><bold>São Paulo, 29 de agosto de 2023</bold></p>`,
      hasUpdateRequest: true,
      updateRequestOwner: 'Steve Jobs',
      updateRequestAt: '2024-02-01T12:42:46.355Z',
      approvedAt: '2024-02-01T12:42:46.355Z'
    };

    return await new Promise((resolve, reject) => {
      try {
        setTimeout(() => {
          return resolve(returnBody);
        }, 1000);
      } catch (err) {
        return reject(err);
      }
    });
  }

  async acceptTerm(): Promise<TermServiceDTO.AcceptTerm.Output> {
    return await new Promise((resolve, reject) => {
      try {
        setTimeout(() => {
          return resolve();
        }, 1000);
      } catch (err) {
        return reject(err);
      }
    });
  }

  async getTermAgreement(): Promise<TermServiceDTO.GetTermAgreement.Output> {
    const returnBody = {
      username: 'João da Silva',
      accepted: false
    };

    return await new Promise((resolve, reject) => {
      try {
        setTimeout(() => {
          return resolve(returnBody);
        }, 1000);
      } catch (err) {
        return reject(err);
      }
    });
  }
}
