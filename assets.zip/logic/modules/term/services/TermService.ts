import { TermServiceDTO } from './TermServiceDTO';
import { HttpResponseBody } from '@/core/types/HttpResponseBody';
import { HttpAdapter } from '@/core/adapter/HttpAdapter';
import { Config } from '@/config';

export interface ITermService {
  getTermGrid(): Promise<TermServiceDTO.GetTermGrid.Output>;
  getTermGridById(
    input: TermServiceDTO.GetTermGriById.input
  ): Promise<TermServiceDTO.GetTermGriById.Output>;
  getTermByType(
    input: TermServiceDTO.GetTermByType.input
  ): Promise<TermServiceDTO.GetTermByType.Output>;
  approveTerm(
    input: TermServiceDTO.ApproveTerm.input
  ): Promise<TermServiceDTO.ApproveTerm.Output>;
  updateTermContent(
    input: TermServiceDTO.UpdateTermContent.input
  ): Promise<TermServiceDTO.UpdateTermContent.Output>;
  acceptTerm(
    input: TermServiceDTO.AcceptTerm.Input
  ): Promise<TermServiceDTO.AcceptTerm.Output>;
  getTermAgreement(
    input: TermServiceDTO.GetTermAgreement.Input
  ): Promise<TermServiceDTO.GetTermAgreement.Output>;
}

export class TermService implements ITermService {
  constructor(private httpAdapter: HttpAdapter) {
    this.httpAdapter = httpAdapter;
  }

  async getTermGrid(): Promise<TermServiceDTO.GetTermGrid.Output> {
    const url = `${Config.getInstance.apiBaseUrl}/acceptanceterm/api/v1/Term`;

    const res: HttpResponseBody<TermServiceDTO.GetTermGrid.Output> =
      await this.httpAdapter.get({
        url
      });

    return res.data;
  }

  async getTermGridById(
    input: TermServiceDTO.GetTermGriById.input
  ): Promise<TermServiceDTO.GetTermGriById.Output> {
    const id = input.id;
    const url = `${Config.getInstance.apiBaseUrl}/acceptanceterm/api/v1/Term/${id}/GetById`;

    const res: HttpResponseBody<TermServiceDTO.GetTermGriById.Output> =
      await this.httpAdapter.get({
        url
      });

    return res.data;
  }

  async getTermByType(
    input: TermServiceDTO.GetTermByType.input
  ): Promise<TermServiceDTO.GetTermByType.Output> {
    const type = input.termType;
    const url = `${Config.getInstance.apiBaseUrl}/acceptanceterm/api/v1/Term/GetByType?TermType=${type}`;

    const res: HttpResponseBody<TermServiceDTO.GetTermByType.Output> =
      await this.httpAdapter.get({
        url
      });

    return res.data;
  }

  async approveTerm(
    input: TermServiceDTO.ApproveTerm.input
  ): Promise<TermServiceDTO.ApproveTerm.Output> {
    const url = `${Config.getInstance.apiBaseUrl}/acceptanceterm/api/v1/Term/Approve`;
    const body = { ...input };
    const res: HttpResponseBody<TermServiceDTO.ApproveTerm.Output> =
      await this.httpAdapter.post({
        url,
        body
      });

    return res.data;
  }

  async updateTermContent(
    input: TermServiceDTO.UpdateTermContent.input
  ): Promise<TermServiceDTO.UpdateTermContent.Output> {
    const url = `${Config.getInstance.apiBaseUrl}/acceptanceterm/api/v1/Term`;
    const body = { ...input };
    const res: HttpResponseBody<TermServiceDTO.UpdateTermContent.Output> =
      await this.httpAdapter.post({
        url,
        body
      });

    return res.data;
  }

  async acceptTerm(
    input: TermServiceDTO.AcceptTerm.Input
  ): Promise<TermServiceDTO.AcceptTerm.Output> {
    const url = `${Config.getInstance.apiBaseUrl}/acceptanceterm/api/v1/Term/AcceptTerm`;

    const body = { ...input };

    const res: HttpResponseBody<TermServiceDTO.AcceptTerm.Output> =
      await this.httpAdapter.post({
        url,
        body
      });

    return res.data;
  }

  async getTermAgreement(
    input: TermServiceDTO.GetTermAgreement.Input
  ): Promise<TermServiceDTO.GetTermAgreement.Output> {
    const termId = input.termId;

    const url = `${Config.getInstance.apiBaseUrl}/acceptanceterm/api/v1/Term/${termId}/GetTermAgreement`;

    const res: HttpResponseBody<TermServiceDTO.GetTermAgreement.Output> =
      await this.httpAdapter.get({
        url
      });

    return res.data;
  }
}
