import { AppError } from 'core/base/AppError';
import type { Either } from 'core/base/Either';
import { Result } from 'core/base/Result';
import { ApproveTypeKey } from '../../enums/TermTypeEnum';

export namespace ApproveTermDTO {
  export interface Request {
    id: string;
    action: ApproveTypeKey;
    reason?: string;
  }
  export type ResponseBody = void;

  export type Response = Either<
    | AppError.UnexpectedError
    | AppError.BadRequest
    | AppError.Unauthorized
    | AppError.RequiredFields,
    Result<ResponseBody>
  >;
}
