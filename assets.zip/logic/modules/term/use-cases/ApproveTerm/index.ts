import { TermService } from '../../services/TermService';
import { TermServiceMock } from '../../services/TermServiceMock';
import { ApproveTermUseCase } from './ApproveTermUseCase';
import { HttpAdapter } from '@/core/adapter/HttpAdapter';
import { Helper } from '@/core/helpers/Helper';

const MOCK = Helper.isTestMode();

const httpAdapter = new HttpAdapter();

const termService = MOCK ? new TermServiceMock() : new TermService(httpAdapter);

const approveTermUseCase = new ApproveTermUseCase(termService);

export default approveTermUseCase;
