import { ApproveType } from '../../enums/TermTypeEnum';
import { TermServiceMock } from '../../services/TermServiceMock';
import { ApproveTermDTO } from './ApproveTermDTO';
import { ApproveTermUseCase } from './ApproveTermUseCase';
import { UseCase } from '@/core/base/UseCase';
import { UseCaseError } from '@/core/base/UseCaseError';
import { ErrorCodeEnum } from '@/core/enums/ErrorCodeEnum';

describe('UseCase: getTermGrid/ApproveTerm', () => {
  let useCase: UseCase<ApproveTermDTO.Request, ApproveTermDTO.Response>;
  const mockData = {
    id: 'ji23j23-332jj22-nnnbvggh222',
    action: ApproveType.REJECT,
    reason: 'teste'
  };
  beforeAll(async () => {
    useCase = (await import('.')).default;
  });

  test('should get termGrid with success', async () => {
    const res = await useCase.execute(mockData);
    expect(res.isRight()).toBe(true);
  });

  test('should return Unexpected Error', async () => {
    const service = new TermServiceMock();

    const spy = vi.spyOn(service, 'approveTerm');

    spy.mockImplementationOnce((): any => {
      return Promise.reject(new Error('Unexpexted error'));
    });

    const useCase = new ApproveTermUseCase(service);

    const res = await useCase.execute(mockData);

    expect(res.isRight()).toBe(false);

    const errorValue = (
      res as ApproveTermDTO.Response
    ).value.errorValue() as UseCaseError;

    expect(errorValue.code).toBe(ErrorCodeEnum.UnexpectedError);
  });

  test('should return Access Denied Error', async () => {
    const service = new TermServiceMock();

    const spy = vi.spyOn(service, 'approveTerm');

    spy.mockImplementationOnce((): any => {
      return Promise.reject(new Error('401 Access Denied'));
    });

    const useCase = new ApproveTermUseCase(service);

    const res = await useCase.execute(mockData);

    expect(res.isRight()).toBe(false);

    const errorValue = (
      res as ApproveTermDTO.Response
    ).value.errorValue() as UseCaseError;

    expect(errorValue.code).toBe(ErrorCodeEnum.AccessDenied);
  });
});
