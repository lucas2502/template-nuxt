import { ITermService } from '../../services/TermService';
import { ApproveTermDTO } from './ApproveTermDTO';
import { UseCase } from '@/core/base/UseCase';
import { AppError } from '@/core/base/AppError';
import { left, right } from '@/core/base/Either';
import { Result } from '@/core/base/Result';
import { CallError } from '@/core/types/ErrorType';
import { HttpHelper } from '@/core/helpers/HttpHelper';

export class ApproveTermUseCase
  implements UseCase<ApproveTermDTO.Request, ApproveTermDTO.Response>
{
  constructor(private termService: ITermService) {
    this.termService = termService;
  }

  public async execute(
    req: ApproveTermDTO.Request
  ): Promise<ApproveTermDTO.Response> {
    try {
      const { action, id, reason } = req;
      const formattedRequest = {
        termId: id,
        action,
        reason
      };
      const res = await this.termService.approveTerm(formattedRequest);
      return right(Result.ok(res));
    } catch (err) {
      if (HttpHelper.isBadRequestError(err as CallError)) {
        return left(new AppError.BadRequest(err));
      }

      if (HttpHelper.isUnauthorizedError(err as CallError)) {
        return left(new AppError.AccessDeniedError(err));
      }
      return left(new AppError.UnexpectedError(err));
    }
  }
}
