import { AppError } from 'core/base/AppError';
import type { Either } from 'core/base/Either';
import { Result } from 'core/base/Result';

export namespace GetTermAgreementDTO {
  export interface Request {
    id: string;
  }
  export interface ResponseBody {
    username: string;
    accepted: boolean;
  }

  export type Response = Either<
    | AppError.UnexpectedError
    | AppError.DataNotFound
    | AppError.BadRequest
    | AppError.Unauthorized
    | AppError.RequiredFields,
    Result<ResponseBody>
  >;
}
