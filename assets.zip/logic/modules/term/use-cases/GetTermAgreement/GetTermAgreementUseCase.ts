import { ITermService } from '../../services/TermService';
import { GetTermAgreementDTO } from './GetTermAgreementDTO';
import { UseCase } from '@/core/base/UseCase';
import { AppError } from '@/core/base/AppError';
import { left, right } from '@/core/base/Either';
import { Result } from '@/core/base/Result';
import { CallError } from '@/core/types/ErrorType';
import { HttpHelper } from '@/core/helpers/HttpHelper';

export class GetTermAgreementUseCase
  implements UseCase<GetTermAgreementDTO.Request, GetTermAgreementDTO.Response>
{
  constructor(private termService: ITermService) {
    this.termService = termService;
  }

  public async execute(
    req: GetTermAgreementDTO.Request
  ): Promise<GetTermAgreementDTO.Response> {
    try {
      const input = {
        termId: req.id
      };

      const res = await this.termService.getTermAgreement(input);
      const { username, accepted } = res;
      const validantion = {
        username,
        accepted
      };
      return right(Result.ok(validantion));
    } catch (err) {
      if (HttpHelper.isNotFoundError(err as CallError)) {
        return left(new AppError.DataNotFound(err));
      }

      if (HttpHelper.isBadRequestError(err as CallError)) {
        return left(new AppError.BadRequest(err));
      }

      if (HttpHelper.isUnauthorizedError(err as CallError)) {
        return left(new AppError.AccessDeniedError(err));
      }
      return left(new AppError.UnexpectedError(err));
    }
  }
}
