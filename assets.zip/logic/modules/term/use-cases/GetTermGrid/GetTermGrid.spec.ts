import { TermServiceMock } from '../../services/TermServiceMock';
import { GetTermGridUseCase } from './GetTermGridUseCase';
import { GetTermGridDTO } from './GetTermGridDTO';
import { UseCase } from '@/core/base/UseCase';
import { UseCaseError } from '@/core/base/UseCaseError';
import { ErrorCodeEnum } from '@/core/enums/ErrorCodeEnum';

describe('UseCase: getTermGrid/GetEmailTemplateById', () => {
  let useCase: UseCase<undefined, GetTermGridDTO.Response>;
  beforeAll(async () => {
    useCase = (await import('.')).default;
  });

  test('should get termGrid with success', async () => {
    const res = await useCase.execute();

    expect(res.isRight()).toBe(true);

    const successValue = res.value.getValue() as GetTermGridDTO.ResponseBody;
    expect(successValue).toBeDefined();
  });

  test('should return Unexpected Error', async () => {
    const service = new TermServiceMock();

    const spy = vi.spyOn(service, 'getTermGrid');

    spy.mockImplementationOnce((): any => {
      return Promise.reject(new Error('Unexpexted error'));
    });

    const useCase = new GetTermGridUseCase(service);

    const res = await useCase.execute();

    expect(res.isRight()).toBe(false);

    const errorValue = (
      res as GetTermGridDTO.Response
    ).value.errorValue() as UseCaseError;

    expect(errorValue.code).toBe(ErrorCodeEnum.UnexpectedError);
  });

  test('should return Not Found Error', async () => {
    const service = new TermServiceMock();

    const spy = vi.spyOn(service, 'getTermGrid');

    spy.mockImplementationOnce((): any => {
      return Promise.reject(new Error('404 Not Found'));
    });

    const useCase = new GetTermGridUseCase(service);

    const res = await useCase.execute();

    expect(res.isRight()).toBe(false);

    const errorValue = (
      res as GetTermGridDTO.Response
    ).value.errorValue() as UseCaseError;

    expect(errorValue.code).toBe(ErrorCodeEnum.NotFound);
  });

  test('should return Access Denied Error', async () => {
    const service = new TermServiceMock();

    const spy = vi.spyOn(service, 'getTermGrid');

    spy.mockImplementationOnce((): any => {
      return Promise.reject(new Error('401 Access Denied'));
    });

    const useCase = new GetTermGridUseCase(service);

    const res = await useCase.execute();

    expect(res.isRight()).toBe(false);

    const errorValue = (
      res as GetTermGridDTO.Response
    ).value.errorValue() as UseCaseError;

    expect(errorValue.code).toBe(ErrorCodeEnum.AccessDenied);
  });
});
