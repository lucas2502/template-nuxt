import { ITermService } from '../../services/TermService';
import { GetTermGridDTO } from './GetTermGridDTO';
import { UseCase } from '@/core/base/UseCase';
import { AppError } from '@/core/base/AppError';
import { left, right } from '@/core/base/Either';
import { Result } from '@/core/base/Result';
import { CallError } from '@/core/types/ErrorType';
import { HttpHelper } from '@/core/helpers/HttpHelper';
import { FormatHelper } from '@/core/helpers/FormatHelper';
import { Helper } from '@/core/helpers/Helper';

export class GetTermGridUseCase
  implements UseCase<undefined, GetTermGridDTO.Response>
{
  constructor(private termService: ITermService) {
    this.termService = termService;
  }

  public async execute(): Promise<GetTermGridDTO.Response> {
    try {
      const res = await this.termService.getTermGrid();
      const {
        termId,
        name,
        approvedAt,
        updateRequestAt,
        updateRequestOwner,
        hasUpdateRequest
      } = res;
      const formattedResponse = {
        id: termId,
        name,
        approvedAt: Helper.isDefined(approvedAt)
          ? FormatHelper.formatIsoDateToDdMmYyyy(approvedAt)
          : '',
        updateRequestAt: Helper.isDefined(updateRequestAt)
          ? FormatHelper.formatIsoDateAndTimeToDdMmYyyy(updateRequestAt)
          : '',
        updateRequestOwner,
        hasUpdateRequest
      };

      return right(Result.ok([formattedResponse]));
    } catch (err) {
      if (HttpHelper.isNotFoundError(err as CallError)) {
        return left(new AppError.DataNotFound(err));
      }
      if (HttpHelper.isUnauthorizedError(err as CallError)) {
        return left(new AppError.AccessDeniedError(err));
      }
      return left(new AppError.UnexpectedError(err));
    }
  }
}
