import { AppError } from 'core/base/AppError';
import type { Either } from 'core/base/Either';
import { Result } from 'core/base/Result';

export namespace GetTermGridDTO {
  export interface ResponseProps {
    id: string;
    name?: string;
    approvedAt?: string;
    updateRequestAt?: string;
    updateRequestOwner?: string;
    hasUpdateRequest: boolean;
  }
  export interface ResponseBody extends Array<ResponseProps> {}

  export type Response = Either<
    | AppError.UnexpectedError
    | AppError.DataNotFound
    | AppError.Unauthorized
    | AppError.RequiredFields,
    Result<ResponseBody>
  >;
}
