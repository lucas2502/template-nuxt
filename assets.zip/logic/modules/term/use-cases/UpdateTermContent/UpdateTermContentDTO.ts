import { AppError } from 'core/base/AppError';
import type { Either } from 'core/base/Either';
import { Result } from 'core/base/Result';

export namespace UpdateTermContentDTO {
  export interface Request {
    content: string;
  }
  export interface ResponseBody {
    id?: string;
  }

  export type Response = Either<
    | AppError.UnexpectedError
    | AppError.BadRequest
    | AppError.Unauthorized
    | AppError.RequiredFields,
    Result<ResponseBody>
  >;
}
