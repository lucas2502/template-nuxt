import { TermServiceMock } from '../../services/TermServiceMock';
import { UpdateTermContentDTO } from './UpdateTermContentDTO';
import { UpdateTermContentUseCase } from './UpdateTermContentUseCase';
import { UseCase } from '@/core/base/UseCase';
import { UseCaseError } from '@/core/base/UseCaseError';
import { ErrorCodeEnum } from '@/core/enums/ErrorCodeEnum';

describe('UseCase: TermGrid/UpdateTermContent', () => {
  let useCase: UseCase<
    UpdateTermContentDTO.Request,
    UpdateTermContentDTO.Response
  >;
  const mockData = {
    content: '<p>Teste</p>'
  };
  beforeAll(async () => {
    useCase = (await import('.')).default;
  });

  test('should get termGrid with success', async () => {
    const res = await useCase.execute(mockData);

    expect(res.isRight()).toBe(true);

    const successValue =
      res.value.getValue() as UpdateTermContentDTO.ResponseBody;
    expect(successValue).toBeDefined();
  });

  test('should return Unexpected Error', async () => {
    const service = new TermServiceMock();

    const spy = vi.spyOn(service, 'updateTermContent');

    spy.mockImplementationOnce((): any => {
      return Promise.reject(new Error('Unexpexted error'));
    });

    const useCase = new UpdateTermContentUseCase(service);

    const res = await useCase.execute(mockData);

    expect(res.isRight()).toBe(false);

    const errorValue = (
      res as UpdateTermContentDTO.Response
    ).value.errorValue() as UseCaseError;

    expect(errorValue.code).toBe(ErrorCodeEnum.UnexpectedError);
  });

  test('should return Access Denied Error', async () => {
    const service = new TermServiceMock();

    const spy = vi.spyOn(service, 'updateTermContent');

    spy.mockImplementationOnce((): any => {
      return Promise.reject(new Error('401 Access Denied'));
    });

    const useCase = new UpdateTermContentUseCase(service);

    const res = await useCase.execute(mockData);

    expect(res.isRight()).toBe(false);

    const errorValue = (
      res as UpdateTermContentDTO.Response
    ).value.errorValue() as UseCaseError;

    expect(errorValue.code).toBe(ErrorCodeEnum.AccessDenied);
  });
});
