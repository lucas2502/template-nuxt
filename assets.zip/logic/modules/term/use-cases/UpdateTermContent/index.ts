import { TermService } from '../../services/TermService';
import { TermServiceMock } from '../../services/TermServiceMock';
import { UpdateTermContentUseCase } from './UpdateTermContentUseCase';
import { Helper } from '@/core/helpers/Helper';
import { HttpAdapter } from '@/core/adapter/HttpAdapter';

const MOCK = Helper.isTestMode();

const httpAdapter = new HttpAdapter();

const termService = MOCK ? new TermServiceMock() : new TermService(httpAdapter);

const updateTermContentUseCase = new UpdateTermContentUseCase(termService);

export default updateTermContentUseCase;
