import { ITermService } from '../../services/TermService';
import { UpdateTermContentDTO } from './UpdateTermContentDTO';
import { UseCase } from '@/core/base/UseCase';
import { AppError } from '@/core/base/AppError';
import { left, right } from '@/core/base/Either';
import { Result } from '@/core/base/Result';
import { CallError } from '@/core/types/ErrorType';
import { HttpHelper } from '@/core/helpers/HttpHelper';

export class UpdateTermContentUseCase
  implements
    UseCase<UpdateTermContentDTO.Request, UpdateTermContentDTO.Response>
{
  constructor(private termService: ITermService) {
    this.termService = termService;
  }

  public async execute(
    req: UpdateTermContentDTO.Request
  ): Promise<UpdateTermContentDTO.Response> {
    try {
      const res = await this.termService.updateTermContent(req);
      const formattedResponse = {
        id: res.termId
      };
      return right(Result.ok(formattedResponse));
    } catch (err) {
      if (HttpHelper.isBadRequestError(err as CallError)) {
        return left(new AppError.BadRequest(err));
      }

      if (HttpHelper.isUnauthorizedError(err as CallError)) {
        return left(new AppError.AccessDeniedError(err));
      }
      return left(new AppError.UnexpectedError(err));
    }
  }
}
