import { TermService } from '../../services/TermService';
import { TermServiceMock } from '../../services/TermServiceMock';
import { GetTermByTypeUseCase } from './GetTermByTypeUseCase';
import { HttpAdapter } from '~/logic/core/adapter/HttpAdapter';
import { Helper } from '~/logic/core/helpers/Helper';

const MOCK = Helper.isTestMode();

const httpAdapter = new HttpAdapter();

const termService = MOCK ? new TermServiceMock() : new TermService(httpAdapter);

const getTermByTypeUseCase = new GetTermByTypeUseCase(termService);

export default getTermByTypeUseCase;
