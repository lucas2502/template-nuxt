import { ITermService } from '../../services/TermService';
import { GetTermByTypeDTO } from './GetTermByTypeDTO';
import { UseCase } from '@/core/base/UseCase';
import { AppError } from '@/core/base/AppError';
import { left, right } from '@/core/base/Either';
import { Result } from '@/core/base/Result';
import { CallError } from '@/core/types/ErrorType';
import { HttpHelper } from '@/core/helpers/HttpHelper';

export class GetTermByTypeUseCase
  implements UseCase<GetTermByTypeDTO.Request, GetTermByTypeDTO.Response>
{
  constructor(private termService: ITermService) {
    this.termService = termService;
  }

  public async execute(
    req: GetTermByTypeDTO.Request
  ): Promise<GetTermByTypeDTO.Response> {
    try {
      const body = {
        termType: req.type
      };
      const res = await this.termService.getTermByType(body);
      return right(Result.ok(res));
    } catch (err) {
      if (HttpHelper.isNotFoundError(err as CallError)) {
        return left(new AppError.DataNotFound(err));
      }

      if (HttpHelper.isBadRequestError(err as CallError)) {
        return left(new AppError.BadRequest(err));
      }

      if (HttpHelper.isUnauthorizedError(err as CallError)) {
        return left(new AppError.AccessDeniedError(err));
      }
      return left(new AppError.UnexpectedError(err));
    }
  }
}
