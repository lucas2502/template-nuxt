import { TermType } from '../../enums/TermTypeEnum';
import { TermServiceMock } from '../../services/TermServiceMock';
import { GetTermByTypeDTO } from './GetTermByTypeDTO';
import { GetTermByTypeUseCase } from './GetTermByTypeUseCase';
import { UseCase } from '@/core/base/UseCase';
import { UseCaseError } from '@/core/base/UseCaseError';
import { ErrorCodeEnum } from '@/core/enums/ErrorCodeEnum';

describe('UseCase: getTermGrid/GetTermByType', () => {
  let useCase: UseCase<GetTermByTypeDTO.Request, GetTermByTypeDTO.Response>;
  const mockData = {
    type: TermType.APPROVED
  };
  beforeAll(async () => {
    useCase = (await import('.')).default;
  });

  test('should get termGrid with success', async () => {
    const res = await useCase.execute(mockData);
    expect(res.isRight()).toBe(true);

    const successValue = res.value.getValue() as GetTermByTypeDTO.ResponseBody;
    expect(successValue).toBeDefined();
  });

  test('should return Unexpected Error', async () => {
    const service = new TermServiceMock();

    const spy = vi.spyOn(service, 'getTermByType');

    spy.mockImplementationOnce((): any => {
      return Promise.reject(new Error('Unexpexted error'));
    });

    const useCase = new GetTermByTypeUseCase(service);

    const res = await useCase.execute(mockData);

    expect(res.isRight()).toBe(false);

    const errorValue = (
      res as GetTermByTypeDTO.Response
    ).value.errorValue() as UseCaseError;

    expect(errorValue.code).toBe(ErrorCodeEnum.UnexpectedError);
  });

  test('should return Not Found Error', async () => {
    const service = new TermServiceMock();

    const spy = vi.spyOn(service, 'getTermByType');

    spy.mockImplementationOnce((): any => {
      return Promise.reject(new Error('404 Not Found'));
    });

    const useCase = new GetTermByTypeUseCase(service);

    const res = await useCase.execute(mockData);

    expect(res.isRight()).toBe(false);

    const errorValue = (
      res as GetTermByTypeDTO.Response
    ).value.errorValue() as UseCaseError;

    expect(errorValue.code).toBe(ErrorCodeEnum.NotFound);
  });

  test('should return Access Denied Error', async () => {
    const service = new TermServiceMock();

    const spy = vi.spyOn(service, 'getTermByType');

    spy.mockImplementationOnce((): any => {
      return Promise.reject(new Error('401 Access Denied'));
    });

    const useCase = new GetTermByTypeUseCase(service);

    const res = await useCase.execute(mockData);

    expect(res.isRight()).toBe(false);

    const errorValue = (
      res as GetTermByTypeDTO.Response
    ).value.errorValue() as UseCaseError;

    expect(errorValue.code).toBe(ErrorCodeEnum.AccessDenied);
  });
});
