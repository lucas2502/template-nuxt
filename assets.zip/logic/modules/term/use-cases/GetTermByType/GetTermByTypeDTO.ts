import { AppError } from 'core/base/AppError';
import type { Either } from 'core/base/Either';
import { Result } from 'core/base/Result';
import { TermTypeKey } from '../../enums/TermTypeEnum';

export namespace GetTermByTypeDTO {
  export interface Request {
    type: TermTypeKey;
  }
  export interface ResponseBody {
    id: string;
    name?: string;
    content?: string;
  }

  export type Response = Either<
    | AppError.UnexpectedError
    | AppError.DataNotFound
    | AppError.BadRequest
    | AppError.Unauthorized
    | AppError.RequiredFields,
    Result<ResponseBody>
  >;
}
