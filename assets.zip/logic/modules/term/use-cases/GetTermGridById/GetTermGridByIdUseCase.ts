import { ITermService } from '../../services/TermService';
import { GetTermGridByIdDTO } from './GetTermGridByIdDTO';
import { UseCase } from '@/core/base/UseCase';
import { AppError } from '@/core/base/AppError';
import { left, right } from '@/core/base/Either';
import { Result } from '@/core/base/Result';
import { CallError } from '@/core/types/ErrorType';
import { HttpHelper } from '@/core/helpers/HttpHelper';

export class GetTermGridByIdUseCase
  implements UseCase<GetTermGridByIdDTO.Request, GetTermGridByIdDTO.Response>
{
  constructor(private termService: ITermService) {
    this.termService = termService;
  }

  public async execute(
    req: GetTermGridByIdDTO.Request
  ): Promise<GetTermGridByIdDTO.Response> {
    try {
      const res = await this.termService.getTermGridById(req);
      return right(Result.ok(res));
    } catch (err) {
      if (HttpHelper.isNotFoundError(err as CallError)) {
        return left(new AppError.DataNotFound(err));
      }

      if (HttpHelper.isBadRequestError(err as CallError)) {
        return left(new AppError.BadRequest(err));
      }

      if (HttpHelper.isUnauthorizedError(err as CallError)) {
        return left(new AppError.AccessDeniedError(err));
      }
      return left(new AppError.UnexpectedError(err));
    }
  }
}
