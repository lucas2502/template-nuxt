import { TermService } from '../../services/TermService';
import { TermServiceMock } from '../../services/TermServiceMock';
import { AcceptTermUseCase } from './AcceptTermUseCase';
import { HttpAdapter } from '@/core/adapter/HttpAdapter';
import { Helper } from '@/core/helpers/Helper';

const MOCK = Helper.isTestMode();

const httpAdapter = new HttpAdapter();

const termService = MOCK ? new TermServiceMock() : new TermService(httpAdapter);

const acceptTermUseCase = new AcceptTermUseCase(termService);

export default acceptTermUseCase;
