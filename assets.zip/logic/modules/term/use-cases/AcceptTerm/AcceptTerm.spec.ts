import { TermServiceMock } from '../../services/TermServiceMock';
import { AcceptTermDTO } from './AcceptTermDTO';
import { AcceptTermUseCase } from './AcceptTermUseCase';
import { UseCase } from '@/core/base/UseCase';
import { UseCaseError } from '@/core/base/UseCaseError';
import { ErrorCodeEnum } from '@/core/enums/ErrorCodeEnum';

describe('UseCase: term/AcceptTerm', () => {
  let useCase: UseCase<AcceptTermDTO.Request, AcceptTermDTO.Response>;
  const mockData = {
    id: 'id1234'
  };

  beforeAll(async () => {
    useCase = (await import('.')).default;
  });

  test('should set term agreement with success', async () => {
    const res = await useCase.execute(mockData);
    expect(res.isRight()).toBe(true);

    res.value.getValue() as AcceptTermDTO.ResponseBody;
  });

  test('should return Unexpected Error', async () => {
    const service = new TermServiceMock();

    const spy = vi.spyOn(service, 'acceptTerm');

    spy.mockImplementationOnce((): any => {
      return Promise.reject(new Error('Unexpexted error'));
    });

    const useCase = new AcceptTermUseCase(service);

    const res = await useCase.execute(mockData);

    expect(res.isRight()).toBe(false);

    const errorValue = (
      res as AcceptTermDTO.Response
    ).value.errorValue() as UseCaseError;

    expect(errorValue.code).toBe(ErrorCodeEnum.UnexpectedError);
  });

  test('should return Access Denied Error', async () => {
    const service = new TermServiceMock();

    const spy = vi.spyOn(service, 'acceptTerm');

    spy.mockImplementationOnce((): any => {
      return Promise.reject(new Error('401 Access Denied'));
    });

    const useCase = new AcceptTermUseCase(service);

    const res = await useCase.execute(mockData);

    expect(res.isRight()).toBe(false);

    const errorValue = (
      res as AcceptTermDTO.Response
    ).value.errorValue() as UseCaseError;

    expect(errorValue.code).toBe(ErrorCodeEnum.AccessDenied);
  });
});
