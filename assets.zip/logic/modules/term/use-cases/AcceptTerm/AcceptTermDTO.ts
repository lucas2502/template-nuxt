import { AppError } from 'core/base/AppError';
import type { Either } from 'core/base/Either';
import { Result } from 'core/base/Result';

export namespace AcceptTermDTO {
  export interface Request {
    id: string;
  }
  export type ResponseBody = void;

  export type Response = Either<
    | AppError.UnexpectedError
    | AppError.BadRequest
    | AppError.Unauthorized
    | AppError.RequiredFields,
    Result<ResponseBody>
  >;
}
