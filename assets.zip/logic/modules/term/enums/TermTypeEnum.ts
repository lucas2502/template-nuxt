export enum ApproveType {
  REJECT = 'Reject',
  APPROVE = 'Approve'
}

export type ApproveTypeKey = ApproveType.APPROVE | ApproveType.REJECT;

export enum TermType {
  CURRENT = 'Vigente',
  PENDING_APPROVAL = 'PendenteAprovacao',
  APPROVED = 'Aprovado',
  REPROVED = 'Reprovado'
}

export type TermTypeKey = `${TermType}`;
