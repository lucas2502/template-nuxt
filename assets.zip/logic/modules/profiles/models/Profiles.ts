import type { ProfileTypeKey } from '../enums/ProfileTypeEnum';

export interface UserId {
  userId: string;
}
export interface Profile {
  id: string;
  profileName: string;
  description: string;
  profileType: ProfileTypeKey;
  assignedUsers?: UserId[];
  functionalities?: string[];
}
