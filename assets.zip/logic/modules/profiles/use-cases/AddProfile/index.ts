import { HttpAdapter } from 'core/adapter/HttpAdapter';
import { Helper } from 'core/helpers/Helper';
import { ProfilesServiceMock } from '../../services/ProfilesServiceMock';
import { ProfilesService } from '../../services/ProfilesService';
import { AddProfileUseCase } from './AddProfileUseCase';

const MOCK = Helper.isTestMode();

const httpAdapter = new HttpAdapter();

const profilesService = MOCK
  ? new ProfilesServiceMock()
  : new ProfilesService(httpAdapter);

const addProfileUseCase = new AddProfileUseCase(profilesService);

export default addProfileUseCase;
