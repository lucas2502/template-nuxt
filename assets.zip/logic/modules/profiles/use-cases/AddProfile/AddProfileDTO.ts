import { AppError } from 'core/base/AppError';
import type { Either } from 'core/base/Either';
import { Result } from 'core/base/Result';
import type { ProfileTypeKey } from '../../enums/ProfileTypeEnum';

import { GetAllUsersDTO } from '@/modules/users/use-cases/GetAllUsers/GetAllUsersDTO';

export namespace AddProfileDTO {
  export interface Request {
    name: string;
    description: string;
    application: ProfileTypeKey;
    assignedUsers: GetAllUsersDTO.Profile[];
    functionalities: string[];
  }

  export type ResponseBody = void;

  export type Response = Either<
    | AppError.UnexpectedError
    | AppError.BadRequest
    | AppError.RequiredFields
    | AppError.Unauthorized,
    Result<ResponseBody>
  >;
}
