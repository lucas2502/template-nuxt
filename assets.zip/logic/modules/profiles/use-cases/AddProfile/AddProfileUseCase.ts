import { ProfileType } from '../../enums/ProfileTypeEnum';
import { IProfilesService } from '../../services/ProfilesService';
import { AddProfileErrors } from './AddProfileErrors';
import { AddProfileDTO } from './AddProfileDTO';
import { UseCase } from '@/core/base/UseCase';
import { Helper } from '@/core/helpers/Helper';
import { AppError } from '@/core/base/AppError';
import { left, right } from '@/core/base/Either';
import { Result } from '@/core/base/Result';
import { CallError } from '@/core/types/ErrorType';
import { HttpHelper } from '@/core/helpers/HttpHelper';

export class AddProfileUseCase
  implements UseCase<AddProfileDTO.Request, AddProfileDTO.Response>
{
  constructor(private profileService: IProfilesService) {
    this.profileService = profileService;
  }

  public async execute(
    req: AddProfileDTO.Request
  ): Promise<AddProfileDTO.Response> {
    if (Helper.isEmpty(req.name) || Helper.isEmpty(req.application)) {
      return left(new AppError.RequiredFields());
    }

    if (!ProfileType[req.application]) {
      return left(new AddProfileErrors.InvalidProfileType());
    }

    try {
      const assignedUsers = req.assignedUsers.map(i => {
        return {
          userId: i.id,
          selected: i.assigned
        };
      });

      const data = {
        profileName: req.name,
        description: req.description,
        profileType: req.application,
        assignedUsers,
        functionalities: req.functionalities
      };

      const res = await this.profileService.addProfile(data);

      return right(Result.ok(res));
    } catch (err) {
      if (HttpHelper.isBadRequestError(err as CallError)) {
        return left(new AppError.BadRequest(err));
      }

      if (HttpHelper.isUnauthorizedError(err as CallError)) {
        return left(new AppError.AccessDeniedError(err));
      }
      return left(new AppError.UnexpectedError(err));
    }
  }
}
