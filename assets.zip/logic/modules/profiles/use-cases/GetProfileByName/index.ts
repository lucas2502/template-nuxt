import { ProfilesServiceMock } from '../../services/ProfilesServiceMock';
import { ProfilesService } from '../../services/ProfilesService';
import { GetProfileByNameUseCase } from './GetProfileByNameUseCase';
import { Helper } from '@/core/helpers/Helper';
import { HttpAdapter } from '@/core/adapter/HttpAdapter';

const MOCK = Helper.isTestMode();

const httpAdapter = new HttpAdapter();

const profilesService = MOCK
  ? new ProfilesServiceMock()
  : new ProfilesService(httpAdapter);

const getProfileByNameUseCase = new GetProfileByNameUseCase(profilesService);

export default getProfileByNameUseCase;
