import { IProfilesService } from '../../services/ProfilesService';
import { GetProfileByNameDTO } from './GetProfileByNameDTO';
import { UseCase } from '@/core/base/UseCase';
import { Helper } from '@/core/helpers/Helper';
import { AppError } from '@/core/base/AppError';
import { left, right } from '@/core/base/Either';
import { Result } from '@/core/base/Result';
import { CallError } from '@/core/types/ErrorType';
import { HttpHelper } from '@/core/helpers/HttpHelper';

export class GetProfileByNameUseCase
  implements UseCase<GetProfileByNameDTO.Request, GetProfileByNameDTO.Response>
{
  constructor(private profilesService: IProfilesService) {
    this.profilesService = profilesService;
  }

  public async execute(
    req: GetProfileByNameDTO.Request
  ): Promise<GetProfileByNameDTO.Response> {
    if (Helper.isEmpty(req.profile)) {
      return left(new AppError.RequiredFields());
    }
    try {
      const res = await this.profilesService.getProfileByName({
        profileName: req.profile
      });

      const body = {
        ...res,
        name: res.profileName,
        application: res.profileType
      };
      return right(Result.ok(body));
    } catch (err) {
      if (HttpHelper.isNotFoundError(err as CallError)) {
        return left(new AppError.DataNotFound(err));
      }

      if (HttpHelper.isUnauthorizedError(err as CallError)) {
        return left(new AppError.AccessDeniedError(err));
      }

      if (HttpHelper.isBadRequestError(err as CallError)) {
        return left(new AppError.BadRequest(err));
      }

      return left(new AppError.UnexpectedError(err));
    }
  }
}
