import { AppError } from 'core/base/AppError';
import type { Either } from 'core/base/Either';
import { Result } from 'core/base/Result';
import type { ProfileTypeKey } from '../../enums/ProfileTypeEnum';

export namespace GetProfileByNameDTO {
  export interface Request {
    profile?: string;
  }
  export interface ResponseBody {
    id: string;
    name: string;
    description: string;
    application?: ProfileTypeKey;
    functionalities?: string[];
  }

  export type Response = Either<
    | AppError.UnexpectedError
    | AppError.BadRequest
    | AppError.DataNotFound
    | AppError.RequiredFields
    | AppError.Unauthorized,
    Result<ResponseBody>
  >;
}
