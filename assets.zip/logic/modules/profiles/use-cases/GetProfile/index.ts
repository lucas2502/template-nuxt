import { ProfilesServiceMock } from '../../services/ProfilesServiceMock';
import { ProfilesService } from '../../services/ProfilesService';
import { GetProfileUseCase } from './GetProfileUseCase';
import { Helper } from '@/core/helpers/Helper';
import { HttpAdapter } from '@/core/adapter/HttpAdapter';

const MOCK = Helper.isTestMode();

const httpAdapter = new HttpAdapter();

const profilesService = MOCK
  ? new ProfilesServiceMock()
  : new ProfilesService(httpAdapter);

const getProfileUseCase = new GetProfileUseCase(profilesService);

export default getProfileUseCase;
