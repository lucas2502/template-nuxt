import { Helper } from 'core/helpers/Helper';
import { left, right } from 'core/base/Either';
import { Result } from 'core/base/Result';
import { HttpHelper } from 'core/helpers/HttpHelper';
import { AppError } from 'core/base/AppError';
import type { UseCase } from 'core/base/UseCase';
import type { CallError } from 'core/types/ErrorType';
import type { IProfilesService } from '../../services/ProfilesService';
import { ProfileType } from '../../enums/ProfileTypeEnum';
import { UpdateProfileErrors } from './UpdateProfileErrors';
import type { UpdateProfileDTO } from './UpdateProfileDTO';
import { IFunctionalityService } from '@/modules/functionality/services/FunctionalityService';

export class UpdateProfileUseCase
  implements UseCase<UpdateProfileDTO.Request, UpdateProfileDTO.Response>
{
  constructor(
    private profileService: IProfilesService,
    private functionalityService: IFunctionalityService
  ) {
    this.profileService = profileService;
    this.functionalityService = functionalityService;
  }

  public async execute(
    req: UpdateProfileDTO.Request
  ): Promise<UpdateProfileDTO.Response> {
    if (Helper.isEmpty(req.name) || Helper.isEmpty(req.application)) {
      return left(new AppError.RequiredFields());
    }

    if (!ProfileType[req.application]) {
      return left(new UpdateProfileErrors.InvalidProfileType());
    }

    try {
      const resFunctionalities =
        await this.functionalityService.getAllFunctionalities();

      const functionalitiesSelected = req.functionalities;

      const functionalities = resFunctionalities.map(item => {
        const { id } = item;
        const isSelected = functionalitiesSelected.includes(item.id);

        return {
          id,
          isSelected
        };
      });

      const assignedUsers = req.assignedUsers.map(i => {
        return {
          userId: i.id,
          selected: i.assigned
        };
      });

      const data = {
        profileName: req.name,
        description: req.description,
        profileType: req.application,
        assignedUsers,
        functionalities
      };

      const res = await this.profileService.updateProfile(data);

      return right(Result.ok(res));
    } catch (err) {
      if (HttpHelper.isBadRequestError(err as CallError)) {
        return left(new AppError.BadRequest(err));
      }
      if (HttpHelper.isUnauthorizedError(err as CallError)) {
        return left(new AppError.AccessDeniedError(err));
      }
      return left(new AppError.UnexpectedError(err));
    }
  }
}
