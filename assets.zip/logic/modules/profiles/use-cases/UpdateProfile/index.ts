import { HttpAdapter } from 'core/adapter/HttpAdapter';
import { Helper } from 'core/helpers/Helper';
import { ProfilesServiceMock } from '../../services/ProfilesServiceMock';
import { ProfilesService } from '../../services/ProfilesService';
import { UpdateProfileUseCase } from './UpdateProfileUseCase';
import { FunctionalityServiceMock } from '@/modules/functionality/services/FunctionalityServiceMock';
import { FunctionalityService } from '@/modules/functionality/services/FunctionalityService';

const MOCK = Helper.isTestMode();

const httpAdapter = new HttpAdapter();

const profilesService = MOCK
  ? new ProfilesServiceMock()
  : new ProfilesService(httpAdapter);

const functionalityService = MOCK
  ? new FunctionalityServiceMock()
  : new FunctionalityService(httpAdapter);

const updateProfileUseCase = new UpdateProfileUseCase(
  profilesService,
  functionalityService
);

export default updateProfileUseCase;
