import { Result } from 'core/base/Result';
import { UseCaseError } from 'core/base/UseCaseError';
import { ErrorCodeEnum } from 'core/enums/ErrorCodeEnum';

export namespace UpdateProfileErrors {
  export class InvalidProfileType extends Result<UseCaseError> {
    constructor() {
      super(false, {
        message: `Profile type is invalid`,
        code: ErrorCodeEnum.InvalidProfileType
      } as UseCaseError);
    }
  }
}
