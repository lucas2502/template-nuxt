import { IProfilesService } from '../../services/ProfilesService';
import { DeleteProfileDTO } from './DeleteProfileDTO';
import { UseCase } from '@/core/base/UseCase';
// import { Helper } from '@/core/helpers/Helper';
import { AppError } from '@/core/base/AppError';
import { left, right } from '@/core/base/Either';
import { Result } from '@/core/base/Result';
import { CallError } from '@/core/types/ErrorType';
import { HttpHelper } from '@/core/helpers/HttpHelper';

export class DeleteProfileUseCase
  implements UseCase<DeleteProfileDTO.Request, DeleteProfileDTO.Response>
{
  constructor(private profileService: IProfilesService) {
    this.profileService = profileService;
  }

  public async execute(
    req: DeleteProfileDTO.Request
  ): Promise<DeleteProfileDTO.Response> {
    // if (Helper.isDefined(req) && req.length > 0) {
    //   return left(new AppError.RequiredFields());
    // }

    try {
      const profiles = req.map(i => {
        return i.name;
      });

      const input = {
        profileName: profiles
      };

      const res = await this.profileService.deleteProfile(input);

      return right(Result.ok(res));
    } catch (err) {
      if (HttpHelper.isBadRequestError(err as CallError)) {
        return left(new AppError.BadRequest(err));
      }
      if (HttpHelper.isUnauthorizedError(err as CallError)) {
        return left(new AppError.AccessDeniedError(err));
      }
      return left(new AppError.UnexpectedError(err));
    }
  }
}
