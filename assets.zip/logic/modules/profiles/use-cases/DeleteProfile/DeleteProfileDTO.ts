import { AppError } from 'core/base/AppError';
import type { Either } from 'core/base/Either';
import { Result } from 'core/base/Result';

export namespace DeleteProfileDTO {
  export interface Profile {
    name: string;
  }
  export interface Request extends Array<Profile> {}

  export type ResponseBody = void;

  export type Response = Either<
    | AppError.UnexpectedError
    | AppError.BadRequest
    | AppError.RequiredFields
    | AppError.Unauthorized,
    Result<ResponseBody>
  >;
}
