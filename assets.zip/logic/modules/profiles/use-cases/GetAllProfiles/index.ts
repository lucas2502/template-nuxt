import { ProfilesServiceMock } from '../../services/ProfilesServiceMock';
import { ProfilesService } from '../../services/ProfilesService';
import { GetAllprofilesUseCase } from './GetAllProfilesUseCase';
import { Helper } from '@/core/helpers/Helper';
import { HttpAdapter } from '@/core/adapter/HttpAdapter';

const MOCK = Helper.isTestMode();

const httpAdapter = new HttpAdapter();

const profileService = MOCK
  ? new ProfilesServiceMock()
  : new ProfilesService(httpAdapter);

const getAllProfilesUseCase = new GetAllprofilesUseCase(profileService);

export default getAllProfilesUseCase;
