import { AppError } from 'core/base/AppError';
import type { Either } from 'core/base/Either';
import { Result } from 'core/base/Result';
import type { ProfileTypeKey } from '../../enums/ProfileTypeEnum';

export namespace GetAllProfilesDTO {
  export interface Profile {
    id: string;
    name: string;
    description: string;
    application: ProfileTypeKey;
  }

  export interface ResponseBody extends Array<Profile> {}

  export type Response = Either<
    AppError.UnexpectedError | AppError.DataNotFound | AppError.Unauthorized,
    Result<ResponseBody>
  >;
}
