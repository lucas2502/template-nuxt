import { IProfilesService } from '../../services/ProfilesService';
import { GetAllProfilesDTO } from './GetAllProfilesDTO';
import { UseCase } from '@/core/base/UseCase';
import { AppError } from '@/core/base/AppError';
import { left, right } from '@/core/base/Either';
import { Result } from '@/core/base/Result';
import { CallError } from '@/core/types/ErrorType';
import { HttpHelper } from '@/core/helpers/HttpHelper';

export class GetAllprofilesUseCase
  implements UseCase<undefined, GetAllProfilesDTO.Response>
{
  constructor(private profilesService: IProfilesService) {
    this.profilesService = profilesService;
  }

  public async execute(): Promise<GetAllProfilesDTO.Response> {
    try {
      const res = await this.profilesService.getAllProfiles();

      const profiles = res.map(item => {
        const { id, profileName, description, profileType } = item;
        return {
          id,
          name: profileName,
          description,
          application: profileType
          // zipCode
        };
      });

      return right(Result.ok(profiles));
    } catch (err) {
      if (HttpHelper.isNotFoundError(err as CallError)) {
        return left(new AppError.DataNotFound(err));
      }
      return left(new AppError.UnexpectedError(err));
    }
  }
}
