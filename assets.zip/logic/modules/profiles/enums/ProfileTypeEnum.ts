export enum ProfileType {
  Internal = 'Internal',
  External = 'External'
}

export type ProfileTypeKey = `${ProfileType}`;
