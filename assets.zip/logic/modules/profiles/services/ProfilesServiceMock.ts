import { ProfileType } from '../enums/ProfileTypeEnum';
import type { IProfilesService } from './ProfilesService';
import type { ProfilesServiceDTO } from './ProfilesServiceDTO';

const DATA = [
  {
    id: 'id123456',
    profileName: 'Administrador de usuários',
    description: `Perfil para buscar, ativar / desativar e resetar senha de usuários
      Perfil para buscar, ativar / desativar e resetar senha de usuáriosPerfil para buscar, ativar / desativar e resetar senha de usuários`,
    profileType: ProfileType.Internal,
    functionalities: [
      '055a055f-9e87-4a3e-91ba-1bdcac76ebcd',
      '0776373a-242e-4b15-a593-c9117ba97f47',
      '451f914e-de12-4173-9aaf-b83970699c2c'
    ]
  },
  {
    id: 'id123456789',
    profileName: 'Relatórios',
    description: 'Perfil para visualizar relatórios',
    profileType: ProfileType.Internal,
    functionalities: [
      '055a055f-9e87-4a3e-91ba-1bdcac76ebcd',
      '0776373a-242e-4b15-a593-c9117ba97f47',
      '451f914e-de12-4173-9aaf-b83970699c2c'
    ]
  },
  {
    id: 'id123456784',
    profileName: 'Aprovador de usuários',
    description: 'Perfil para aprovar ou reprovar solicitações de usuários',
    profileType: ProfileType.Internal,
    functionalities: [
      '055a055f-9e87-4a3e-91ba-1bdcac76ebcd',
      '0776373a-242e-4b15-a593-c9117ba97f47',
      '451f914e-de12-4173-9aaf-b83970699c2c'
    ]
  },
  {
    id: 'id123456724',
    profileName: 'Administrador de template de e-mails',
    description: 'Perfil para administrar templates de e-mails',
    profileType: ProfileType.Internal,
    functionalities: [
      '055a055f-9e87-4a3e-91ba-1bdcac76ebcd',
      '0776373a-242e-4b15-a593-c9117ba97f47',
      '451f914e-de12-4173-9aaf-b83970699c2c'
    ]
  }
];
export class ProfilesServiceMock implements IProfilesService {
  async getAllProfiles(): Promise<ProfilesServiceDTO.GetAllProfiles.Output> {
    const returnBody = DATA;

    return await new Promise((resolve, reject) => {
      try {
        setTimeout(() => {
          resolve(returnBody);
        }, 1000);
      } catch (err) {
        return reject(err);
      }
    });
  }

  async getProfile(
    _input: ProfilesServiceDTO.GetProfile.Input
  ): Promise<ProfilesServiceDTO.GetProfile.Output> {
    const returnBody = [
      {
        id: 'id123456',
        profileName: 'Administrador',
        description: 'description',
        profileType: ProfileType.Internal,
        functionalities: [
          '055a055f-9e87-4a3e-91ba-1bdcac76ebcd',
          '0776373a-242e-4b15-a593-c9117ba97f47',
          '451f914e-de12-4173-9aaf-b83970699c2c'
        ]
      },
      {
        id: '31343423',
        profileName: 'Administrador',
        description: 'description',
        profileType: ProfileType.Internal,
        functionalities: [
          '055a055f-9e87-4a3e-91ba-1bdcac76ebcd',
          '0776373a-242e-4b15-a593-c9117ba97f47',
          '451f914e-de12-4173-9aaf-b83970699c2c'
        ]
      }
    ];

    return await new Promise((resolve, reject) => {
      try {
        setTimeout(() => {
          resolve(returnBody);
        }, 3000);
      } catch (err) {
        return reject(err);
      }
    });
  }

  async getProfileByName(
    _input: ProfilesServiceDTO.GetProfileByName.Input
  ): Promise<ProfilesServiceDTO.GetProfileByName.Output> {
    const returnBody = {
      id: 'id123456',
      profileName: 'Administrador',
      description: 'description',
      profileType: ProfileType.Internal,
      functionalities: [
        '055a055f-9e87-4a3e-91ba-1bdcac76ebcd',
        '0776373a-242e-4b15-a593-c9117ba97f47',
        '451f914e-de12-4173-9aaf-b83970699c2c'
      ]
    };

    return await new Promise((resolve, reject) => {
      try {
        setTimeout(() => {
          resolve(returnBody);
        }, 3000);
      } catch (err) {
        return reject(err);
      }
    });
  }

  async addProfile(
    _input: ProfilesServiceDTO.AddProfile.Input
  ): Promise<ProfilesServiceDTO.AddProfile.Output> {
    return await new Promise((resolve, reject) => {
      try {
        setTimeout(() => {
          resolve();
        }, 1000);
      } catch (err) {
        return reject(err);
      }
    });
  }

  async updateProfile(
    _input: ProfilesServiceDTO.UpdateProfile.Input
  ): Promise<ProfilesServiceDTO.UpdateProfile.Output> {
    return await new Promise((resolve, reject) => {
      try {
        setTimeout(() => {
          resolve();
        }, 1000);
      } catch (err) {
        return reject(err);
      }
    });
  }

  async deleteProfile(
    _input: ProfilesServiceDTO.DeleteProfile.Input
  ): Promise<ProfilesServiceDTO.DeleteProfile.Output> {
    return await new Promise((resolve, reject) => {
      try {
        setTimeout(() => {
          resolve();
        }, 1000);
      } catch (err) {
        return reject(err);
      }
    });
  }
}
