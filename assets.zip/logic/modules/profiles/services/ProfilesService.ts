import type { ProfilesServiceDTO } from './ProfilesServiceDTO';
import { Config } from '@/config';
import { HttpAdapter } from '@/core/adapter/HttpAdapter';
import { HttpResponseBody } from '@/core/types/HttpResponseBody';

export interface IProfilesService {
  getAllProfiles(): Promise<ProfilesServiceDTO.GetAllProfiles.Output>;
  getProfile(
    input: ProfilesServiceDTO.GetProfile.Input
  ): Promise<ProfilesServiceDTO.GetProfile.Output>;
  getProfileByName(
    input: ProfilesServiceDTO.GetProfileByName.Input
  ): Promise<ProfilesServiceDTO.GetProfileByName.Output>;
  addProfile(
    input: ProfilesServiceDTO.AddProfile.Input
  ): Promise<ProfilesServiceDTO.AddProfile.Output>;
  updateProfile(
    input: ProfilesServiceDTO.UpdateProfile.Input
  ): Promise<ProfilesServiceDTO.UpdateProfile.Output>;
  deleteProfile(
    input: ProfilesServiceDTO.DeleteProfile.Input
  ): Promise<ProfilesServiceDTO.DeleteProfile.Output>;
}
export class ProfilesService implements IProfilesService {
  constructor(private httpAdapter: HttpAdapter) {
    this.httpAdapter = httpAdapter;
  }

  async getAllProfiles(): Promise<ProfilesServiceDTO.GetAllProfiles.Output> {
    const url = `${Config.getInstance.apiBaseUrl}/profile/api/v1/Profile`;

    const res: HttpResponseBody<ProfilesServiceDTO.GetAllProfiles.Output> =
      await this.httpAdapter.get({
        url
      });

    return res.data;
  }

  async getProfile(
    input: ProfilesServiceDTO.GetProfile.Input
  ): Promise<ProfilesServiceDTO.GetProfile.Output> {
    const profileName = input.profileName;
    const profileType = input.profileType;
    const url = `${Config.getInstance.apiBaseUrl}/profile/api/v1/Profile/FindProfiles?profileName=${profileName}&profileType=${profileType}`;

    const res: HttpResponseBody<ProfilesServiceDTO.GetProfile.Output> =
      await this.httpAdapter.get({
        url
      });

    return res.data;
  }

  async getProfileByName(
    input: ProfilesServiceDTO.GetProfileByName.Input
  ): Promise<ProfilesServiceDTO.GetProfileByName.Output> {
    const profileName = input.profileName;
    const url = `${Config.getInstance.apiBaseUrl}/profile/api/v1/Profile/name/${profileName}`;

    const res: HttpResponseBody<ProfilesServiceDTO.GetProfileByName.Output> =
      await this.httpAdapter.get({
        url
      });

    return res.data;
  }

  async addProfile(
    input: ProfilesServiceDTO.AddProfile.Input
  ): Promise<ProfilesServiceDTO.AddProfile.Output> {
    const url = `${Config.getInstance.apiBaseUrl}/profile/api/v1/Profile`;

    const body = { ...input };

    const res: HttpResponseBody<ProfilesServiceDTO.AddProfile.Output> =
      await this.httpAdapter.post({
        url,
        body
      });

    return res.data;
  }

  async updateProfile(
    input: ProfilesServiceDTO.UpdateProfile.Input
  ): Promise<ProfilesServiceDTO.UpdateProfile.Output> {
    const url = `${Config.getInstance.apiBaseUrl}/profile/api/v1/Profile`;

    const body = { ...input };

    const res: HttpResponseBody<ProfilesServiceDTO.UpdateProfile.Output> =
      await this.httpAdapter.put({
        url,
        body
      });

    return res.data;
  }

  async deleteProfile(
    input: ProfilesServiceDTO.DeleteProfile.Input
  ): Promise<ProfilesServiceDTO.DeleteProfile.Output> {
    const url = `${Config.getInstance.apiBaseUrl}/profile/api/v1/Profile`;

    const body = input;

    const res: HttpResponseBody<ProfilesServiceDTO.DeleteProfile.Output> =
      await this.httpAdapter.delete({
        url,
        body
      });

    return res.data;
  }
}
