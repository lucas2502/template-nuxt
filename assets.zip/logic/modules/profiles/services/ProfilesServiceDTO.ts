import type { ProfileTypeKey } from '../enums/ProfileTypeEnum';
import type { Profile, UserId } from '../models/Profiles';

export namespace ProfilesServiceDTO {
  export namespace GetAllProfiles {
    export interface Output extends Array<Profile> {}
  }

  export namespace GetProfile {
    export interface Input {
      profileName?: string;
      profileType?: ProfileTypeKey;
    }
    export interface Output extends Array<Profile> {}
  }

  export namespace GetProfileByName {
    export interface Input {
      profileName?: string;
    }
    export interface Output extends Profile {}
  }

  export namespace AddProfile {
    export interface Input {
      profileName: string;
      description: string;
      profileType: ProfileTypeKey;
      assignedUsers: UserId[];
      functionalities: string[];
    }
    export type Output = void;
  }

  export namespace UpdateProfile {
    export interface Input {
      profileName: string;
      description: string;
      profileType: ProfileTypeKey;
      assignedUsers: UserId[];
      functionalities: {
        id: string;
        isSelected: boolean;
      }[];
    }
    export type Output = void;
  }

  export namespace DeleteProfile {
    export interface ProfileName {
      profileName: string[];
    }
    export interface Input extends ProfileName {}
    export type Output = void;
  }
}
