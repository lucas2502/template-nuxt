import { ICompanyService } from '../../services/CompanyService';
import { DeleteCompanyDTO } from './DeleteCompanyDTO';
import { UseCase } from '@/core/base/UseCase';
import { AppError } from '@/core/base/AppError';
import { left, right } from '@/core/base/Either';
import { Result } from '@/core/base/Result';
import { CallError } from '@/core/types/ErrorType';
import { HttpHelper } from '@/core/helpers/HttpHelper';

export class DeleteCompanyUseCase
  implements UseCase<DeleteCompanyDTO.Request, DeleteCompanyDTO.Response>
{
  constructor(private companiesService: ICompanyService) {
    this.companiesService = companiesService;
  }

  public async execute(
    input: DeleteCompanyDTO.Request
  ): Promise<DeleteCompanyDTO.Response> {
    try {
      const res = await this.companiesService.deleteCompany(input);
      return right(Result.ok(res));
    } catch (err) {
      if (HttpHelper.isNotFoundError(err as CallError)) {
        return left(new AppError.DataNotFound(err));
      }
      if (HttpHelper.isUnauthorizedError(err as CallError)) {
        return left(new AppError.AccessDeniedError(err));
      }

      return left(new AppError.UnexpectedError(err));
    }
  }
}
