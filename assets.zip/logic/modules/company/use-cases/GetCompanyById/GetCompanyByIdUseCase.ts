import { ICompanyService } from '../../services/CompanyService';
import { GetCompanyByIdDTO } from './GetCompanyByIdDTO';
import { UseCase } from '@/core/base/UseCase';
import { AppError } from '@/core/base/AppError';
import { left, right } from '@/core/base/Either';
import { Result } from '@/core/base/Result';
import { CallError } from '@/core/types/ErrorType';
import { HttpHelper } from '@/core/helpers/HttpHelper';
import { Helper } from '@/core/helpers/Helper';
import { FormatHelper } from '@/core/helpers/FormatHelper';

export class GetCompanyByIdUseCase
  implements UseCase<GetCompanyByIdDTO.Request, GetCompanyByIdDTO.Response>
{
  constructor(private companiesService: ICompanyService) {
    this.companiesService = companiesService;
  }

  public async execute(
    req: GetCompanyByIdDTO.Request
  ): Promise<GetCompanyByIdDTO.Response> {
    try {
      const res = await this.companiesService.getCompanyById(req);
      const formattedResponse = {
        ...res,
        cnpj: Helper.isDefined(res.cnpj)
          ? FormatHelper.formatCnpj(res.cnpj)
          : res.cnpj,
        zipCode: Helper.isDefined(res.zipCode)
          ? FormatHelper.formatCep(res.zipCode)
          : res.zipCode,
        phone: Helper.isDefined(res.phones)
          ? res.phones.map(i => FormatHelper.formatPhoneNumber(i))
          : res.phones
      };
      return right(Result.ok(formattedResponse));
    } catch (err) {
      if (HttpHelper.isNotFoundError(err as CallError)) {
        return left(new AppError.DataNotFound(err));
      }
      if (HttpHelper.isBadRequestError(err as CallError)) {
        return left(new AppError.BadRequest(err));
      }
      if (HttpHelper.isUnauthorizedError(err as CallError)) {
        return left(new AppError.AccessDeniedError(err));
      }

      return left(new AppError.UnexpectedError(err));
    }
  }
}
