import { vi } from 'vitest';
import { CompanyServiceMock } from '../../services/CompanyServiceMock';
import { DeleteCompanyDTO } from '../DeleteCompany/DeleteCompanyDTO';
import { DeleteCompanyUseCase } from '../DeleteCompany/DeleteCompanyUseCase';
import { UseCase } from '@/core/base/UseCase';
import { ErrorCodeEnum } from '@/core/enums/ErrorCodeEnum';
import { UseCaseError } from '@/core/base/UseCaseError';

describe('UseCase: Users/GetCompanyById', () => {
  let useCase: UseCase<DeleteCompanyDTO.Request, DeleteCompanyDTO.Response>;

  beforeAll(async () => {
    useCase = (await import('.')).default;
  });

  const req = {
    id: '2331h21-kjj3nbn1-2k3nh2n3'
  };

  test('should get all companies with success', async () => {
    const res = await useCase.execute(req);

    expect(res.isRight()).toBe(true);
  });

  test('should return Unexpected Error', async () => {
    const service = new CompanyServiceMock();

    const spy = vi.spyOn(service, 'deleteCompany');

    spy.mockImplementationOnce((): any => {
      return Promise.reject(new Error('Unexpexted error'));
    });

    const useCase = new DeleteCompanyUseCase(service);

    const res = await useCase.execute(req);

    expect(res.isRight()).toBe(false);

    const errorValue = (
      res as DeleteCompanyDTO.Response
    ).value.errorValue() as UseCaseError;

    expect(errorValue.code).toBe(ErrorCodeEnum.UnexpectedError);
  });

  test('should return Not Found Error', async () => {
    const service = new CompanyServiceMock();

    const spy = vi.spyOn(service, 'deleteCompany');

    spy.mockImplementationOnce((): any => {
      return Promise.reject(new Error('404 Not Found'));
    });

    const useCase = new DeleteCompanyUseCase(service);

    const res = await useCase.execute(req);

    expect(res.isRight()).toBe(false);

    const errorValue = (
      res as DeleteCompanyDTO.Response
    ).value.errorValue() as UseCaseError;

    expect(errorValue.code).toBe(ErrorCodeEnum.NotFound);
  });

  test('should return Access Denied Error', async () => {
    const service = new CompanyServiceMock();

    const spy = vi.spyOn(service, 'deleteCompany');

    spy.mockImplementationOnce((): any => {
      return Promise.reject(new Error('401 Access Denied'));
    });

    const useCase = new DeleteCompanyUseCase(service);

    const res = await useCase.execute(req);

    expect(res.isRight()).toBe(false);

    const errorValue = (
      res as DeleteCompanyDTO.Response
    ).value.errorValue() as UseCaseError;

    expect(errorValue.code).toBe(ErrorCodeEnum.AccessDenied);
  });
});
