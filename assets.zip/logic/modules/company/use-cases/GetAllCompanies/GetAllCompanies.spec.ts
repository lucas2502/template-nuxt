import { vi } from 'vitest';
import { CompanyServiceMock } from '../../services/CompanyServiceMock';
import { GetAllCompaniesDTO } from './GetAllCompaniesDTO';
import { GetAllCompaniesUseCase } from './GetAllCompaniesUseCase';
import { UseCase } from '@/core/base/UseCase';
import { ErrorCodeEnum } from '@/core/enums/ErrorCodeEnum';
import { UseCaseError } from '@/core/base/UseCaseError';

describe('UseCase: Users/GetAllCompaniesUsers', () => {
  let useCase: UseCase<undefined, GetAllCompaniesDTO.Response>;

  beforeAll(async () => {
    useCase = (await import('.')).default;
  });

  test('should get all companies with success', async () => {
    const res = await useCase.execute();

    expect(res.isRight()).toBe(true);

    const successValue =
      res.value.getValue() as GetAllCompaniesDTO.ResponseBody;

    expect(successValue).toBeDefined();
  });

  test('should return Unexpected Error', async () => {
    const service = new CompanyServiceMock();

    const spy = vi.spyOn(service, 'getAllCompanies');

    spy.mockImplementationOnce((): any => {
      return Promise.reject(new Error('Unexpexted error'));
    });

    const useCase = new GetAllCompaniesUseCase(service);

    const res = await useCase.execute();

    expect(res.isRight()).toBe(false);

    const errorValue = (
      res as GetAllCompaniesDTO.Response
    ).value.errorValue() as UseCaseError;

    expect(errorValue.code).toBe(ErrorCodeEnum.UnexpectedError);
  });

  test('should return Not Found Error', async () => {
    const service = new CompanyServiceMock();

    const spy = vi.spyOn(service, 'getAllCompanies');

    spy.mockImplementationOnce((): any => {
      return Promise.reject(new Error('404 Not Found'));
    });

    const useCase = new GetAllCompaniesUseCase(service);

    const res = await useCase.execute();

    expect(res.isRight()).toBe(false);

    const errorValue = (
      res as GetAllCompaniesDTO.Response
    ).value.errorValue() as UseCaseError;

    expect(errorValue.code).toBe(ErrorCodeEnum.NotFound);
  });

  test('should return Access Denied Error', async () => {
    const service = new CompanyServiceMock();

    const spy = vi.spyOn(service, 'getAllCompanies');

    spy.mockImplementationOnce((): any => {
      return Promise.reject(new Error('401 Access Denied'));
    });

    const useCase = new GetAllCompaniesUseCase(service);

    const res = await useCase.execute();

    expect(res.isRight()).toBe(false);

    const errorValue = (
      res as GetAllCompaniesDTO.Response
    ).value.errorValue() as UseCaseError;

    expect(errorValue.code).toBe(ErrorCodeEnum.AccessDenied);
  });
});
