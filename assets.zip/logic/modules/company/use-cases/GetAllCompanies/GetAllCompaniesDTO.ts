import { AppError } from 'core/base/AppError';
import type { Either } from 'core/base/Either';
import { Result } from 'core/base/Result';

export namespace GetAllCompaniesDTO {
  export interface ResponseProps {
    id: string;
    cnpj: string;
    legalName?: string;
    tradeName?: string;
    economicActivityCode?: string;
    legalNatureCode?: string;
    responsiblePerson?: string;
    address?: string;
    number?: string;
    complement?: string;
    zipCode: string;
    district?: string;
    city?: string;
    email?: string;
    phones?: string[];
    isMainCnpj: boolean;
  }

  export interface ResponseBody extends Array<ResponseProps> {}

  export type Response = Either<
    AppError.UnexpectedError | AppError.DataNotFound | AppError.Unauthorized,
    Result<ResponseBody>
  >;
}
