import { ICompanyService } from '../../services/CompanyService';
import { GetAllCompaniesDTO } from './GetAllCompaniesDTO';
import { UseCase } from '@/core/base/UseCase';
import { AppError } from '@/core/base/AppError';
import { left, right } from '@/core/base/Either';
import { Result } from '@/core/base/Result';
import { CallError } from '@/core/types/ErrorType';
import { HttpHelper } from '@/core/helpers/HttpHelper';
import { Helper } from '@/core/helpers/Helper';
import { FormatHelper } from '@/core/helpers/FormatHelper';

export class GetAllCompaniesUseCase
  implements UseCase<undefined, GetAllCompaniesDTO.Response>
{
  constructor(private companiesService: ICompanyService) {
    this.companiesService = companiesService;
  }

  public async execute(): Promise<GetAllCompaniesDTO.Response> {
    try {
      const res = await this.companiesService.getAllCompanies();
      const formattedResponse = res.map(i => {
        return {
          ...i,
          cnpj: Helper.isDefined(i.cnpj)
            ? FormatHelper.formatCnpj(i.cnpj)
            : i.cnpj,
          zipCode: Helper.isDefined(i.zipCode)
            ? FormatHelper.formatCep(i.zipCode)
            : i.zipCode,
          phone: Helper.isDefined(i.phones)
            ? i.phones.map(i => FormatHelper.formatPhoneNumber(i))
            : i.phones
        };
      });
      return right(Result.ok(formattedResponse));
    } catch (err) {
      if (HttpHelper.isNotFoundError(err as CallError)) {
        return left(new AppError.DataNotFound(err));
      }
      if (HttpHelper.isUnauthorizedError(err as CallError)) {
        return left(new AppError.AccessDeniedError(err));
      }

      return left(new AppError.UnexpectedError(err));
    }
  }
}
