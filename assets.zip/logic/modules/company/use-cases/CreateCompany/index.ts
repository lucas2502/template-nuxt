import { CompanyService } from '../../services/CompanyService';
import { CompanyServiceMock } from '../../services/CompanyServiceMock';
import { CreateCompanyUseCase } from './CreateCompanyUseCase';
import { Helper } from '@/core/helpers/Helper';
import { HttpAdapter } from '@/core/adapter/HttpAdapter';

const MOCK = Helper.isTestMode();

const httpAdapter = new HttpAdapter();

const profileService = MOCK
  ? new CompanyServiceMock()
  : new CompanyService(httpAdapter);

const createCompanyUseCase = new CreateCompanyUseCase(profileService);

export default createCompanyUseCase;
