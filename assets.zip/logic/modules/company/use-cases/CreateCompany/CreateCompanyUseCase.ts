import { ICompanyService } from '../../services/CompanyService';
import { CreateCompanyDTO } from './CreateCompanyDTO';
import { UseCase } from '@/core/base/UseCase';
import { AppError } from '@/core/base/AppError';
import { left, right } from '@/core/base/Either';
import { Result } from '@/core/base/Result';
import { CallError } from '@/core/types/ErrorType';
import { HttpHelper } from '@/core/helpers/HttpHelper';
import { Helper } from '@/core/helpers/Helper';
import { FormatHelper } from '@/core/helpers/FormatHelper';

export class CreateCompanyUseCase
  implements UseCase<CreateCompanyDTO.Request, CreateCompanyDTO.Response>
{
  constructor(private companiesService: ICompanyService) {
    this.companiesService = companiesService;
  }

  public async execute(
    input: CreateCompanyDTO.Request
  ): Promise<CreateCompanyDTO.Response> {
    try {
      const formattedInput = {
        ...input,
        cnpj: Helper.isDefined(input.cnpj)
          ? FormatHelper.removeSpecialCharsFromString(input.cnpj)
          : input.cnpj,
        zipCode: Helper.isDefined(input.zipCode)
          ? Number(FormatHelper.removeSpecialCharsFromString(input.zipCode))
          : input.zipCode,
        economicActivityCode: Helper.isDefined(input.economicActivityCode)
          ? FormatHelper.removeSpecialCharsFromString(
              input.economicActivityCode
            )
          : input.economicActivityCode,
        legalNatureCode: Helper.isDefined(input.legalNatureCode)
          ? FormatHelper.removeSpecialCharsFromString(input.legalNatureCode)
          : input.legalNatureCode,
        phones: Helper.isDefined(input.phones)
          ? input.phones.map(i => FormatHelper.removeSpecialCharsFromString(i))
          : input.phones
      };
      const res = await this.companiesService.createCompany(formattedInput);
      return right(Result.ok(res));
    } catch (err) {
      if (HttpHelper.isNotFoundError(err as CallError)) {
        return left(new AppError.DataNotFound(err));
      }
      if (HttpHelper.isUnauthorizedError(err as CallError)) {
        return left(new AppError.AccessDeniedError(err));
      }

      return left(new AppError.UnexpectedError(err));
    }
  }
}
