import { vi } from 'vitest';
import { CompanyServiceMock } from '../../services/CompanyServiceMock';
import { CreateCompanyDTO } from './CreateCompanyDTO';
import { CreateCompanyUseCase } from './CreateCompanyUseCase';
import { UseCase } from '@/core/base/UseCase';
import { ErrorCodeEnum } from '@/core/enums/ErrorCodeEnum';
import { UseCaseError } from '@/core/base/UseCaseError';

describe('UseCase: Users/CreateCompany', () => {
  let useCase: UseCase<CreateCompanyDTO.Request, CreateCompanyDTO.Response>;

  beforeAll(async () => {
    useCase = (await import('.')).default;
  });

  const req = {
    cnpj: '12345678901234',
    legalName: 'Empresa ABC',
    tradeName: 'ABC Comércio',
    economicActivityCode: '1234',
    legalNatureCode: '5678',
    responsiblePerson: 'João da Silva',
    address: 'Rua Principal',
    number: '123',
    complement: 'Sala 101',
    zipCode: '03688-050',
    district: 'Centro',
    city: 'Cidade A',
    email: 'contato@empresaabc.com',
    phones: ['(12) 3456-7890', '(98) 7654-3210']
  };

  test('should get all companies with success', async () => {
    const res = await useCase.execute(req);

    expect(res.isRight()).toBe(true);
  });

  test('should return Unexpected Error', async () => {
    const service = new CompanyServiceMock();

    const spy = vi.spyOn(service, 'createCompany');

    spy.mockImplementationOnce((): any => {
      return Promise.reject(new Error('Unexpexted error'));
    });

    const useCase = new CreateCompanyUseCase(service);

    const res = await useCase.execute(req);

    expect(res.isRight()).toBe(false);

    const errorValue = (
      res as CreateCompanyDTO.Response
    ).value.errorValue() as UseCaseError;

    expect(errorValue.code).toBe(ErrorCodeEnum.UnexpectedError);
  });

  test('should return Not Found Error', async () => {
    const service = new CompanyServiceMock();

    const spy = vi.spyOn(service, 'createCompany');

    spy.mockImplementationOnce((): any => {
      return Promise.reject(new Error('404 Not Found'));
    });

    const useCase = new CreateCompanyUseCase(service);

    const res = await useCase.execute(req);

    expect(res.isRight()).toBe(false);

    const errorValue = (
      res as CreateCompanyDTO.Response
    ).value.errorValue() as UseCaseError;

    expect(errorValue.code).toBe(ErrorCodeEnum.NotFound);
  });

  test('should return Access Denied Error', async () => {
    const service = new CompanyServiceMock();

    const spy = vi.spyOn(service, 'createCompany');

    spy.mockImplementationOnce((): any => {
      return Promise.reject(new Error('401 Access Denied'));
    });

    const useCase = new CreateCompanyUseCase(service);

    const res = await useCase.execute(req);

    expect(res.isRight()).toBe(false);

    const errorValue = (
      res as CreateCompanyDTO.Response
    ).value.errorValue() as UseCaseError;

    expect(errorValue.code).toBe(ErrorCodeEnum.AccessDenied);
  });
});
