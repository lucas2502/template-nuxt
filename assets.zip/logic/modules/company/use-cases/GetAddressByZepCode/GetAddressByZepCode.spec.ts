import { vi } from 'vitest';
import { CompanyServiceMock } from '../../services/CompanyServiceMock';
import { GetAddressByZepCodeDTO } from './GetAddressByZepCodeDTO';
import { GetAddressByZepCodeUseCase } from './GetAddressByZepCodeUseCase';
import { UseCase } from '@/core/base/UseCase';
import { ErrorCodeEnum } from '@/core/enums/ErrorCodeEnum';
import { UseCaseError } from '@/core/base/UseCaseError';

describe('UseCase: Users/GetCompanyById', () => {
  let useCase: UseCase<
    GetAddressByZepCodeDTO.Request,
    GetAddressByZepCodeDTO.Response
  >;

  beforeAll(async () => {
    useCase = (await import('.')).default;
  });

  const req = {
    zipCode: '03688030'
  };

  test('should get all companies with success', async () => {
    const res = await useCase.execute(req);

    expect(res.isRight()).toBe(true);

    const successValue =
      res.value.getValue() as GetAddressByZepCodeDTO.ResponseBody;

    expect(successValue).toBeDefined();
  });

  test('should return Unexpected Error', async () => {
    const service = new CompanyServiceMock();

    const spy = vi.spyOn(service, 'getAddressByZepCode');

    spy.mockImplementationOnce((): any => {
      return Promise.reject(new Error('Unexpexted error'));
    });

    const useCase = new GetAddressByZepCodeUseCase(service);

    const res = await useCase.execute(req);

    expect(res.isRight()).toBe(false);

    const errorValue = (
      res as GetAddressByZepCodeDTO.Response
    ).value.errorValue() as UseCaseError;

    expect(errorValue.code).toBe(ErrorCodeEnum.UnexpectedError);
  });

  test('should return Not Found Error', async () => {
    const service = new CompanyServiceMock();

    const spy = vi.spyOn(service, 'getAddressByZepCode');

    spy.mockImplementationOnce((): any => {
      return Promise.reject(new Error('404 Not Found'));
    });

    const useCase = new GetAddressByZepCodeUseCase(service);

    const res = await useCase.execute(req);

    expect(res.isRight()).toBe(false);

    const errorValue = (
      res as GetAddressByZepCodeDTO.Response
    ).value.errorValue() as UseCaseError;

    expect(errorValue.code).toBe(ErrorCodeEnum.NotFound);
  });

  test('should return Access Denied Error', async () => {
    const service = new CompanyServiceMock();

    const spy = vi.spyOn(service, 'getAddressByZepCode');

    spy.mockImplementationOnce((): any => {
      return Promise.reject(new Error('401 Access Denied'));
    });

    const useCase = new GetAddressByZepCodeUseCase(service);

    const res = await useCase.execute(req);

    expect(res.isRight()).toBe(false);

    const errorValue = (
      res as GetAddressByZepCodeDTO.Response
    ).value.errorValue() as UseCaseError;

    expect(errorValue.code).toBe(ErrorCodeEnum.AccessDenied);
  });
});
