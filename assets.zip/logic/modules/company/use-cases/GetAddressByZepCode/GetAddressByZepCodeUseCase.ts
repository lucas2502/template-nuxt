import { ICompanyService } from '../../services/CompanyService';
import { GetAddressByZepCodeDTO } from './GetAddressByZepCodeDTO';
import { UseCase } from '@/core/base/UseCase';
import { AppError } from '@/core/base/AppError';
import { left, right } from '@/core/base/Either';
import { Result } from '@/core/base/Result';
import { CallError } from '@/core/types/ErrorType';
import { HttpHelper } from '@/core/helpers/HttpHelper';
import { Helper } from '@/core/helpers/Helper';
import { FormatHelper } from '@/core/helpers/FormatHelper';

export class GetAddressByZepCodeUseCase
  implements
    UseCase<GetAddressByZepCodeDTO.Request, GetAddressByZepCodeDTO.Response>
{
  constructor(private companiesService: ICompanyService) {
    this.companiesService = companiesService;
  }

  public async execute(
    req: GetAddressByZepCodeDTO.Request
  ): Promise<GetAddressByZepCodeDTO.Response> {
    try {
      const formattedInput = {
        zipCode: Helper.isDefined(req.zipCode)
          ? FormatHelper.removeSpecialCharsFromString(req.zipCode)
          : req.zipCode
      };
      const res = await this.companiesService.getAddressByZepCode(
        formattedInput
      );
      return right(Result.ok(res[0]));
    } catch (err) {
      if (HttpHelper.isNotFoundError(err as CallError)) {
        return left(new AppError.DataNotFound(err));
      }
      if (HttpHelper.isBadRequestError(err as CallError)) {
        return left(new AppError.BadRequest(err));
      }
      if (HttpHelper.isUnauthorizedError(err as CallError)) {
        return left(new AppError.AccessDeniedError(err));
      }

      return left(new AppError.UnexpectedError(err));
    }
  }
}
