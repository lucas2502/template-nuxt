import { AppError } from 'core/base/AppError';
import type { Either } from 'core/base/Either';
import { Result } from 'core/base/Result';

export namespace GetAddressByZepCodeDTO {
  export interface Request {
    zipCode: string;
  }

  export interface ResponseBody {
    cep?: string;
    logradouro?: string;
    bairro?: string;
    localidade?: string;
    uf?: string;
  }

  export type Response = Either<
    | AppError.UnexpectedError
    | AppError.DataNotFound
    | AppError.BadRequest
    | AppError.Unauthorized,
    Result<ResponseBody>
  >;
}
