import { AppError } from 'core/base/AppError';
import type { Either } from 'core/base/Either';
import { Result } from 'core/base/Result';

export namespace PatchMainCnpjDTO {
  export interface Request {
    id: string;
  }

  export type ResponseBody = void;

  export type Response = Either<
    | AppError.UnexpectedError
    | AppError.DataNotFound
    | AppError.BadRequest
    | AppError.Unauthorized,
    Result<ResponseBody>
  >;
}
