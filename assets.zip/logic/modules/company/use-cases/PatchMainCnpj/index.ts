import { CompanyService } from '../../services/CompanyService';
import { CompanyServiceMock } from '../../services/CompanyServiceMock';
import { PatchMainCnpjUseCase } from './PatchMainCnpjUseCase';
import { Helper } from '@/core/helpers/Helper';
import { HttpAdapter } from '@/core/adapter/HttpAdapter';

const MOCK = Helper.isTestMode();

const httpAdapter = new HttpAdapter();

const profileService = MOCK
  ? new CompanyServiceMock()
  : new CompanyService(httpAdapter);

const patchMainCnpjUseCase = new PatchMainCnpjUseCase(profileService);

export default patchMainCnpjUseCase;
