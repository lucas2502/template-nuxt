import { Company } from '../models/Company';

export namespace CompanyServiceDTO {
  export namespace GetAllCompanies {
    export interface Output extends Array<Company> {}
  }

  export namespace GetCompanyById {
    export interface Input {
      id: string;
    }
    export interface Output extends Company {}
  }

  export namespace CreateCompany {
    export interface Input {
      cnpj: string;
      legalName: string;
      tradeName: string;
      economicActivityCode: string;
      legalNatureCode: string;
      responsiblePerson: string;
      address: string;
      number?: string;
      complement?: string;
      zipCode: number;
      district: string;
      city: string;
      email: string;
      phones: string[];
    }
    export type Output = void;
  }

  export namespace DeleteCompany {
    export interface Input {
      id: string;
    }
    export type Output = void;
  }

  export namespace UpdateCompany {
    export interface Input {
      id: string;
      cnpj: string;
      legalName?: string;
      tradeName?: string;
      economicActivityCode?: string;
      legalNatureCode?: string;
      responsiblePerson?: string;
      address?: string;
      number?: string;
      complement?: string;
      zipCode: number;
      district?: string;
      city?: string;
      email?: string;
      phones?: string[];
    }
    export type Output = void;
  }

  export namespace GetAddressByZepCode {
    export interface Input {
      zipCode: string;
    }

    export interface AddressProps {
      cep?: string;
      logradouro?: string;
      bairro?: string;
      localidade?: string;
      uf?: string;
    }

    export interface Output extends Array<AddressProps> {}
  }

  export namespace PatchMainCnpj {
    export interface Input {
      id: string;
    }
    export interface Output extends Company {}
  }
}
