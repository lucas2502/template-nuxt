import { ICompanyService } from './CompanyService';
import { CompanyServiceDTO } from './CompanyServiceDTO';

export class CompanyServiceMock implements ICompanyService {
  async getAllCompanies(): Promise<CompanyServiceDTO.GetAllCompanies.Output> {
    const returnBody = [
      {
        id: '123e4567-e89b-12d3-a456-426614174000',
        cnpj: '98706204000147',
        legalName: 'Empresa ABC',
        tradeName: 'ABC Comércio',
        economicActivityCode: '1234',
        legalNatureCode: '5678',
        responsiblePerson: 'João da Silva',
        address: 'Rua Principal',
        number: '123',
        complement: 'Sala 101',
        zipCode: 12345678,
        district: 'Centro',
        city: 'Cidade A',
        email: 'contato@empresaabc.com',
        phones: ['(12) 3456-7890', '(98) 7654-3210'],
        isMainCnpj: true,
        active: true
      },
      {
        id: '78901234-5678-90ab-cdef-1234567890ab',
        cnpj: '23424825000139',
        legalName: 'Empresa XYZ',
        tradeName: 'XYZ Comércio',
        economicActivityCode: '5678',
        legalNatureCode: '9012',
        responsiblePerson: 'Maria Oliveira',
        address: 'Avenida Secundária',
        number: '456',
        complement: 'Bloco C',
        zipCode: 87654321,
        district: 'Bairro B',
        city: 'Cidade X',
        email: 'contato@empresaxyz.com',
        phones: ['(34) 5678-9012', '(23) 4567-8901'],
        isMainCnpj: false,
        active: true
      },
      {
        id: 'abcdef12-3456-7890-1234-567890abcdef',
        cnpj: '69952754000148',
        legalName: 'Empresa QRS',
        tradeName: 'QRS Comércio',
        economicActivityCode: '3456',
        legalNatureCode: '7890',
        responsiblePerson: 'José Santos',
        address: 'Rua Secundária',
        number: '789',
        complement: 'Andar 2',
        zipCode: 54321098,
        district: 'Bairro C',
        city: 'Cidade Y',
        email: 'contato@empresaqrs.com',
        phones: ['(87) 6543-2109'],
        isMainCnpj: false,
        active: true
      }
    ];

    return await new Promise((resolve, reject) => {
      try {
        setTimeout(() => {
          resolve(returnBody);
        }, 1000);
      } catch (err) {
        return reject(err);
      }
    });
  }

  async getCompanyById(
    req: CompanyServiceDTO.GetCompanyById.Input
  ): Promise<CompanyServiceDTO.GetCompanyById.Output> {
    let returnBody: CompanyServiceDTO.GetCompanyById.Output;

    if (req.id === '123e4567-e89b-12d3-a456-426614174000') {
      returnBody = {
        id: '123e4567-e89b-12d3-a456-426614174000',
        cnpj: '98706204000147',
        legalName: 'Empresa ABC',
        tradeName: 'ABC Comércio',
        economicActivityCode: '1234',
        legalNatureCode: '5678',
        responsiblePerson: 'João da Silva',
        address: 'Rua Principal',
        number: '123',
        complement: 'Sala 101',
        zipCode: 12345678,
        district: 'Centro',
        city: 'Cidade A',
        email: 'contato@empresaabc.com',
        phones: ['(12) 3456-7890', '(98) 7654-3210'],
        isMainCnpj: true,
        active: true
      };
    }

    if (req.id === '78901234-5678-90ab-cdef-1234567890ab') {
      returnBody = {
        id: '78901234-5678-90ab-cdef-1234567890ab',
        cnpj: '23424825000139',
        legalName: 'Empresa XYZ',
        tradeName: 'XYZ Comércio',
        economicActivityCode: '5678',
        legalNatureCode: '9012',
        responsiblePerson: 'Maria Oliveira',
        address: 'Avenida Secundária',
        number: '456',
        complement: 'Bloco C',
        zipCode: 87654321,
        district: 'Bairro B',
        city: 'Cidade X',
        email: 'contato@empresaxyz.com',
        phones: ['(34) 5678-9012', '(23) 4567-8901'],
        isMainCnpj: false,
        active: true
      };
    }

    if (req.id === 'abcdef12-3456-7890-1234-567890abcdef') {
      returnBody = {
        id: 'abcdef12-3456-7890-1234-567890abcdef',
        cnpj: '69952754000148',
        legalName: 'Empresa QRS',
        tradeName: 'QRS Comércio',
        economicActivityCode: '3456',
        legalNatureCode: '7890',
        responsiblePerson: 'José Santos',
        address: 'Rua Secundária',
        number: '789',
        complement: 'Andar 2',
        zipCode: 54321098,
        district: 'Bairro C',
        city: 'Cidade Y',
        email: 'contato@empresaqrs.com',
        phones: ['(87) 6543-2109'],
        isMainCnpj: false,
        active: true
      };
    }

    return await new Promise((resolve, reject) => {
      try {
        setTimeout(() => {
          resolve(returnBody);
        }, 1000);
      } catch (err) {
        return reject(err);
      }
    });
  }

  async createCompany(): Promise<CompanyServiceDTO.CreateCompany.Output> {
    return await new Promise((resolve, reject) => {
      try {
        setTimeout(() => {
          resolve();
        }, 1000);
      } catch (err) {
        return reject(err);
      }
    });
  }

  async deleteCompany(): Promise<CompanyServiceDTO.DeleteCompany.Output> {
    return await new Promise((resolve, reject) => {
      try {
        setTimeout(() => {
          resolve();
        }, 1000);
      } catch (err) {
        return reject(err);
      }
    });
  }

  async updateCompany(): Promise<CompanyServiceDTO.UpdateCompany.Output> {
    return await new Promise((resolve, reject) => {
      try {
        setTimeout(() => {
          resolve();
        }, 1000);
      } catch (err) {
        return reject(err);
      }
    });
  }

  async getAddressByZepCode(): Promise<CompanyServiceDTO.GetAddressByZepCode.Output> {
    const returnBody = [
      {
        cep: '0368830',
        logradouro: 'Rua Padre Arlindo Gomes',
        bairro: 'Vila Santo Antônio',
        localidade: 'São Paulo',
        uf: 'SP'
      }
    ];

    return await new Promise((resolve, reject) => {
      try {
        setTimeout(() => {
          resolve(returnBody);
        }, 1000);
      } catch (err) {
        return reject(err);
      }
    });
  }

  async patchMainCnpj(): Promise<CompanyServiceDTO.PatchMainCnpj.Output> {
    const returnBody = {
      id: '123e4567-e89b-12d3-a456-426614174000',
      cnpj: '12345678901234',
      legalName: 'Empresa ABC',
      tradeName: 'ABC Comércio',
      economicActivityCode: '1234',
      legalNatureCode: '5678',
      responsiblePerson: 'João da Silva',
      address: 'Rua Principal',
      number: '123',
      complement: 'Sala 101',
      zipCode: 12345678,
      district: 'Centro',
      city: 'Cidade A',
      email: 'contato@empresaabc.com',
      phones: ['(12) 3456-7890', '(98) 7654-3210'],
      isMainCnpj: true,
      active: true
    };

    return await new Promise((resolve, reject) => {
      try {
        setTimeout(() => {
          resolve(returnBody);
        }, 1000);
      } catch (err) {
        return reject(err);
      }
    });
  }
}
