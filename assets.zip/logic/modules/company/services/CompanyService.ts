import { CompanyServiceDTO } from './CompanyServiceDTO';
import { HttpResponseBody } from '@/core/types/HttpResponseBody';
import { HttpAdapter } from '@/core/adapter/HttpAdapter';
import { Config } from '@/config';

export interface ICompanyService {
  getAllCompanies(): Promise<CompanyServiceDTO.GetAllCompanies.Output>;
  getCompanyById(
    input: CompanyServiceDTO.GetCompanyById.Input
  ): Promise<CompanyServiceDTO.GetCompanyById.Output>;
  createCompany(
    input: CompanyServiceDTO.CreateCompany.Input
  ): Promise<CompanyServiceDTO.CreateCompany.Output>;
  deleteCompany(
    input: CompanyServiceDTO.DeleteCompany.Input
  ): Promise<CompanyServiceDTO.DeleteCompany.Output>;
  updateCompany(
    input: CompanyServiceDTO.UpdateCompany.Input
  ): Promise<CompanyServiceDTO.UpdateCompany.Output>;
  getAddressByZepCode(
    input: CompanyServiceDTO.GetAddressByZepCode.Input
  ): Promise<CompanyServiceDTO.GetAddressByZepCode.Output>;
  patchMainCnpj(
    input: CompanyServiceDTO.PatchMainCnpj.Input
  ): Promise<CompanyServiceDTO.PatchMainCnpj.Output>;
}

export class CompanyService implements ICompanyService {
  constructor(private httpAdapter: HttpAdapter) {
    this.httpAdapter = httpAdapter;
  }

  async getAllCompanies(): Promise<CompanyServiceDTO.GetAllCompanies.Output> {
    const url = `${Config.getInstance.apiBaseUrl}/company/api/v1/Company`;

    const res: HttpResponseBody<CompanyServiceDTO.GetAllCompanies.Output> =
      await this.httpAdapter.get({
        url
      });

    return res.data;
  }

  async getCompanyById(
    input: CompanyServiceDTO.GetCompanyById.Input
  ): Promise<CompanyServiceDTO.GetCompanyById.Output> {
    const url = `${Config.getInstance.apiBaseUrl}/company/api/v1/Company?id=${input.id}`;
    const res: HttpResponseBody<CompanyServiceDTO.GetCompanyById.Output> =
      await this.httpAdapter.get({
        url
      });

    return res.data;
  }

  async createCompany(
    input: CompanyServiceDTO.CreateCompany.Input
  ): Promise<CompanyServiceDTO.CreateCompany.Output> {
    const url = `${Config.getInstance.apiBaseUrl}/company/api/v1/Company`;
    const body = { ...input };
    const res: HttpResponseBody<CompanyServiceDTO.CreateCompany.Output> =
      await this.httpAdapter.post({
        url,
        body
      });

    return res.data;
  }

  async deleteCompany(
    input: CompanyServiceDTO.DeleteCompany.Input
  ): Promise<CompanyServiceDTO.DeleteCompany.Output> {
    const url = `${Config.getInstance.apiBaseUrl}/company/api/v1/Company?id=${input.id}`;
    const res: HttpResponseBody<CompanyServiceDTO.CreateCompany.Output> =
      await this.httpAdapter.delete({
        url
      });

    return res.data;
  }

  async updateCompany(
    input: CompanyServiceDTO.UpdateCompany.Input
  ): Promise<CompanyServiceDTO.UpdateCompany.Output> {
    const url = `${Config.getInstance.apiBaseUrl}/company/api/v1/Company`;
    const body = { ...input };
    const res: HttpResponseBody<CompanyServiceDTO.UpdateCompany.Output> =
      await this.httpAdapter.put({
        url,
        body
      });

    return res.data;
  }

  async getAddressByZepCode(
    input: CompanyServiceDTO.GetAddressByZepCode.Input
  ): Promise<CompanyServiceDTO.GetAddressByZepCode.Output> {
    const url = `${Config.getInstance.apiBaseUrl}/company/api/v1/Company/GetAddress/${input.zipCode}`;
    const res: HttpResponseBody<CompanyServiceDTO.GetAddressByZepCode.Output> =
      await this.httpAdapter.get({
        url
      });

    return res.data;
  }

  async patchMainCnpj(
    input: CompanyServiceDTO.PatchMainCnpj.Input
  ): Promise<CompanyServiceDTO.PatchMainCnpj.Output> {
    const url = `${Config.getInstance.apiBaseUrl}/company/api/v1/Company?id=${input.id}`;
    const res: HttpResponseBody<CompanyServiceDTO.PatchMainCnpj.Output> =
      await this.httpAdapter.patch({
        url
      });

    return res.data;
  }
}
