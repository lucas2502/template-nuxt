export interface Company {
  id: string;
  cnpj: string;
  legalName?: string;
  tradeName?: string;
  economicActivityCode?: string;
  legalNatureCode?: string;
  responsiblePerson?: string;
  address?: string;
  number?: string;
  complement?: string;
  zipCode: number;
  district?: string;
  city?: string;
  email?: string;
  phones?: string[];
  isMainCnpj: boolean;
  active: boolean;
}
