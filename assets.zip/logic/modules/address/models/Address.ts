export interface Address {
  publicPlace: string;
  city: string;
  neighborhood: string;
  state: string;
  zipCode: string;
}
