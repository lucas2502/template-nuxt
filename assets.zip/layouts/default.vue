<template>
  <q-layout view="lHh LpR lFf" class="admin-page-layout">
    <Sidebar></Sidebar>

    <q-page-container>
      <q-page class="full-height column">
        <nuxt-page />
        <Notify></Notify>
      </q-page>
    </q-page-container>
  </q-layout>
</template>

<script lang="ts" setup></script>

<style lang="scss">
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap');
@import url('https://fonts.googleapis.com/css2?family=Nunito+Sans:ital,wght@0,200;0,300;0,400;0,600;0,700;0,800;0,900;1,200;1,300;1,400;1,600;1,700;1,800;1,900&display=swap');

* {
  font-family: 'Inter', sans-serif;
  margin: 0;
  font-size: 13px;
}
.admin-page-layout {
  background-color: #f6f6f6;
}
</style>
