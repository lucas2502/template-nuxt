import Keycloak from 'next-auth/providers/keycloak';

// @ts-ignore
import { NuxtAuthHandler } from '#auth';

export default NuxtAuthHandler({
  debug: process.env.NODE_ENV !== 'production',
  secret: process.env.NUXT_KEYCLOAK_CLIENT_SECRET,
  session: {
    strategy: 'jwt'
  },
  callbacks: {
    async jwt({ token, user, account, profile }: any) {
      if (account && user) {
        return {
          ...token,
          accessToken: account?.access_token,
          idToken: account?.id_token,
          profile: {
            name: profile?.given_name,
            id: profile?.preferred_username
          },
          iss: profile?.iss,
          ...user
        };
      }

      // Handle token refresh before it expires of 15 minutes
      if (account?.expires_at && new Date() > new Date(account?.expires_at)) {
        console.warn('Token is expired. Getting a new');
      }

      return await token;
    },
    async session({ session, token }: any) {
      (session as any).role = token.role;
      (session as any).uid = token.id;
      (session as any).accessToken = token.accessToken;
      (session as any).idToken = token.idToken;
      (session as any).profile = token.profile;
      (session as any).iss = token.iss;

      return await session;
    }
  },
  providers: [
    // @ts-expect-error You need to use .default here for it to work during SSR. May be fixed via Vite at some point
    Keycloak.default({
      clientId: process.env.NUXT_KEYCLOAK_CLIENT_ID,
      clientSecret: process.env.NUXT_KEYCLOAK_CLIENT_SECRET,
      // issuer: `${process.env.NUXT_KEYCLOAK_HOST}/auth/realms/${process.env.NUXT_KEYCLOAK_REALM}`
      issuer: `${process.env.NUXT_KEYCLOAK_HOST}`
    })
  ]
});
