// import { getToken } from '#auth';

// export default defineEventHandler(async (event): Promise<unknown> => {
//   try {
//     const token = await getToken({ event });

//     const request: {
//       path: string;
//       method: 'GET' | 'POST' | 'PUT' | 'DELETE';
//       payload: any;
//       query: any;
//     } = await readBody(event);

//     const headers = {
//       // ...event.headers,
//       Authorization: `Bearer ${token?.accessToken}`
//       // 'Content-Type': 'application/x-www-form-urlencoded'
//     };

//     const body = request.payload;
//     const url = `${process.env.API_BASE_URL}${request?.path}`;

//     console.log('API SERVER >> ', { request, headers, body, url });

//     if (request.method === 'GET') {
//       const query = request.query;

//       const responseGet = await $fetch(url, {
//         headers,
//         query
//       });

//       console.log('response get server', responseGet);
//       return responseGet;
//     }

//     const response = await $fetch(url, {
//       method: `${request.method}` as any,
//       headers,
//       body
//     });

//     console.log('response post server', response);
//     return response;
//   } catch (error) {
//     return error;
//   }
// });
