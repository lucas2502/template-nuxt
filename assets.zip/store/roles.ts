import { defineStore } from 'pinia';
import { GetAllUserRolesDTO } from '@pmesp/logic/dist/modules/functionality/use-cases/GetAllUserRoles/GetAllUserRolesDTO';
import { RoleEnumKey } from '@pmesp/logic/dist/modules/functionality/enums/RoleEnum';

interface State {
  roles: GetAllUserRolesDTO.Role[] | [];
}

export const useRolesStore = defineStore({
  id: 'roles',

  state: (): State => ({
    roles: []
  }),

  actions: {
    existRoles(route: RoleEnumKey) {
      const roles = JSON.parse(
        JSON.stringify(this.roles)
      ) as GetAllUserRolesDTO.Role[];

      const index = roles.findIndex(item => {
        return item.routes.includes(route);
      });
      return index !== -1;
    },

    setRoles(roles: GetAllUserRolesDTO.Role[]) {
      this.roles = roles;
    },
    showMenuOption(menu: string) {
      const roles = JSON.parse(
        JSON.stringify(this.roles)
      ) as GetAllUserRolesDTO.Role[];

      const index = roles.findIndex(item => {
        const menuOption = item?.menu.toLowerCase();
        return menuOption === menu?.toLowerCase();
      });

      return index !== -1;
    }
  }
});
