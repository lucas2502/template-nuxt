import { defineStore } from 'pinia';

export const useDrawerStore = defineStore({
  id: 'drawer-store',
  state: () => {
    return {
      detailsIaaSFile: {
        open: false
      },
      discount: {
        open: false
      },
      catalog: {
        open: false
      },
      uploadIaaSFile: {
        open: false
      },
      resumeProposal: {
        open: false
      },
      chargeRuler: {
        open: false
      }
    };
  },
  actions: {
    toggleDetailsIaaSFile() {
      this.detailsIaaSFile.open = !this.detailsIaaSFile.open;
    },
    toggleDiscount() {
      this.discount.open = !this.discount.open;
    },
    toggleCatalog() {
      this.catalog.open = !this.catalog.open;
    },
    toggleUploadIaaSFile() {
      this.uploadIaaSFile.open = !this.uploadIaaSFile.open;
    },
    toggleResumeProposal() {
      this.resumeProposal.open = !this.resumeProposal.open;
    },
    toggleChargeRuler() {
      this.catalog.open = !this.catalog.open;
    }
  },
  getters: {
    // isOpen: state => state.open
  }
});
