import { defineStore } from 'pinia';

// export interface UserInfo {
//   sub: string;
//   email_verified: boolean;
//   name: string;
//   preferred_username: string;
//   given_name: string;
//   family_name: string;
//   email: string;
// }
interface State {
  session: string | undefined;
}

export const useAuthStore = defineStore({
  id: 'auth',

  state: (): State => ({
    // user: null,
    session: undefined
  }),

  actions: {
    serverInit() {
      const session = localStorage.getItem('session');

      session && this.setSession(JSON.parse(session));
    },

    // setUser(user: any) {
    //   this.user = user;
    // },

    setSession(session: any) {
      this.session = session;

      localStorage.setItem('session', JSON.stringify(this.session));
    },
    removeSession() {
      this.session = undefined;

      localStorage.removeItem('session');
    }
  }
});
