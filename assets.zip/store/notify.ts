import { defineStore } from 'pinia';

export enum StatusType {
  WARNING = 'warning',
  ERROR = 'negative',
  SUCCESS = 'positive'
}
export type StatusTypeKey = `${StatusType}`;
interface State {
  type: StatusTypeKey | undefined;
  message: string | undefined;
}

export const useNotifyStore = defineStore({
  id: 'notify-store',

  state: (): State => ({
    type: undefined,
    message: undefined
  }),

  getters: {
    getNotifyOptions: (state): State => {
      const { type, message } = state;
      return {
        type,
        message
      };
    }
  },

  actions: {
    toggleNotify(value?: State) {
      this.type = value?.type;
      this.message = value?.message;
    }
  }
});
